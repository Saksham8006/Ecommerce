let backendUrl: string;
if (process.env.NODE_ENV === 'production') {
  backendUrl = 'https://us.zinventory.in';
} else {
  backendUrl = 'http://localhost:5000'; // Use your local development URL
}

export { backendUrl };

let inventoryBackendUrl: string;
if (process.env.NODE_ENV === 'production') {
  inventoryBackendUrl = 'https://in.zinventory.in';
} else {
  inventoryBackendUrl = 'http://localhost:4000'; // Use your local development URL
}

export { inventoryBackendUrl };

let accountBackendUrl: string;
if (process.env.NODE_ENV === 'production') {
  accountBackendUrl = 'https://ac.zinventory.in';
} else {
  accountBackendUrl = 'http://localhost:3000'; // Use your local development URL
}

export { accountBackendUrl };



// let inventoryBackendUrl;
// console.log(process.env.NODE_ENV)
// if (process.env.NODE_ENV === 'production') {
//   backendUrl = 'https://in.zinventory.in';
// } else {
//   backendUrl = 'http://127.0.0.1:5000'; // Use your local development URL
// }
// export default inventoryBackendUrl;
