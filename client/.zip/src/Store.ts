// src/app/store.ts

import { configureStore } from "@reduxjs/toolkit";
import { persistReducer, persistStore } from "redux-persist";
import storage from "redux-persist/lib/storage";
import brandDataReducer from './reducers/brandSlice';
// import authReducer from './reducers/authSlice'; 

// Persist config for brand data
const brandPersistConfig = {
    key: 'brandDataForOthers',
    storage,
};

// Persist config for auth data
const authPersistConfig = {
    key: 'auth',
    storage,
};

const persistedBrandDataReducer = persistReducer(brandPersistConfig, brandDataReducer);
// const persistedAuthReducer = persistReducer(authPersistConfig, authReducer);

const store = configureStore({
    reducer: {
        brandDataForOthers: persistedBrandDataReducer,
        // auth: persistedAuthReducer,
    },
});

const persistor = persistStore(store);

export { store, persistor };

// Infer the `RootState` and `AppDispatch` types from the store itself
export type RootState = ReturnType<typeof store.getState>;
export type AppDispatch = typeof store.dispatch;
