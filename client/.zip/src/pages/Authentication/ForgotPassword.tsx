import React, { HtmlHTMLAttributes, useState } from 'react'
import bgSignUp from '../../assets/bgSignUp.svg'
import business from '../../assets/business.svg'
import capsule from '../../assets/capsule.svg'
import fitbit from '../../assets/fitbit.svg'
import imageAvatarSignup from '../../assets/imageAvatarSignup.svg'
import mailChimpLogo from '../../assets/mailChimpLogo.svg'
import LOGO from '../../assets/LOGO_white.svg'
import { IoChevronBackOutline } from "react-icons/io5";
import axios from 'axios'
import { backendUrl } from '../../../src/Configmain.ts'
import { Link } from 'react-router-dom'

const ForgotPassword: React.FC = () => {
    const [email, setEmail] = useState<string>("")

    const handleForgotPass = async (event: React.MouseEvent<HTMLButtonElement, MouseEvent>) => {
        event.preventDefault();

        try {
            const data = {
                email: email
            };

            const response = await axios.post(`${backendUrl}/api/auth/forgot-password`, data);

            console.log("response", response);
        } catch (error) {
            console.log("error", error);
        }
    };


    const handleEmailChange = (event: React.ChangeEvent<HTMLInputElement>) => {
        setEmail(event?.target.value)
    }



    return (
        <div className='flex bg-white min-h-screen'>

            <div className='max-w-[43%]' style={{ backgroundImage: `url(${bgSignUp})`, backgroundSize: "cover", zIndex: "20" }}>
                <img src={LOGO} alt="" className='p-10' />

                <div className='flex flex-col min-h-[60%] gap-y-[20px] pt-[52px] my-[90px]'>
                    <img src={mailChimpLogo} alt="" className='max-w-[80%] mx-auto' />

                    <p className='text-white font-semibold text-[20px] max-w-[68%] text-center mx-auto'>“ It has many landing page variations to choose from,

                        which one is always a big advantage. ”</p>

                    <div className='text-center my-[32px]'>
                        <img src={imageAvatarSignup} alt="" className='max-w-[100%] mx-auto' />

                        <div className='my-[20px]'>
                            <p className='text-white font-semibold text-[16px]'>Project Manager | Mailchimp</p>
                        </div>
                    </div>

                </div>
                <div className='flex justify-around items-end'>
                    <img src={fitbit} alt="" />
                    <img src={business} alt="" />
                    <img src={capsule} alt="" />
                </div>
            </div>


            {/* form content */}

            <main className="w-full max-w-[575px] mx-auto pt-[110px]">
                <div className="mt-[80px] bg-white shadow-sm ">
                    <div className="p-4 sm:p-7">
                        <div className="text-center">
                            <h1 className="block text-[32px] font-[900] text-black">
                                Forgot Password
                            </h1>
                            <p className="my-[18px] text-[16px] text-slate-500 font-semibold">
                                Enter your email address below and we'll get you back on track.

                            </p>
                        </div>
                        <div className="mt-[50px]">


                            {/* Form */}
                            <form>
                                <div className="grid gap-y-4">
                                    {/* Form Group */}
                                    <div>
                                        <div className='flex justify-between'>
                                            <label
                                                htmlFor="email"
                                                className="block text-[15px] mb-2 text-black font-[500]"
                                            >
                                                Email address
                                            </label>
                                            <Link to="/auth/signin">
                                                <p className='flex text-sky-500 text-sm font-semibold'>
                                                    <span className='mt-1 mr-1'><IoChevronBackOutline /></span>
                                                    Back to Log in
                                                </p>
                                            </Link>
                                        </div>
                                        <div className="relative">
                                            <input
                                                type="email"
                                                id="email"
                                                value={email}
                                                onChange={handleEmailChange}
                                                name="email"
                                                placeholder='email@site.com'
                                                className="py-3 px-4 block w-full border border-slate-300 rounded-lg text-sm  "
                                                required
                                                aria-describedby="email-error"
                                            />
                                            <div className="hidden absolute inset-y-0 end-0 pointer-events-none pe-3">
                                                <svg
                                                    className="h-5 w-5 text-red-500"
                                                    width={16}
                                                    height={16}
                                                    fill="currentColor"
                                                    viewBox="0 0 16 16"
                                                    aria-hidden="true"
                                                >
                                                    <path d="M16 8A8 8 0 1 1 0 8a8 8 0 0 1 16 0zM8 4a.905.905 0 0 0-.9.995l.35 3.507a.552.552 0 0 0 1.1 0l.35-3.507A.905.905 0 0 0 8 4zm.002 6a1 1 0 1 0 0 2 1 1 0 0 0 0-2z" />
                                                </svg>
                                            </div>
                                        </div>
                                        <p className="hidden text-xs text-red-600 mt-2" id="email-error">
                                            Please include a valid email address so we can get back to you
                                        </p>
                                    </div>



                                    <button
                                        type="submit"
                                        onClick={handleForgotPass}
                                        className="w-full py-3 px-4 inline-flex justify-center items-center gap-x-2 text-sm font-semibold rounded-lg my-[15px]
                      bg-black uppercase text-white hover:shadow-sm"
                                    >
                                        Submit
                                    </button>


                                </div>
                            </form>
                            {/* End Form */}


                        </div>
                    </div>
                </div>
            </main>

        </div>
    )
}

export default ForgotPassword