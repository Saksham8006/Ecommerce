import React from 'react'
import bgSignUp from '../../assets/bgSignUp.svg'
import business from '../../assets/business.svg'
import capsule from '../../assets/capsule.svg'
import fitbit from '../../assets/fitbit.svg'
import imageAvatarSignup from '../../assets/imageAvatarSignup.svg'
import mailChimpLogo from '../../assets/mailChimpLogo.svg'
import LOGO from '../../assets/LOGO_white.svg'
import ZLOGO from '../../assets/ZLOGO.svg'

const OtpValidation: React.FC = () => {
    return (
        <div className='flex bg-white min-h-screen'>

            <div className='max-w-[43%]' style={{ backgroundImage: `url(${bgSignUp})`, backgroundSize: "cover", zIndex: "20" }}>
                <img src={LOGO} alt="" className='p-10' />

                <div className='flex flex-col min-h-[60%] gap-y-[20px] pt-[52px] my-[90px]'>
                    <img src={mailChimpLogo} alt="" className='max-w-[80%] mx-auto' />

                    <p className='text-white font-semibold text-[20px] max-w-[68%] text-center mx-auto'>“ It has many landing page variations to choose from,

                        which one is always a big advantage. ”</p>

                    <div className='text-center my-[32px]'>
                        <img src={imageAvatarSignup} alt="" className='max-w-[100%] mx-auto' />

                        <div className='my-[20px]'>
                            <p className='text-white font-semibold text-[16px]'>Project Manager | Mailchimp</p>
                        </div>
                    </div>

                </div>
                <div className='flex justify-around items-end'>
                    <img src={fitbit} alt="" />
                    <img src={business} alt="" />
                    <img src={capsule} alt="" />
                </div>
            </div>


            {/* form content */}

            <main className="w-full max-w-[575px] mx-auto pt-[110px]">
                <div className="mt-[80px] bg-white shadow-sm ">
                    <div className="p-4 sm:p-7">
                        <div className="text-center">
                            <h1 className="block text-[32px] font-[900] text-black max-w-[100%] mx-auto">
                                <img src={ZLOGO} alt="" className='max-w-[100%] mx-auto pb-[22px]' />
                            </h1>
                            <p className="my-[25px] text-[32px] text-black font-bold">
                                Enter the verification code

                            </p>
                            <p className='text-[18px] text-slate-600 font-semibold'>An SMS containing a 6-digit verification code has been sent to the Phone Number - 9999999999</p>

                            <p className='text-[16px] mt-[18px] font-semibold'>Don't have access? <span className='text-sky-500 underline'>Use another method</span></p>
                        </div>

                        <div className="mt-[30px]">


                            {/* Form */}
                            <form>
                                <div className="grid gap-y-4">
                                    <div id="otp" className="flex flex-row justify-center text-center px-2 ">
                                        <input
                                            className="m-2 border h-12 w-13 text-center form-control rounded"
                                            type="text"
                                            id="first"
                                            maxLength={1}
                                        />
                                        <input
                                            className="m-2 border h-12 w-13 text-center form-control rounded"
                                            type="text"
                                            id="second"
                                            maxLength={1}
                                        />
                                        <input
                                            className="m-2 border h-12 w-13 text-center form-control rounded"
                                            type="text"
                                            id="third"
                                            maxLength={1}
                                        />
                                        <input
                                            className="m-2 border h-12 w-13 text-center form-control rounded"
                                            type="text"
                                            id="fourth"
                                            maxLength={1}
                                        />
                                        <input
                                            className="m-2 border h-12 w-13 text-center form-control rounded"
                                            type="text"
                                            id="fifth"
                                            maxLength={1}
                                        />
                                        <input
                                            className="m-2 border h-12 w-13 text-center form-control rounded"
                                            type="text"
                                            id="sixth"
                                            maxLength={1}
                                        />
                                    </div>


                                    <div className="flex items-center">
                                        <div className="flex ">
                                            <input
                                                id="remember-me"
                                                name="remember-me"
                                                type="checkbox"
                                                className="shrink-0 border-gray-200 rounded text-blue-600 pointer-events-none mt-3"
                                            />
                                        </div>
                                        <div className="ms-3 pt-3">
                                            <label
                                                htmlFor="remember-me"
                                                className="text-[16px] font-semibold"
                                            >
                                                Don't ask again on this device
                                            </label>
                                        </div>
                                    </div>



                                    <button
                                        type="submit"
                                        className="w-full py-3 px-4 inline-flex justify-center items-center gap-x-2 text-sm font-semibold rounded-lg
                    bg-black uppercase text-white hover:shadow-sm"
                                    >
                                        Verify
                                    </button>


                                </div>
                            </form>
                            {/* End Form */}

                            <p className='text-black font-[500] text-center my-[18px]'>Don't recieve the code <span className='text-sky-500 underline'>Resend it.</span></p>

                        </div>
                    </div>
                </div>
            </main>

        </div>
    )
}

export default OtpValidation