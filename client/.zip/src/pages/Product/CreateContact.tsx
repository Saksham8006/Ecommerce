import React, { useState, useEffect } from 'react';
import DefaultLayout from '../../layout/DefaultLayout.tsx';
import Breadcrumb from '../../components/Breadcrumbs/Breadcrumb.tsx';
import StateData from '../../Utils/StateData.json';
import { FaHome } from 'react-icons/fa';
import employee from '../../assets/employee.svg';
import CountryData from '../../Utils/CountryData.json';
import axios from 'axios';
import toast, { Toaster } from 'react-hot-toast';
import { FaPlus } from 'react-icons/fa6';
import { backendUrl } from '../../Configmain.ts';

import { MdOutlineCancel } from 'react-icons/md';
import { useParams } from 'react-router-dom';

const CreateContact: React.FC = () => {
  const [checked, setChecked] = useState<boolean>(false);
  const [current, setCurrent] = useState<number>(1);
  const [firstName, setFirstName] = useState<string>('');
  const [lastName, setLastName] = useState<string>('');
  const [companyName, setCompanyName] = useState<string>('');
  const [code, setCode] = useState<string>('');
  const [mobile, setMobile] = useState<string>('');
  const [telephoneNumber, setTelephoneNumber] = useState<string>('');
  const [email, setEmail] = useState<string>('');
  const [remarks, setRemarks] = useState<string>('');
  const [applyTds, setApplyTds] = useState<boolean>(false);
  const [creditLimit, setCreditLimit] = useState<string>('');
  const [paymentMode, setPaymentMode] = useState<string>('');
  const [paymentTerms, setPaymentTerms] = useState<string>('');
  const [debitAmount, setDebitAmount] = useState<string>('');
  const [creditAmount, setCreditAmount] = useState<string>('');
  const [whatsapp, setWhatsapp] = useState<string>('');
  const [dob, setDob] = useState<string>('');
  const [anniversaryDate, setAnniversaryDate] = useState<string>('');
  const [customerCategory, setCustomerCategory] = useState<string>('');
  const [type, setType] = useState<string>('');

  const [panNumber, setPanNumber] = useState<string>('');

  const [role, setRole] = useState<any>('');
  const [bankName, setBankName] = useState<string>('');
  const [branchName, setBranchName] = useState<string>('');
  const [accountNumber, setAccountNumber] = useState<string>('');
  const [bankIfscCode, setBankIfscCode] = useState<string>('');
  const [transporterId, setTransporterId] = useState<string>('');
  const [contactType, setContactType] = useState<string>('customer');

  // true or false status for form validation

  const [fname, setFname] = useState<Boolean>(false);
  const [contype, setContype] = useState<Boolean>(false);
  const [gstin, setGstin] = useState<Boolean>(false);
  const [contFirstName, setContFirstName] = useState<Boolean>(false);
  const [selectCountry, setSelectContry] = useState<Boolean>(false);
  const [selectState, setSelectState] = useState<Boolean>(false);
  const [selectCity, setSelectCity] = useState<Boolean>(false);
  const [err, setErr] = useState<String>('');
  const [addressValue, setAddressValue] = useState({})

  const [Clicked, setClicked] = useState<Boolean>(false)
  const [flag, setFlag] = useState<Boolean>(false)
  const { id } = useParams<{ id: string }>();
  const token = localStorage.getItem('authorization');


  const [addressList, setAddressList] = useState<any>([
    {
      gstType: '',
      gstIn: '',
      panNumber: '',
      contactFirstName: '',
      contactLastName: '',
      contactCompanyName: '',
      contactNumber: '',
      contactEmail: '',
      addressLine1: '',
      addressLine2: '',
      country: '',
      state: '',
      city: '',
      pinCode: '',
    },
  ]);

  // console.log(addressList)

  const handleInputChange = (e: any, index: number) => {
    const { name, value } = e.target;
    const list = [...addressList];
    list[index][name] = value;

    setAddressList(list);


  };

  const handleRemove = (indexToRemove: number) => {
    const list = addressList.filter((_: any, index: number) => index !== indexToRemove);
    setAddressList(list)
  };

  const handleAddClick = () => {
    setAddressList([
      ...addressList,
      {
        gstType: '',
        gstIn: '',
        panNumber: '',
        contactFirstName: '',
        contactLastName: '',
        contactCompanyName: '',
        contactNumber: '',
        contactEmail: '',
        addressLine1: '',
        addressLine2: '',
        country: '',
        state: '',
        city: '',
        pinCode: '',
      },
    ]);
  };

  const handleChange = (
    event: React.ChangeEvent<
      HTMLInputElement | HTMLTextAreaElement | HTMLSelectElement
    >,
  ) => {
    const { id, value } = event.target;
    switch (id) {
      case 'first_name':
        setFirstName(value);
        setFname(false);
        break;
      case 'last_name':
        setLastName(value);
        break;
      case 'company_name':
        setCompanyName(value);
        break;
      case 'code':
        setCode(value);
        break;
      case 'mobile':
        setMobile(value);
        break;
      case 'telephone_no':
        setTelephoneNumber(value);
        break;
      case 'email':
        setEmail(value);
        break;
      case 'remarks':
        setRemarks(value);
        break;
      case 'apply_tds':
        setApplyTds(true);
        break;
      case 'credit_limit':
        setCreditLimit(value);
        break;
      case 'payment_mode':
        setPaymentMode(value);
        break;
      case 'payment_terms':
        setPaymentTerms(value);
        break;
      case 'debit_amount':
        setDebitAmount(value);
        break;
      case 'credit_amount':
        setCreditAmount(value);
        break;
      case 'dob':
        setDob(value);
        break;
      case 'whatsapp_no':
        setWhatsapp(value);
        break;
      // case "type":
      //     setType(value);
      //     setContype(false);
      //     break;
      case 'customer_category':
        setCustomerCategory(value);
        break;
      case 'bank_name':
        setBankName(value);
        break;
      case 'ifsc_code':
        setBankIfscCode(value);
        break;
      case 'branch_name':
        setBranchName(value);
        break;
      case 'account_no':
        setAccountNumber(value);
        break;

      case 'anniversary_date':
        setAnniversaryDate(value);
        break;
      case 'transporter_id':
        setTransporterId(value);
        break;

      default:
        break;
    }
  };

  const handleDobChange = (
    event: React.ChangeEvent<HTMLInputElement | HTMLTextAreaElement>,
  ) => {
    setDob(event.target.value);
  };

  const handleSubmit = async (event: React.FormEvent<HTMLFormElement>) => {
    event.preventDefault();

    setClicked(true)

    // Validation checks

    // Transform addressList into the desired format
    const addressData = addressList.map((address: any) => ({
      gstType: address.gstType,
      gstIn: address.gstIn,
      panNumber: address.panNumber,
      contactFirstName: address.contactFirstName,
      contactLastName: address.contactLastName,
      contactCompanyName: address.contactCompanyName,
      contactNumber: address.contactNumber,
      contactEmail: address.contactEmail,
      addressLine1: address.addressLine1,
      addressLine2: address.addressLine2,
      country: address.country,
      state: address.state,
      city: address.city,
      pincode: address.pincode,
    }));

    const data = {
      contactType,

      contactDetails: {
        firstName,
        lastName,
        mobile,
        companyName,
        email,
        remarks,
        applyTds,

        customerCategory,
        anniversaryDate,
        dob,
        whatsapp,
        ...(current === 2 ? { bankIfscCode } : ""),
        ...(current === 2 ? { bankName } : ""),
        ...(current === 2 ? { branchName } : ""),
        ...(current === 2 ? { accountNumber } : ""),
        ...(current === 3 ? { transporterId } : ""),

      },

      address: addressData,
    };

    const token = localStorage.getItem('authorization');
    console.log('token', token);





    // Call the function to check for undefined GSTIN values in the array

    // Iterate over each object in the array
    addressData.forEach((obj, index) => {
      // Check if the gstIn property is undefined
      // console.log(obj)
      if (!obj.gstIn && !obj.country && !obj.state) {
        // Show error message for the object with undefined gstIn
        setFlag(true)
        console.log(flag)

      }


    });




    if (!firstName) {
      setFname(true);

      return;
    } else if (!type) {
      setContype(true);

      return;
    }
    console.log("sdkjfhj")

    try {
      const response = await axios.post(
        `${backendUrl}/api/user/contacts`,
        data,
        {
          headers: {
            Authorization: `${token}`,
          },
        },
      );


      console.log('response', response.status);

      if (response.status === 201) {
        setFirstName('');
        setLastName('');
        setCompanyName('');
        setCode('');
        setMobile('');
        setTelephoneNumber('');

        setEmail('');
        setRemarks('');
        setApplyTds(false);
        setCreditLimit('');
        setPaymentMode('');
        setPaymentTerms('');
        setDebitAmount('');
        setCreditAmount('');
        setWhatsapp('');
        setCode('');

        setCustomerCategory('');
        setType('');

        setAddressList([
          {
            gstType: '',
            gstIn: '',
            panNumber: '',
            contactFirstName: '',
            contactLastName: '',
            contactCompanyName: '',
            contactNumber: '',
            contactEmail: '',
            addressLine1: '',
            addressLine2: '',
            country: '',
            state: '',
            city: '',
            pinCode: '',
          },
        ]);
        setBankName('');
        setBranchName('');
        setAccountNumber('');
        setBankIfscCode('');
        setTransporterId('');
        setCurrent(1);
        setContactType('customer');
        setPanNumber('');
        // setPassword("")
        setRole('');

        toast.success('Contact Created Successfully');
        setGstin(false)
      }
    } catch (error) {
      console.log('error', error);
      console.log(error.response.status)

      if (error.response.status == 400) {
        toast.error(error.response.data.message)
      }

    }
  };

  const handleChecked = () => {
    setChecked(!checked);
    // console.log("check", checked)
  };

  // useEffect(() => {
  //   const handleNameFetch = async () => {
  //     try {
  //       const response = await axios.get(`${backendUrl}/api/user/${id}`, {
  //         headers: {
  //           Authorization: `${token}`,
  //         },
  //       });
  //     } catch (error) {
  //       console.log('error', error);
  //     }
  //   };

  //   handleNameFetch();
  // });

  return (
    <DefaultLayout>
      <Breadcrumb
        pageName={<h1 className="ml-[45px]">Create New Contact</h1>}
        icon={<img src={employee} alt="Employee icon" className=" ml-2" />}
        homeIcon={<FaHome />}
      />

      <div className=" min-h-screen m-[12px] rounded-[12px]">


        <Toaster />
        <div className="bg-white px-[20px] py-[12px] rounded-lg">
          <div className="flex justify-between">
            <div className="my-[10px]">
              <span className="text-black font-[500] ">Contact Type</span>
              <div className="flex gap-x-[32px] py-[12px] flex-wrap ">
                <div className="flex items-center mb-4">
                  <input
                    id="customer"
                    type="checkbox"
                    value={1}
                    checked={current === 1}
                    onChange={() => {
                      setCurrent(1),
                        setContactType('customer'),
                        console.log(contactType);
                    }}
                    defaultValue=""
                    className="w-4 h-4 text-blue-500 bg-gray-100 border-slate-300 "
                  />
                  <label
                    htmlFor="customer"
                    className="ms-2 text-sm font-medium text-black "
                  >
                    Customer
                  </label>
                </div>
                <div className="flex items-center mb-4">
                  <input
                    id="supplier"
                    type="checkbox"
                    value={2}
                    checked={current === 2}
                    onChange={() => {
                      setCurrent(2),
                        setContactType('supplier'),
                        console.log(contactType);
                    }}
                    defaultValue=""
                    className="w-4 h-4 text-blue-500 bg-gray-100 border-slate-300 "
                  />
                  <label
                    htmlFor="supplier"
                    className="ms-2 text-sm font-medium text-black "
                  >
                    Supplier/Vendor
                  </label>
                </div>
                <div className="flex items-center mb-4">
                  <input
                    id="transport"
                    type="checkbox"
                    value={3}
                    checked={current === 3}
                    onChange={() => {
                      setCurrent(3),
                        setContactType('transport'),
                        console.log(contactType);
                    }}
                    defaultValue=""
                    className="w-4 h-4 text-blue-500 bg-gray-100 border-slate-300 "
                  />
                  <label
                    htmlFor="transport"
                    className="ms-2 text-sm font-medium text-black "
                  >
                    Transport
                  </label>
                </div>
              </div>
            </div>
            <div>
              <label
                htmlFor="countries"
                className="block mb-2 text-sm font-medium text-black"
              >
                Select an option
              </label>
              <select
                id="countries"
                className="bg-white border border-slate-300 text-gray-900 text-sm rounded-lg  block w-full px-2 py-[5px] "
              >
                <option selected>Choose a country</option>
                <option value="US">United States</option>
                <option value="CA">Canada</option>
                <option value="FR">France</option>
                <option value="DE">Germany</option>
              </select>
            </div>
          </div>
        </div>
        <div className="bg-white px-[20px] py-[12px] rounded-lg my-[12px]">
          <div className="border-b border-slate-300">
            <span className="text-[16px] font-[500] text-[#2ac3df] py-[25px]">
              General Details
            </span>
          </div>
          <div className="flex gap-[12px] flex-wrap my-[23px]">
            {/* Name */}
            <div>
              <label
                htmlFor="first_name"
                className="block mb-2 text-sm font-[500] text-black"
              >
                First Name
              </label>
              <input
                type="text"
                id="first_name"
                value={firstName}
                onChange={handleChange}
                className={`bg-gray-50 border rounded-lg  ${fname ? 'border-red-500' : 'border-slate-300'
                  }  text-black text-sm  block w-full px-2 py-[5px] outline-none`}
                placeholder="First Name"
                required
              />
              {fname ? <p className="text-red-500 text-[14px]">Enter Your First Name !</p> : ''}
            </div>
            <div>
              <label
                htmlFor="last_name"
                className="block mb-2 text-sm font-[500] text-black"
              >
                Last Name
              </label>
              <input
                type="text"
                id="last_name"
                value={lastName}
                onChange={handleChange}
                className="bg-gray-50 rounded-lg border border-slate-300 text-black text-sm  block w-full px-2 py-[5px] outline-none"
                placeholder="Last Name"
                required
              />
            </div>
            <div>
              <label
                htmlFor="company_name"
                className="block mb-2 text-sm font-[500] text-black"
              >
                Company Name
              </label>
              <div className="flex gap-[10px]">
                <input
                  type="text"
                  id="company_name"
                  value={companyName}
                  onChange={handleChange}
                  className="bg-gray-50 rounded-lg border border-slate-300 text-black text-sm  block w-full px-2 py-[5px] outline-none"
                  placeholder="Company Name"
                  required
                />
                <input
                  type="text"
                  id="code"
                  className="bg-gray-50 rounded-lg border border-slate-300 text-black text-sm  block w-[30%] px-2 py-[5px] outline-none"
                  placeholder="Code"
                  required
                />
              </div>
            </div>
            {/* Mobile Number */}
            <div>
              <label
                htmlFor="mobile"
                className="block mb-2 text-sm font-[500] text-black"
              >
                Mobile No.
              </label>
              <input
                type="text"
                id="mobile"
                value={mobile}
                onChange={handleChange}
                className="bg-gray-50 rounded-lg border border-slate-300 text-black text-sm  block w-full px-2 py-[5px] outline-none"
                placeholder="Mobile No."
                required
              />
            </div>

            <div>
              <label
                htmlFor="telephone_no"
                className="block mb-2 text-sm font-[500] text-black"
              >
                Telephone No.
              </label>
              <input
                type="text"
                id="telephone_no"
                className="bg-gray-50 rounded-lg border border-slate-300 text-black text-sm  block w-full px-2 py-[5px] outline-none"
                placeholder="Telephone No."
                required
              />
            </div>
            {/* Email */}
            <div>
              <label
                htmlFor="email"
                className="block mb-2 text-sm font-[500] text-black"
              >
                Email
              </label>
              <input
                type="email"
                id="email"
                value={email}
                onChange={handleChange}
                className="bg-gray-50 rounded-lg border border-slate-300 text-black text-sm  block w-full px-2 py-[5px] outline-none"
                placeholder="email"
                required
              />
            </div>

            <div>
              <label
                htmlFor="remarks"
                className="block mb-2 text-sm font-[500] text-black"
              >
                Remarks
              </label>
              <div className="flex items-center gap-[10px]">
                <input
                  type="text"
                  id="remarks"
                  value={remarks}
                  onChange={handleChange}
                  className="bg-gray-50 rounded-lg border border-slate-300 text-black text-sm  block w-full px-2 py-[5px] outline-none"
                  placeholder="Remarks"
                  required
                />

                <div className="flex items-center ">
                  <input
                    id="apply_tds"
                    type="checkbox"
                    checked={checked}
                    onChange={handleChecked}
                    defaultValue=""
                    className="w-4 h-4 text-blue-500 bg-gray-100 border-slate-300 outline-none"
                  />
                  <label
                    htmlFor="apply_tds"
                    className="ms-2 text-sm font-medium text-slate-800 whitespace-nowrap"
                  >
                    Apply TDS
                  </label>
                </div>
              </div>
            </div>

            <div>
              <label
                htmlFor="credit_limit"
                className="block mb-2 text-sm font-[500] text-black"
              >
                Credit Limit
              </label>
              <input
                type="text"
                id="credit_limit"
                value={creditLimit}
                onChange={handleChange}
                className="bg-gray-50 rounded-lg border border-slate-300 text-black text-sm  block w-full px-2 py-[5px] outline-none"
                placeholder="Add Min Credit Limit"
                required
              />
            </div>

            <div>
              <label
                htmlFor="payment_mode"
                className="block mb-2 text-sm font-medium text-black"
              >
                Payment Mode
              </label>
              <select
                id="payment_mode"
                value={paymentMode}
                onChange={handleChange}
                className="bg-white border border-slate-300 text-gray-900 text-sm rounded-lg  block w-full px-2 py-[5px] "
              >
                <option selected>Select Payment Mode</option>
                <option value="cash">Cash</option>
                <option value="cheque">Cheque</option>
                <option value="dds">DDS</option>
                <option value="DE">E-Commerce Operator</option>
                <option value="DE">UIN Holders</option>
              </select>
            </div>
            <div>
              <label
                htmlFor="paymentTerms"
                className="block mb-2 text-sm font-medium text-black"
              >
                Payment Terms
              </label>
              <select
                id="payment_terms"
                value={paymentTerms}
                onChange={handleChange}
                className="bg-white border border-slate-300 text-gray-900 text-sm rounded-lg  block w-full px-2 py-[5px] "
              >
                <option selected>Select Payment Terms</option>
                <option value="7 days">7 days</option>
                <option value="15 days">15 days</option>
                <option value="30 days">30 days</option>
                <option value="60 days">60 days</option>
              </select>
            </div>

            <div>
              <label
                htmlFor="opening balance"
                className="block mb-2 text-sm font-[500] text-black"
              >
                Opening Balance
              </label>
              <div className="flex gap-[10px]">
                <input
                  type="text"
                  id="debit_amount"
                  value={debitAmount}
                  onChange={handleChange}
                  className="bg-gray-50 rounded-lg border border-slate-300 text-black text-sm  block w-[40%] px-2 py-[5px] outline-none"
                  placeholder="Debit Amount"
                  required
                />
                <input
                  type="text"
                  id="credit_amount"
                  value={creditAmount}
                  onChange={handleChange}
                  className="bg-gray-50 rounded-lg border border-slate-300 text-black text-sm  block w-[40%] px-2 py-[5px] outline-none"
                  placeholder="Credit Amount"
                  required
                />
              </div>
            </div>

            {current === 1 && (
              <div className="flex gap-[12px] flex-wrap ">
                {/* first */}
                <div>
                  <label
                    htmlFor="whatsapp_no"
                    className="block mb-2 text-sm font-medium text-black"
                  >
                    WhatsApp No.
                  </label>
                  <input
                    type="text"
                    id="whatsapp_no"
                    value={whatsapp}
                    onChange={handleChange}
                    className="bg-gray-50 rounded-lg border border-slate-300 text-black text-sm  block w-full px-2 py-[5px] outline-none"
                    placeholder="WhatsApp No"
                    required
                  />
                </div>

                <div>
                  <label className="mb-2 block text-sm font-medium text-black ">
                    Date of Birth
                  </label>
                  <input
                    type="date"
                    id="date_of_birth"
                    value={dob}
                    onChange={(e) => setDob(e.target.value)}
                    className="bg-gray-50 rounded-lg border border-slate-300 text-black text-sm  block w-full px-2 py-[5px] outline-none"

                    required
                  />
                </div>
                <div>
                  <label className="mb-2 block text-sm font-medium text-black ">
                    Anniversary Date
                  </label>
                  <input
                    type="date"
                    id="anniversary_date"
                    value={anniversaryDate}
                    onChange={handleChange}
                    className="bg-gray-50 rounded-lg border border-slate-300 text-black text-sm  block w-full px-2 py-[5px] outline-none"

                    required
                  />
                </div>
                <div>
                  <label
                    htmlFor="customer category"
                    className="block mb-2 text-sm font-medium text-black"
                  >
                    Customer Category
                  </label>
                  <select
                    id="customer_category"
                    value={customerCategory}
                    onChange={handleChange}
                    className="bg-white border border-slate-300 text-gray-900 text-sm rounded-lg  block w-full px-2 py-[5px] "
                  >
                    <option selected>Select Customer Category</option>
                    <option value="Retailer">Retailer</option>
                    <option value="Wholesaler">Wholesaler</option>
                    <option value="Other">Other</option>
                    <option value="Merchant">Merchant</option>
                    <option value="Manufacturer">Manufacturer</option>
                    <option value="Stockiest">Stockiest</option>
                    <option value="Trader">Trader</option>
                  </select>
                </div>
                <div>
                  <label
                    htmlFor="customer category"
                    className="block mb-2 text-sm font-medium text-black"
                  >
                    Select Type
                  </label>
                  <select
                    id="customer_category"
                    value={type}
                    onChange={(e) => {
                      setType(e.target.value), setContype(false);
                    }}
                    className={`bg-white border ${contype ? 'border-red-500' : 'border-slate-300'
                      }  text-gray-900 text-sm rounded-lg  block w-full px-2 py-[5px] `}
                  >
                    <option selected>Select Type</option>
                    <option value="Retailer">Retailer</option>
                    <option value="Wholesaler">Wholesaler</option>
                    <option value="Other">Other</option>
                    <option value="Merchant">Merchant</option>
                    <option value="Manufacturer">Manufacturer</option>
                    <option value="Stockiest">Stockiest</option>
                    <option value="Trader">Trader</option>
                  </select>
                  {contype ? (
                    <p className="text-red-500 text-[14px]">Select The Type !</p>
                  ) : (
                    ''
                  )}
                </div>
              </div>
            )}
            {current === 2 && (
              <div className="flex gap-[12px] flex-wrap">
                {/* second */}
                <div>
                  <label
                    htmlFor="whatsapp_no"
                    className="block mb-2 text-sm font-medium text-black"
                  >
                    WhatsApp No.
                  </label>
                  <input
                    type="text"
                    id="whatsapp_no"
                    value={whatsapp}
                    onChange={handleChange}
                    className="bg-gray-50 rounded-lg border border-slate-300 text-black text-sm  block w-full px-2 py-[5px] outline-none"
                    placeholder="WhatsApp No"
                    required
                  />
                </div>

                <div>
                  <label className="mb-2 block text-sm font-medium text-black ">
                    Date of Birth
                  </label>
                  <div className="relative">
                    <input
                      className="form-datepicker w-full rounded-lg border-[1.5px] border-slate-300 bg-transparent px-3 py-1 font-normal outline-none transition "
                      placeholder="Date of Birth"
                      data-class="flatpickr-right"
                    />

                    <div className="pointer-events-none absolute inset-0 left-auto right-5 flex items-center">
                      <svg
                        width="18"
                        height="18"
                        viewBox="0 0 18 18"
                        fill="none"
                        xmlns="http://www.w3.org/2000/svg"
                      >
                        <path
                          d="M15.7504 2.9812H14.2879V2.36245C14.2879 2.02495 14.0066 1.71558 13.641 1.71558C13.2754 1.71558 12.9941 1.99683 12.9941 2.36245V2.9812H4.97852V2.36245C4.97852 2.02495 4.69727 1.71558 4.33164 1.71558C3.96602 1.71558 3.68477 1.99683 3.68477 2.36245V2.9812H2.25039C1.29414 2.9812 0.478516 3.7687 0.478516 4.75308V14.5406C0.478516 15.4968 1.26602 16.3125 2.25039 16.3125H15.7504C16.7066 16.3125 17.5223 15.525 17.5223 14.5406V4.72495C17.5223 3.7687 16.7066 2.9812 15.7504 2.9812ZM1.77227 8.21245H4.16289V10.9968H1.77227V8.21245ZM5.42852 8.21245H8.38164V10.9968H5.42852V8.21245ZM8.38164 12.2625V15.0187H5.42852V12.2625H8.38164V12.2625ZM9.64727 12.2625H12.6004V15.0187H9.64727V12.2625ZM9.64727 10.9968V8.21245H12.6004V10.9968H9.64727ZM13.8379 8.21245H16.2285V10.9968H13.8379V8.21245ZM2.25039 4.24683H3.71289V4.83745C3.71289 5.17495 3.99414 5.48433 4.35977 5.48433C4.72539 5.48433 5.00664 5.20308 5.00664 4.83745V4.24683H13.0504V4.83745C13.0504 5.17495 13.3316 5.48433 13.6973 5.48433C14.0629 5.48433 14.3441 5.20308 14.3441 4.83745V4.24683H15.7504C16.0316 4.24683 16.2566 4.47183 16.2566 4.75308V6.94683H1.77227V4.75308C1.77227 4.47183 1.96914 4.24683 2.25039 4.24683ZM1.77227 14.5125V12.2343H4.16289V14.9906H2.25039C1.96914 15.0187 1.77227 14.7937 1.77227 14.5125ZM15.7504 15.0187H13.8379V12.2625H16.2285V14.5406C16.2566 14.7937 16.0316 15.0187 15.7504 15.0187Z"
                          fill="#64748B"
                        />
                      </svg>
                    </div>
                  </div>
                </div>
                <div>
                  <label className="mb-2 block text-sm font-medium text-black ">
                    Anniversary Date
                  </label>
                  <div className="relative">
                    <input
                      className="form-datepicker w-full rounded-lg border-[1.5px] border-slate-300 bg-transparent px-3 py-1 font-normal outline-none transition "
                      placeholder="Anniversary Date"
                      data-class="flatpickr-right"
                    />

                    <div className="pointer-events-none absolute inset-0 left-auto right-5 flex items-center">
                      <svg
                        width="18"
                        height="18"
                        viewBox="0 0 18 18"
                        fill="none"
                        xmlns="http://www.w3.org/2000/svg"
                      >
                        <path
                          d="M15.7504 2.9812H14.2879V2.36245C14.2879 2.02495 14.0066 1.71558 13.641 1.71558C13.2754 1.71558 12.9941 1.99683 12.9941 2.36245V2.9812H4.97852V2.36245C4.97852 2.02495 4.69727 1.71558 4.33164 1.71558C3.96602 1.71558 3.68477 1.99683 3.68477 2.36245V2.9812H2.25039C1.29414 2.9812 0.478516 3.7687 0.478516 4.75308V14.5406C0.478516 15.4968 1.26602 16.3125 2.25039 16.3125H15.7504C16.7066 16.3125 17.5223 15.525 17.5223 14.5406V4.72495C17.5223 3.7687 16.7066 2.9812 15.7504 2.9812ZM1.77227 8.21245H4.16289V10.9968H1.77227V8.21245ZM5.42852 8.21245H8.38164V10.9968H5.42852V8.21245ZM8.38164 12.2625V15.0187H5.42852V12.2625H8.38164V12.2625ZM9.64727 12.2625H12.6004V15.0187H9.64727V12.2625ZM9.64727 10.9968V8.21245H12.6004V10.9968H9.64727ZM13.8379 8.21245H16.2285V10.9968H13.8379V8.21245ZM2.25039 4.24683H3.71289V4.83745C3.71289 5.17495 3.99414 5.48433 4.35977 5.48433C4.72539 5.48433 5.00664 5.20308 5.00664 4.83745V4.24683H13.0504V4.83745C13.0504 5.17495 13.3316 5.48433 13.6973 5.48433C14.0629 5.48433 14.3441 5.20308 14.3441 4.83745V4.24683H15.7504C16.0316 4.24683 16.2566 4.47183 16.2566 4.75308V6.94683H1.77227V4.75308C1.77227 4.47183 1.96914 4.24683 2.25039 4.24683ZM1.77227 14.5125V12.2343H4.16289V14.9906H2.25039C1.96914 15.0187 1.77227 14.7937 1.77227 14.5125ZM15.7504 15.0187H13.8379V12.2625H16.2285V14.5406C16.2566 14.7937 16.0316 15.0187 15.7504 15.0187Z"
                          fill="#64748B"
                        />
                      </svg>
                    </div>
                  </div>
                </div>

                <div>
                  <label
                    htmlFor="bank_name"
                    className="block mb-2 text-sm font-medium text-black"
                  >
                    Bank Name
                  </label>
                  <input
                    type="text"
                    id="bank_name"
                    value={bankName}
                    onChange={handleChange}
                    className="bg-gray-50 rounded-lg border border-slate-300 text-black text-sm  block w-full px-2 py-[5px] outline-none"
                    placeholder="Bank Name"
                    required
                  />
                </div>
                <div>
                  <label
                    htmlFor="ifsc_code"
                    className="block mb-2 text-sm font-medium text-black"
                  >
                    Bank IFSC Code
                  </label>
                  <input
                    type="text"
                    id="ifsc_code"
                    value={bankIfscCode}
                    onChange={handleChange}
                    className="bg-gray-50 rounded-lg border border-slate-300 text-black text-sm  block w-full px-2 py-[5px] outline-none"
                    placeholder="IFSC Code"
                    required
                  />
                </div>
                <div>
                  <label
                    htmlFor="branch_name"
                    className="block mb-2 text-sm font-medium text-black"
                  >
                    Branch Name
                  </label>
                  <input
                    type="text"
                    id="branch_name"
                    value={branchName}
                    onChange={handleChange}
                    className="bg-gray-50 rounded-lg border border-slate-300 text-black text-sm  block w-full px-2 py-[5px] outline-none"
                    placeholder="Branch Name"
                    required
                  />
                </div>
                <div>
                  <label
                    htmlFor="account_no"
                    className="block mb-2 text-sm font-medium text-black"
                  >
                    Account No.
                  </label>
                  <input
                    type="text"
                    id="account_no"
                    value={accountNumber}
                    onChange={handleChange}
                    className="bg-gray-50 rounded-lg border border-slate-300 text-black text-sm  block w-full px-2 py-[5px] outline-none"
                    placeholder="Account No"
                    required
                  />
                </div>

                <div>
                  <label
                    htmlFor="customer category"
                    className="block mb-2 text-sm font-medium text-black"
                  >
                    Select Type
                  </label>
                  <select
                    id="customer_category"
                    value={type}
                    onChange={handleChange}
                    className="bg-white border border-slate-300 text-gray-900 text-sm rounded-lg  block w-full px-2 py-[5px] "
                  >
                    <option selected>Select Type</option>
                    <option value="Retailer">Retailer</option>
                    <option value="Wholesaler">Wholesaler</option>
                    <option value="Other">Other</option>
                    <option value="Merchant">Merchant</option>
                    <option value="Manufacturer">Manufacturer</option>
                    <option value="Stockiest">Stockiest</option>
                    <option value="Trader">Trader</option>
                  </select>
                </div>
              </div>
            )}

            {current === 3 && (
              <div className="flex gap-[12px] flex-wrap">
                <div>
                  <label className="mb-2 block text-sm font-medium text-black ">
                    Date of Birth
                  </label>
                  <div className="relative">
                    <input
                      className="form-datepicker w-full rounded-lg border-[1.5px] border-slate-300 bg-transparent px-3 py-1 font-normal outline-none transition "
                      placeholder="Date of Birth"
                      data-class="flatpickr-right"
                    />

                    <div className="pointer-events-none absolute inset-0 left-auto right-5 flex items-center">
                      <svg
                        width="18"
                        height="18"
                        viewBox="0 0 18 18"
                        fill="none"
                        xmlns="http://www.w3.org/2000/svg"
                      >
                        <path
                          d="M15.7504 2.9812H14.2879V2.36245C14.2879 2.02495 14.0066 1.71558 13.641 1.71558C13.2754 1.71558 12.9941 1.99683 12.9941 2.36245V2.9812H4.97852V2.36245C4.97852 2.02495 4.69727 1.71558 4.33164 1.71558C3.96602 1.71558 3.68477 1.99683 3.68477 2.36245V2.9812H2.25039C1.29414 2.9812 0.478516 3.7687 0.478516 4.75308V14.5406C0.478516 15.4968 1.26602 16.3125 2.25039 16.3125H15.7504C16.7066 16.3125 17.5223 15.525 17.5223 14.5406V4.72495C17.5223 3.7687 16.7066 2.9812 15.7504 2.9812ZM1.77227 8.21245H4.16289V10.9968H1.77227V8.21245ZM5.42852 8.21245H8.38164V10.9968H5.42852V8.21245ZM8.38164 12.2625V15.0187H5.42852V12.2625H8.38164V12.2625ZM9.64727 12.2625H12.6004V15.0187H9.64727V12.2625ZM9.64727 10.9968V8.21245H12.6004V10.9968H9.64727ZM13.8379 8.21245H16.2285V10.9968H13.8379V8.21245ZM2.25039 4.24683H3.71289V4.83745C3.71289 5.17495 3.99414 5.48433 4.35977 5.48433C4.72539 5.48433 5.00664 5.20308 5.00664 4.83745V4.24683H13.0504V4.83745C13.0504 5.17495 13.3316 5.48433 13.6973 5.48433C14.0629 5.48433 14.3441 5.20308 14.3441 4.83745V4.24683H15.7504C16.0316 4.24683 16.2566 4.47183 16.2566 4.75308V6.94683H1.77227V4.75308C1.77227 4.47183 1.96914 4.24683 2.25039 4.24683ZM1.77227 14.5125V12.2343H4.16289V14.9906H2.25039C1.96914 15.0187 1.77227 14.7937 1.77227 14.5125ZM15.7504 15.0187H13.8379V12.2625H16.2285V14.5406C16.2566 14.7937 16.0316 15.0187 15.7504 15.0187Z"
                          fill="#64748B"
                        />
                      </svg>
                    </div>
                  </div>
                </div>
                <div>
                  <label className="mb-2 block text-sm font-medium text-black ">
                    Anniversary Date
                  </label>
                  <div className="relative">
                    <input
                      className="form-datepicker w-full rounded-lg border-[1.5px] border-slate-300 bg-transparent px-3 py-1 font-normal outline-none transition "
                      placeholder="Anniversary Date"
                      data-class="flatpickr-right"
                    />

                    <div className="pointer-events-none absolute inset-0 left-auto right-5 flex items-center">
                      <svg
                        width="18"
                        height="18"
                        viewBox="0 0 18 18"
                        fill="none"
                        xmlns="http://www.w3.org/2000/svg"
                      >
                        <path
                          d="M15.7504 2.9812H14.2879V2.36245C14.2879 2.02495 14.0066 1.71558 13.641 1.71558C13.2754 1.71558 12.9941 1.99683 12.9941 2.36245V2.9812H4.97852V2.36245C4.97852 2.02495 4.69727 1.71558 4.33164 1.71558C3.96602 1.71558 3.68477 1.99683 3.68477 2.36245V2.9812H2.25039C1.29414 2.9812 0.478516 3.7687 0.478516 4.75308V14.5406C0.478516 15.4968 1.26602 16.3125 2.25039 16.3125H15.7504C16.7066 16.3125 17.5223 15.525 17.5223 14.5406V4.72495C17.5223 3.7687 16.7066 2.9812 15.7504 2.9812ZM1.77227 8.21245H4.16289V10.9968H1.77227V8.21245ZM5.42852 8.21245H8.38164V10.9968H5.42852V8.21245ZM8.38164 12.2625V15.0187H5.42852V12.2625H8.38164V12.2625ZM9.64727 12.2625H12.6004V15.0187H9.64727V12.2625ZM9.64727 10.9968V8.21245H12.6004V10.9968H9.64727ZM13.8379 8.21245H16.2285V10.9968H13.8379V8.21245ZM2.25039 4.24683H3.71289V4.83745C3.71289 5.17495 3.99414 5.48433 4.35977 5.48433C4.72539 5.48433 5.00664 5.20308 5.00664 4.83745V4.24683H13.0504V4.83745C13.0504 5.17495 13.3316 5.48433 13.6973 5.48433C14.0629 5.48433 14.3441 5.20308 14.3441 4.83745V4.24683H15.7504C16.0316 4.24683 16.2566 4.47183 16.2566 4.75308V6.94683H1.77227V4.75308C1.77227 4.47183 1.96914 4.24683 2.25039 4.24683ZM1.77227 14.5125V12.2343H4.16289V14.9906H2.25039C1.96914 15.0187 1.77227 14.7937 1.77227 14.5125ZM15.7504 15.0187H13.8379V12.2625H16.2285V14.5406C16.2566 14.7937 16.0316 15.0187 15.7504 15.0187Z"
                          fill="#64748B"
                        />
                      </svg>
                    </div>
                  </div>
                </div>
                <div>
                  <label
                    htmlFor="debit_amount"
                    className="block mb-2 text-sm font-[500] text-black"
                  >
                    Transporter ID
                  </label>

                  <input
                    type="text"
                    id="transporter_id"
                    value={transporterId}
                    onChange={handleChange}
                    className="bg-gray-50 rounded-lg border border-slate-300 text-black text-sm  block w-full px-2 py-[5px] outline-none"
                    placeholder="Transporter ID"
                    required
                  />
                </div>
              </div>
            )}
          </div>
        </div>

        <div className="bg-white px-[20px] py-[12px] rounded-lg my-[12px]">
          <div className="border-b border-slate-300">
            <span className="text-[16px] font-[500] text-[#2ac3df] py-[25px]">
              Address Details
            </span>
          </div>
          {addressList.map((address: any, index: number) => (
            <div key={index} className="flex gap-[12px] my-[32px] flex-wrap">
              {/*Bank Name */}
              <div>
                <label
                  htmlFor="gst_type"
                  className="block mb-2 text-sm font-medium text-black"
                >
                  GST Type
                </label>
                <select
                  id={`gst_type_${index}_${Date.now()}`}
                  name="gstType"
                  value={address.gstType}
                  onChange={(e) => handleInputChange(e, index)}
                  className="bg-white border border-slate-300 text-gray-900 text-sm rounded-lg  block w-full px-2 py-[5px] "
                >
                  <option selected value="unRegistered">
                    Un Registered
                  </option>
                  <option value="Registered Regular">
                    Registered Regular
                  </option>
                  <option value="Registered Composition">
                    Registered Composition
                  </option>
                  <option value="Input Service Distributor">
                    Input Service Distributor
                  </option>
                  <option value="E-commerce Operator">
                    E-Commerce Operator
                  </option>
                  <option value="UIN Holders">UIN Holders</option>
                </select>
              </div>

              <div>
                <label
                  htmlFor="gstin"
                  className="block mb-2 text-sm font-medium text-black"
                >
                  GSTIN
                </label>
                <input
                  type="text"
                  id={`gstin_type_${index}_${Date.now()}`}
                  name="gstIn"
                  value={address.gstIn}
                  onChange={(e) => {
                    handleInputChange(e, index);
                  }}
                  className={`"bg-gray-50 rounded-lg border ${!address.gstIn && Clicked ? 'border-red-500' : 'border-slate-300'
                    } text-black text-sm  block w-full px-2 py-[5px] outline-none`}
                  placeholder="GSTIN"
                />

                {!address.gstIn && Clicked ? (
                  <p className="text-red-500 text-[14px]">Enter GSTIN</p>
                ) : (
                  ''
                )}
              </div>
              <div>
                <label
                  htmlFor="pan_no"
                  className="block mb-2 text-sm font-medium text-black"
                >
                  Pan No.
                </label>
                <input
                  type="text"
                  id="pan_no"
                  name="panNumber"
                  value={address.panNumber}
                  onChange={(e) => handleInputChange(e, index)}
                  className="bg-gray-50 border rounded-lg border-slate-300 text-black text-sm  block w-full px-2 py-[5px] outline-none"
                  placeholder="PAN No."
                  required
                />
              </div>
              {/* Mobile Number */}
              <div>
                <label
                  htmlFor="contact_first_name"
                  className="block mb-2 text-sm font-medium text-black"
                >
                  Contact First Name
                </label>
                <input
                  type="text"
                  id="contact_first_name"
                  name="contactFirstName"
                  value={address.contactFirstName}
                  onChange={(e) => handleInputChange(e, index)}
                  className="bg-gray-50 border rounded-lg border-slate-300 text-black text-sm  block w-full px-2 py-[5px] outline-none"
                  placeholder="Contact First Name"
                  required
                />
              </div>
              {/* Email */}
              <div>
                <label
                  htmlFor="contact_last_name"
                  className="block mb-2 text-sm font-medium text-black"
                >
                  Contact Last Name
                </label>
                <input
                  type="text"
                  id="contact_last_name"
                  name="contactLastName"
                  value={address.contactLastName}
                  onChange={(e) => handleInputChange(e, index)}
                  className="bg-gray-50 border rounded-lg border-slate-300 text-black text-sm  block w-full px-2 py-[5px] outline-none"
                  placeholder="Contact Last Name"
                  required
                />
              </div>
              {/* Pan Number */}
              <div>
                <label
                  htmlFor="contact_company_name"
                  className="block mb-2 text-sm font-medium text-black"
                >
                  Contact Company Name
                </label>
                <input
                  type="text"
                  id="contact_company_name"
                  name="contactCompanyName"
                  value={address.contactCompanyName}
                  onChange={(e) => handleInputChange(e, index)}
                  className="bg-gray-50 border rounded-lg border-slate-300 text-black text-sm  block w-full px-2 py-[5px] outline-none"
                  placeholder="Contact Company Name"
                  required
                />
              </div>

              {/* Name */}
              <div>
                <label
                  htmlFor="contact_no"
                  className="block mb-2 text-sm font-medium text-black"
                >
                  Contact No.
                </label>
                <input
                  type="text"
                  id="contact_no"
                  name="contactNumber"
                  value={address.contactNumber}
                  onChange={(e) => handleInputChange(e, index)}
                  className="bg-gray-50 border rounded-lg border-slate-300 text-black text-sm  block w-full px-2 py-[5px] outline-none"
                  placeholder="Contact Number"
                  required
                />
              </div>

              {/* Email */}
              <div>
                <label
                  htmlFor="contact_email"
                  className="block mb-2 text-sm font-medium text-black"
                >
                  Contact Email
                </label>
                <input
                  type="text"
                  id="contact_email"
                  name="contactEmail"
                  value={address.contactEmail}
                  onChange={(e) => handleInputChange(e, index)}
                  className="bg-gray-50 border rounded-lg border-slate-300 text-black text-sm  block w-full px-2 py-[5px]  outline-none"
                  placeholder="Contact Email"
                  required
                />
              </div>
              {/* Pan Number */}
              <div>
                <label
                  htmlFor="address_line_1"
                  className="block mb-2 text-sm font-medium text-black"
                >
                  Address Line 1
                </label>
                <textarea
                  id="address_line_1"
                  name="addressLine1"
                  value={address.addressLine1}
                  onChange={(e) => handleInputChange(e, index)}
                  rows={4}
                  className="block rounded-lg px-2 py-[5px].5 min-w-[330px] max-h-[33px] text-sm text-gray-900 bg-gray-50  border border-slate-300 outline-none"
                  placeholder="Address"
                  defaultValue={''}
                />
              </div>
              <div>
                <label
                  htmlFor="address_line_2"
                  className="block mb-2 text-sm font-medium text-black"
                >
                  Address Line 2
                </label>
                <textarea
                  id="address_line_2"
                  name="addressLine2"
                  value={address.addressLine2}
                  onChange={(e) => handleInputChange(e, index)}
                  rows={4}
                  className="block rounded-lg px-2 py-[5px].5 min-w-[330px] max-h-[33px] text-sm text-gray-900 bg-gray-50  border border-slate-300 outline-none"
                  placeholder="Address"
                  defaultValue={''}
                />
              </div>

              {/* country */}
              <div className="max-h-[200px]">
                <label
                  htmlFor="country"
                  className="block mb-2 text-sm font-medium text-black "
                >
                  Select a Country
                </label>
                <select
                  id="country"
                  name="country"
                  value={address.country} // Make sure to bind value to the state variable
                  className={`bg-white border ${!address.country && Clicked ? "border-red-500" : "border-slate-300"}  text-black text-sm rounded-lg block w-full px-2 py-[5px] `}
                  onChange={(e) => handleInputChange(e, index)}
                >
                  <option value="">Select a Country</option>
                  {CountryData.map((data) => (
                    <option key={data.id} value={data.country}>
                      {data.country}
                    </option>
                  ))}
                </select>
                {
                  !address.country && Clicked ? <p className='text-[14px] text-red-500'>Select Country !</p> : ""
                }
              </div>
              {/* State */}
              <div className="max-h-[200px]">
                <label
                  htmlFor="state"
                  className="block mb-2 text-sm font-medium text-black "
                >
                  Select a state
                </label>
                <select
                  id="state"
                  name="state"
                  value={address.state} // Make sure to bind value to the state variable
                  className={`bg-white border  ${!address.state && Clicked ? "border-red-500" : "border-slate-300"} text-black text-sm rounded-lg block w-full px-2 py-[5px]`}
                  onChange={(e) => handleInputChange(e, index)}
                >
                  <option value="">Select a state</option>
                  {StateData.map((data) => (
                    <option key={data.id} value={data.state}>
                      {data.state}
                    </option>
                  ))}
                </select>
                {
                  !address.state && Clicked ? <p className='text-red-500 text-[14px]'>Select State !</p> : ""
                }
              </div>
              {/* State */}
              <div className="max-h-[200px]">
                <label
                  htmlFor="city"
                  className="block mb-2 text-sm font-medium text-black "
                >
                  Select a City
                </label>
                <select
                  id="city"
                  name="city"
                  value={address.city} // Make sure to bind value to the state variable
                  className={`bg-white border ${!address.city && Clicked ? "border-red-500" : "border-slate-300"}  text-black text-sm rounded-lg block w-full px-2 py-[5px] `}
                  onChange={(e) => handleInputChange(e, index)}
                >
                  <option value="">Select a City</option>
                  {StateData.map((data) => (
                    <option key={data.id} value={data.state}>
                      {data.state}
                    </option>
                  ))}
                </select>
                {
                  !address.city && Clicked ? <p className='text-red-500 text-[14px]' >Select City !</p> : ""
                }
              </div>

              {/* Zip / postal Code */}
              <div>
                <label
                  htmlFor="zip"
                  className="block mb-2 text-sm font-medium text-black"
                >
                  ZIP / Postal Code
                </label>
                <input
                  type="text"
                  id="zip"
                  name="pincode"
                  value={address.pincode}
                  onChange={(e) => handleInputChange(e, index)}
                  className="bg-gray-50 rounded-lg border border-slate-300 text-black text-sm  block w-full px-2 py-[5px] outline-none"
                  placeholder="ZIP / Postal Code"
                  required
                />
              </div>
              {addressList.length > 1 && addressList.length !== 1 ? (
                <button
                  type="button"
                  onClick={() => handleRemove(index)}
                  className="text-red-600 text-[30px] mt-[25px]"
                >
                  <MdOutlineCancel />
                </button>
              ) : (
                ''
              )}

              {addressList.length - 1 === index && addressList.length < 4 && (
                <div>
                  <button
                    type="button"
                    onClick={handleAddClick}
                    className="text-[16px] underline font-[500] cursor-pointer text-[#2ac3df] py-[25px] flex items-center gap-[8px]"
                  >
                    <p className="border">
                      <FaPlus />
                    </p>
                    Add more address
                  </button>
                </div>
              )}
            </div>
          ))}

          <div className="my-[40px] flex justify-end gap-x-[12px]">
            <button
              type="button"
              className="text-red-500 border border-red-700 hover:bg-red-100/40 font-bold text-lg px-4 py-[2px] rounded-lg"
            >
              Cancel
            </button>
            <button
              type="button"
              onClick={handleSubmit}
              className="text-green-500 border border-green-700 hover:bg-green-100/40 font-bold text-lg px-4 py-[2px] me-2 rounded-lg"
            >
              Save
            </button>
          </div>
        </div>

      </div>
    </DefaultLayout>
  );
};

export default CreateContact;
