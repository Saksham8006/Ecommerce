import React, { useState } from 'react'
import DefaultLayout from '../../../layout/DefaultLayout'
import Breadcrumb from '../../../components/Breadcrumbs/Breadcrumb'
import { FaHome } from "react-icons/fa";
import Settings_sidebar from '../../../assets/Settings_sidebar.svg'
import Profile from './Profile/Profile';
import Taxes from './Taxes/Taxes';
import ReportFormats from './Report Formats/ReportFormats';
import UserRoles from './User Roles/UserRoles';
import Prefix from './Prefix/Prefix';
import PaymentTerms from './Payment Terms/PaymentTerms';
import AdditionalCharges from './Additional Charges/AdditionalCharges';
import ConsumptionType from './Consumption Type/ConsumptionType';
import Hardware from './Hardware/Hardware';
import { TbBrandPaypalFilled } from "react-icons/tb";
import ManageAccounts from './Manage Account/ManageAccount';
import { FaNotesMedical } from "react-icons/fa6";
import { MdAccountBalance } from "react-icons/md";
import { TbReport } from "react-icons/tb";
import { GrSettingsOption } from "react-icons/gr";

import { GrNotes } from "react-icons/gr";
import { FaUsersCog } from "react-icons/fa";
import { MdOutlineDomainAdd } from "react-icons/md";
import { GrUserManager } from "react-icons/gr";
import { IoHardwareChipSharp } from "react-icons/io5";




const GeneralSettings: React.FC = () => {
    const [current, setCurrent] = useState<number>(1);

    return (
        <DefaultLayout>
            <Breadcrumb
                pageName={<h1 className='ml-[42px] '>General Settings</h1>}
                icon={<img src={Settings_sidebar} alt="Inventory Settings icon" className='max-w-[50%] ml-2 mb-2' />}
                homeIcon={<span className=''><FaHome /></span>}
            />

            <div className='flex flex-row gap-[30px] '>

                <div className='flex flex-col gap-[4px]'>
                    <button type="button" onClick={() => setCurrent(1)} className={` ${current === 1 ? "border-[1.5px] border-black" : "border border-slate-300"} text-black  font-medium rounded-lg text-sm px-5 py-[4px] me-2 mb-2 ml-[20px] w-[200px]  bg-white flex items-center gap-[10px] `}><GrUserManager />Profile</button>
                    <button type="button" onClick={() => setCurrent(2)} className={` ${current === 2 ? "border-[1.5px] border-black" : "border border-slate-300"} text-black  font-medium rounded-lg text-sm px-5  py-[4px] me-2 mb-2 ml-[20px] w-[200px]  bg-white flex items-center gap-[10px] `}><GrNotes />Taxes</button>
                    <button type="button" onClick={() => setCurrent(3)} className={` ${current === 3 ? "border-[1.5px] border-black" : "border border-slate-300"} text-black  font-medium rounded-lg text-sm px-5  py-[4px]  me-2 mb-2 ml-[20px] w-[200px] bg-white flex items-center gap-[10px] `}><TbReport />Report Formats</button>
                    <button type="button" onClick={() => setCurrent(4)} className={` ${current === 4 ? "border-[1.5px] border-black" : "border border-slate-300"} text-black  font-medium rounded-lg text-sm px-5 py-[4px] me-2 mb-2 ml-[20px]  w-[200px]  bg-white flex items-center gap-[10px] `}><FaUsersCog />User Roles</button>
                    <button type="button" onClick={() => setCurrent(5)} className={` ${current === 5 ? "border-[1.5px] border-black" : "border border-slate-300"} text-black  font-medium rounded-lg text-sm px-5 py-[4px] me-2 mb-2 ml-[20px]  w-[200px]  bg-white flex items-center gap-[10px] `}><FaNotesMedical />Prefix</button>
                    <button type="button" onClick={() => setCurrent(6)} className={` ${current === 6 ? "border-[1.5px] border-black" : "border border-slate-300"} text-black  font-medium rounded-lg text-sm px-5 py-[4px] me-2 mb-2 ml-[20px] w-[200px]   bg-white flex items-center gap-[10px] `}><TbBrandPaypalFilled />Payment Terms</button>
                    <button type="button" onClick={() => setCurrent(7)} className={` ${current === 7 ? "border-[1.5px] border-black" : "border border-slate-300"} text-black  font-medium rounded-lg text-sm px-5 py-[4px] me-2 mb-2 ml-[20px] w-[200px]   bg-white flex items-center gap-[10px] `}><MdOutlineDomainAdd />Additional Charges</button>
                    <button type="button" onClick={() => setCurrent(8)} className={` ${current === 8 ? "border-[1.5px] border-black" : "border border-slate-300"} text-black  font-medium rounded-lg text-sm px-5 py-[4px] me-2 mb-2 ml-[20px] w-[200px]   bg-white flex items-center gap-[10px] `}><GrSettingsOption />Consumption Type</button>
                    <button type="button" onClick={() => setCurrent(9)} className={` ${current === 9 ? "border-[1.5px] border-black" : "border border-slate-300"} text-black  font-medium rounded-lg text-sm px-5 py-[4px] me-2 mb-2 ml-[20px] w-[200px]   bg-white flex items-center gap-[10px] `}><IoHardwareChipSharp />Hardware</button>
                    <button type="button" onClick={() => setCurrent(10)} className={` ${current === 10 ? "border-[1.5px] border-black" : "border border-slate-300"} text-black  font-medium rounded-lg text-sm px-5 py-[4px] me-2 mb-2 ml-[20px] w-[200px]   bg-white flex items-center gap-[10px] `}><MdAccountBalance />Manage Account</button>

                </div>

                <div className='w-full'>
                    {current === 1 &&
                        <Profile />
                    }
                    {current === 2 &&
                        <Taxes />
                    }
                    {current === 3 &&
                        <ReportFormats />
                    }
                    {current === 4 &&
                        <UserRoles />
                    }
                    {current === 5 &&
                        <Prefix />
                    }
                    {current === 6 &&
                        <PaymentTerms />
                    }
                    {current === 7 &&
                        <AdditionalCharges />
                    }
                    {current === 8 &&
                        <ConsumptionType />
                    }
                    {current === 9 &&
                        <Hardware />
                    }
                    {current === 10 &&
                        <ManageAccounts />
                    }

                </div>
            </div>
        </DefaultLayout>
    )
}
export default GeneralSettings