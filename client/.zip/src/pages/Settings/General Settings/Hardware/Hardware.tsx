import React, { useState } from 'react'



const Hardware: React.FC = () => {

    const [isChecked, setIsChecked] = useState<boolean>(false)



    return (
        <div className="mx-auto px-[24px] bg-white py-[24px] my-[24px] mb-[50px]">

            <div className='border-b border-slate-300'>
                <span className='text-[16px] font-[500] text-[#2ac3df] py-[25px]'>Advance Setting</span>
            </div>


            <div className="bg-white  relative  overflow-hidden mt-[40px]">
                <div className="">
                    <div className='grid grid-cols-2 gap-[15px] p-[24px]'>
                        <div className='flex justify-between  text-black font-medium  items-center gap-[20px]'>
                            <label>Is Touch Screen</label>
                            <label
                                htmlFor="sales_man"
                                className="flex items-center cursor-pointer "
                            >
                                <div className="relative">
                                    <input type="checkbox" id="sales_man" className="peer sr-only" />
                                    <div className="block h-[22px] rounded-full bg-slate-400  w-[50px]" />
                                    <div className="absolute flex items-center justify-center w-[24px] h-[20px] transition bg-white  rounded-full dot  left-[1px] top-[1px] peer-checked:translate-x-full peer-checked:bg-green-600">
                                        {isChecked === false ?

                                            <svg
                                                width={7}
                                                height={5}
                                                viewBox="0 0 11 8"
                                                fill="none"
                                                xmlns="http://www.w3.org/2000/svg"
                                            >
                                                <path
                                                    d="M10.0915 0.951972L10.0867 0.946075L10.0813 0.940568C9.90076 0.753564 9.61034 0.753146 9.42927 0.939309L4.16201 6.22962L1.58507 3.63469C1.40401 3.44841 1.11351 3.44879 0.932892 3.63584C0.755703 3.81933 0.755703 4.10875 0.932892 4.29224L0.932878 4.29225L0.934851 4.29424L3.58046 6.95832C3.73676 7.11955 3.94983 7.2 4.1473 7.2C4.36196 7.2 4.55963 7.11773 4.71406 6.9584L10.0468 1.60234C10.2436 1.4199 10.2421 1.1339 10.0915 0.951972ZM4.2327 6.30081L4.2317 6.2998C4.23206 6.30015 4.23237 6.30049 4.23269 6.30082L4.2327 6.30081Z"
                                                    fill="white"
                                                    stroke="white"
                                                    strokeWidth="0.4"
                                                />
                                            </svg>
                                            :

                                            <svg
                                                className="w-4 h-4 stroke-current"
                                                fill="none"
                                                viewBox="0 0 24 24"
                                                xmlns="http://www.w3.org/2000/svg"
                                            >
                                                <path
                                                    strokeLinecap="round"
                                                    strokeLinejoin="round"
                                                    strokeWidth={2}
                                                    d="M6 18L18 6M6 6l12 12"
                                                />
                                            </svg>

                                        }
                                    </div>
                                </div>
                            </label>
                        </div>

                        <div className='flex justify-between  text-black font-medium  items-center gap-[20px]'>
                            <label>Customer Facing Screen/Line Display</label>
                            <label
                                htmlFor="Qty"
                                className="flex items-center cursor-pointer "
                            >
                                <div className="relative">
                                    <input type="checkbox" id="Qty" className="peer sr-only" />
                                    <div className="block h-[22px] rounded-full bg-slate-400  w-[50px]" />
                                    <div className="absolute flex items-center justify-center w-[24px] h-[20px] transition bg-white  rounded-full dot  left-[1px] top-[1px] peer-checked:translate-x-full peer-checked:bg-green-600">
                                        {isChecked === false ?

                                            <svg
                                                width={11}
                                                height={8}
                                                viewBox="0 0 11 8"
                                                fill="none"
                                                xmlns="http://www.w3.org/2000/svg"
                                            >
                                                <path
                                                    d="M10.0915 0.951972L10.0867 0.946075L10.0813 0.940568C9.90076 0.753564 9.61034 0.753146 9.42927 0.939309L4.16201 6.22962L1.58507 3.63469C1.40401 3.44841 1.11351 3.44879 0.932892 3.63584C0.755703 3.81933 0.755703 4.10875 0.932892 4.29224L0.932878 4.29225L0.934851 4.29424L3.58046 6.95832C3.73676 7.11955 3.94983 7.2 4.1473 7.2C4.36196 7.2 4.55963 7.11773 4.71406 6.9584L10.0468 1.60234C10.2436 1.4199 10.2421 1.1339 10.0915 0.951972ZM4.2327 6.30081L4.2317 6.2998C4.23206 6.30015 4.23237 6.30049 4.23269 6.30082L4.2327 6.30081Z"
                                                    fill="white"
                                                    stroke="white"
                                                    strokeWidth="0.4"
                                                />
                                            </svg>
                                            :

                                            <svg
                                                className="w-4 h-4 stroke-current"
                                                fill="none"
                                                viewBox="0 0 24 24"
                                                xmlns="http://www.w3.org/2000/svg"
                                            >
                                                <path
                                                    strokeLinecap="round"
                                                    strokeLinejoin="round"
                                                    strokeWidth={2}
                                                    d="M6 18L18 6M6 6l12 12"
                                                />
                                            </svg>

                                        }
                                    </div>
                                </div>
                            </label>
                        </div>
                        <div className='flex justify-between  text-black font-medium  items-center gap-[20px]'>
                            <label>Weight Scale</label>
                            <label
                                htmlFor="Qty"
                                className="flex items-center cursor-pointer "
                            >
                                <div className="relative">
                                    <input type="checkbox" id="Qty" className="peer sr-only" />
                                    <div className="block h-[22px] rounded-full bg-slate-400  w-[50px]" />
                                    <div className="absolute flex items-center justify-center w-[24px] h-[20px] transition bg-white  rounded-full dot  left-[1px] top-[1px] peer-checked:translate-x-full peer-checked:bg-green-600">
                                        {isChecked === false ?

                                            <svg
                                                width={11}
                                                height={8}
                                                viewBox="0 0 11 8"
                                                fill="none"
                                                xmlns="http://www.w3.org/2000/svg"
                                            >
                                                <path
                                                    d="M10.0915 0.951972L10.0867 0.946075L10.0813 0.940568C9.90076 0.753564 9.61034 0.753146 9.42927 0.939309L4.16201 6.22962L1.58507 3.63469C1.40401 3.44841 1.11351 3.44879 0.932892 3.63584C0.755703 3.81933 0.755703 4.10875 0.932892 4.29224L0.932878 4.29225L0.934851 4.29424L3.58046 6.95832C3.73676 7.11955 3.94983 7.2 4.1473 7.2C4.36196 7.2 4.55963 7.11773 4.71406 6.9584L10.0468 1.60234C10.2436 1.4199 10.2421 1.1339 10.0915 0.951972ZM4.2327 6.30081L4.2317 6.2998C4.23206 6.30015 4.23237 6.30049 4.23269 6.30082L4.2327 6.30081Z"
                                                    fill="white"
                                                    stroke="white"
                                                    strokeWidth="0.4"
                                                />
                                            </svg>
                                            :

                                            <svg
                                                className="w-4 h-4 stroke-current"
                                                fill="none"
                                                viewBox="0 0 24 24"
                                                xmlns="http://www.w3.org/2000/svg"
                                            >
                                                <path
                                                    strokeLinecap="round"
                                                    strokeLinejoin="round"
                                                    strokeWidth={2}
                                                    d="M6 18L18 6M6 6l12 12"
                                                />
                                            </svg>

                                        }
                                    </div>
                                </div>
                            </label>
                        </div>

                    </div>

                    <div className='grid grid-cols-2 gap-[15px] p-[24px]'>
                        <div>
                            <label
                                htmlFor="select_brand"
                                className='font-[500] text-[15px] text-black whitespace-nowrap color'
                            >
                                Select Weight Scale Type
                            </label>

                            <select
                                id="bank"
                                // value={paymentMode}
                                // onChange={handleChange}
                                className="bg-white border border-slate-300 text-gray-900 text-sm rounded-lg  block w-full px-2 py-[8px] mt-3 "
                            >
                                <option selected>Search Bank</option>
                                <option value="cash">Cash</option>
                                <option value="cheque">Cheque</option>
                                <option value="dds">DDS</option>
                                <option value="DE">E-Commerce Operator</option>
                                <option value="DE">UIN Holders</option>
                            </select>
                        </div>

                        <div>
                            <label
                                htmlFor="select_brand"
                                className='font-[500] text-[15px] text-black whitespace-nowrap color'
                            >
                                Size of Barcode
                            </label>

                            <select
                                id="bank"
                                // value={paymentMode}
                                // onChange={handleChange}
                                className="bg-white border border-slate-300 text-gray-900 text-sm rounded-lg  block w-full px-2 py-[8px] mt-3 "
                            >
                                <option selected>Search Bank</option>
                                <option value="cash">Cash</option>
                                <option value="cheque">Cheque</option>
                                <option value="dds">DDS</option>
                                <option value="DE">E-Commerce Operator</option>
                                <option value="DE">UIN Holders</option>
                            </select>
                        </div>

                        <div>
                            <label
                                htmlFor="select_brand"
                                className='font-[500] text-[15px] text-black whitespace-nowrap color'
                            >
                                Size of Product Code
                            </label>

                            <select
                                id="bank"
                                // value={paymentMode}
                                // onChange={handleChange}
                                className="bg-white border border-slate-300 text-gray-900 text-sm rounded-lg  block w-full px-2 py-[8px] mt-3 "
                            >
                                <option selected>Search Bank</option>
                                <option value="cash">Cash</option>
                                <option value="cheque">Cheque</option>
                                <option value="dds">DDS</option>
                                <option value="DE">E-Commerce Operator</option>
                                <option value="DE">UIN Holders</option>
                            </select>
                        </div>

                        <div>
                            <label
                                htmlFor="select_brand"
                                className='font-[500] text-[15px] text-black whitespace-nowrap color'
                            >
                                Skip Last Digit
                            </label>

                            <select
                                id="bank"
                                // value={paymentMode}
                                // onChange={handleChange}
                                className="bg-white border border-slate-300 text-gray-900 text-sm rounded-lg  block w-full px-2 py-[8px] mt-3 "
                            >
                                <option selected>Search Bank</option>
                                <option value="cash">Cash</option>
                                <option value="cheque">Cheque</option>
                                <option value="dds">DDS</option>
                                <option value="DE">E-Commerce Operator</option>
                                <option value="DE">UIN Holders</option>
                            </select>
                        </div>
                    </div>
                </div>
            </div>

        </div>
    )
}

export default Hardware