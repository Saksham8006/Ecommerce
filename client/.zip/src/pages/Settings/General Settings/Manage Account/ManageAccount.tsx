import React, { useState } from 'react'
import { MdBusinessCenter } from "react-icons/md";



const ManageAccounts: React.FC = () => {
    const [current, setCurrent] = useState<number>(1)
    const [accountSubset, setAccountSubset] = useState<number>(1); // New state for Account subsection




    return (

        <div className=" bg-white px-[24px] mt-[1px] rounded-md  mr-[20px] border-b border-slate-300">

            <>
                {/* component */}
                {/* @author: Hackcharms */}
                <style
                    dangerouslySetInnerHTML={{
                        __html:
                            "\n    input:checked ~ .radio {\n  color:white;\n  background-color: green;\n}\n"
                    }}
                />
                <div>
                    <div className="mx-auto bg-white pt-[10px]">

                        <div className='border-b border-slate-300'>
                            <span className='text-[16px] font-[500] text-[#2ac3df] flex items-center gap-[2px] mb-[1px]'><span className='text-[20px]'><MdBusinessCenter/></span>B2B</span>
                        </div>



                        <div className='border-b border-slate-300 flex items-center py-[10px] gap-x-[30px]'>

                            <div>
                                <button type='button' onClick={() => setCurrent(1)} className='text-[16px] font-[500] text-[#2ac3df] '>Acount</button>
                                {current === 1 && (
                                    <div className=' border-b border-slate-300 flex items-center py-[10px] gap-x-[30px] '>
                                        <button type='button' onClick={() => setAccountSubset(1)} className={`text-[16px] font-[500] text-[#2ac3df] ${accountSubset === 1 &&'text-black h-[2px] bg-black border min-w-[14px] border-black'}`}>Stock</button>
                                        <button type='button' onClick={() => setAccountSubset(2)} className={`text-[16px] font-[500] text-[#2ac3df] ${accountSubset === 2 && 'text-black h-[2px] bg-black border min-w-[14px] border-black'}`}>Year End Process</button>
                                    </div>
                                )}
                            </div>

                            <div>
                                <button type='button' onClick={() => setCurrent(2)} className='text-[16px] font-[500] text-[#2ac3df] '>Stock</button>
                                {current === 2 &&
                                    <hr className='text-black h-[2px] bg-black border min-w-[14\20px] border-black' />
                                }
                            </div>

                            <div>
                                <button type='button' onClick={() => setCurrent(3)} className='text-[16px] font-[500] text-[#2ac3df] '>Year End Process</button>
                                {current === 3 &&
                                    <hr className='text-black h-[2px] bg-black border min-w-[14\20px] border-black' />
                                }
                            </div>

                        </div>
                    </div>
                </div>
        </>
        </div >


    )
}

export default ManageAccounts