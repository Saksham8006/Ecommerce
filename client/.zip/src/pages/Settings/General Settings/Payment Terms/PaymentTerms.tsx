import React, { useEffect, useState } from 'react'
import { FaPlus, FaRegEdit } from 'react-icons/fa'
import { backendUrl } from '../../../../Configmain'
import axios from 'axios'
import toast, { Toaster } from 'react-hot-toast'
import { RiDeleteBin6Line } from 'react-icons/ri'

interface Data {
    paymentTermName: string;
    paymentTermDay: string;
    createdBy: string;
    _id: string

}

const PaymentTerms: React.FC = () => {
    const [data, setData] = useState<Data[]>([])
    const [paymentTermName, setPaymentTermName] = useState<string>("");
    const [paymentTermDay, setPaymentTermDay] = useState<string>("");
    const [paymentBoxOpen, setPaymentBoxOpen] = useState<boolean>(false);
    const token = localStorage.getItem("authorization")


    const handleDelete = async (_id: string) => {
        try {
            const response = await axios.delete(
                `${backendUrl}/api/settings/general/payment/${_id}`,
                {
                    headers: {
                        Authorization: `${token}`,
                    },
                },
            );

            if (response.status === 200) {
                toast.success('Payment Terms Deleted Successfully');
                setData((prevData) => prevData.filter((item) => item._id !== _id));
            }
        } catch (error) {
            console.log('error', error);
        }
    };


    useEffect(() => {
        const fectchingPayment = async () => {

            try {
                const response = await axios.get(`${backendUrl}/api/settings/general/payment`, {
                    headers: {
                        "Authorization": `${token}`
                    }
                })
                console.log("response from Payment", response.data.data)

                if (response.status === 200) {
                    setData(response.data.data)
                }


            } catch (error) {
                console.log("error", error)
            }
        }


        fectchingPayment();
    }, [])


    const handleChange = (event: React.ChangeEvent<HTMLSelectElement | HTMLInputElement | HTMLTextAreaElement>) => {
        const { id, value } = event.target;
        switch (id) {

            case "payment_term_name":
                setPaymentTermName(value);
                break;
            case "payment_term_day":
                setPaymentTermDay(value);
                break;

            default:
                break;
        }
    }


    const handleSubmit = async () => {

        const data = {
            paymentTermDay, paymentTermName

        }

        try {
            const response = await axios.post(`${backendUrl}/api/settings/general/payment`, data, {
                headers: {
                    "Authorization": `${token}`
                }
            })

            if (response.status === 201) {
                toast.success("Payment Term created Successfully")
                setPaymentBoxOpen(false);
                setPaymentTermDay("")
                setPaymentTermName("")

            }

        } catch (error) {
            console.log("error", error)
        }
    }




    return (


        <div className="bg-white  relative  overflow-hidden">

            {paymentBoxOpen === true && (
                <div
                    id="popup-modal"
                    tabIndex={-1}
                    className="fixed top-0 left-0 w-full h-full flex justify-center items-center bg-gray-900 bg-opacity-50 z-50"
                >
                    <div className="relative w-full max-w-[330px]">
                        <div className="relative bg-white rounded-lg shadow">

                            <div className='flex px-[12px] py-[10px]'>
                                <p className='text-black font-medium'>New Tax</p>
                                <button
                                    type="button"
                                    onClick={() => setPaymentBoxOpen(false)}
                                    className="absolute top-2 right-2 text-gray-400 bg-transparent rounded-lg text-sm w-8 h-8 flex justify-center items-center"
                                >
                                    <svg
                                        className="w-3 h-3"
                                        aria-hidden="true"
                                        xmlns="http://www.w3.org/2000/svg"
                                        fill="none"
                                        viewBox="0 0 14 14"
                                    >
                                        <path
                                            stroke="currentColor"
                                            strokeLinecap="round"
                                            strokeLinejoin="round"
                                            strokeWidth={2}
                                            d="m1 1 6 6m0 0 6 6M7 7l6-6M7 7l-6 6"
                                        />
                                    </svg>
                                    <span className="sr-only">Close modal</span>
                                </button>
                            </div>
                            <hr className="h-px my-1 bg-slate-300 border-0 "></hr>
                            <div className="p-4 md:p-5 text-center">
                                <form className="max-w-sm mx-auto">

                                    <div>
                                        <label
                                            htmlFor="payment_term_name"
                                            className="block mb-1 mt-3 text-[14px] text-start  font-medium text-black"
                                        >
                                            Payment Term Name
                                        </label>
                                        <input
                                            type="text"
                                            id="payment_term_name"
                                            value={paymentTermName}
                                            onChange={handleChange}
                                            className="bg-gray-50 rounded-lg border border-slate-300 text-black text-sm  block w-full px-2 py-[5px] outline-none"
                                            placeholder="Payment Term Name"
                                            required
                                        />
                                    </div>
                                    <div>
                                        <label
                                            htmlFor="payment_term_day"
                                            className="block mt-3 mb-1 text-[14px] text-start  font-medium text-black"
                                        >
                                            Payment Term Day
                                        </label>
                                        <input
                                            type="text"
                                            id="payment_term_day"
                                            value={paymentTermDay}
                                            onChange={handleChange}
                                            className="bg-gray-50 rounded-lg border border-slate-300 text-black text-sm  block w-full px-2 py-[5px] outline-none"
                                            placeholder="Payment Term Day"
                                            required
                                        />
                                    </div>


                                </form>


                                <div className='flex gap-[5px] items-end justify-end px-[12px]'>
                                    <button
                                        data-modal-hide="popup-modal"
                                        type="button"
                                        onClick={() => setPaymentBoxOpen(false)}
                                        className="py-[3px] mt-[12px] text-red-500 border border-red-500 px-5 ms-3 text-sm font-medium text-gray-900 outline-none bg-white rounded-lg "
                                    >
                                        Cancel
                                    </button>
                                    <button
                                        data-modal-hide="popup-modal"
                                        type="button"
                                        onClick={handleSubmit}
                                        className="py-[3px] mt-[12px] text-green-500 border border-green-500 px-4 text-sm font-medium text-gray-900 outline-none bg-white rounded-lg "
                                    >
                                        Save
                                    </button>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
            )}
            <Toaster />
            <div className="flex flex-col md:flex-row items-center justify-between space-y-3 md:space-y-0 md:space-x-4 p-4 px-[32px]">
                <div className=''>
                    <button
                        type="button"
                        onClick={() => setPaymentBoxOpen(!paymentBoxOpen)}
                        className="flex items-center justify-center text-black border border-slate-300 rounded-[8px] font-[500] text-sm px-3 py-1 "
                    >
                        <span className='mr-1 mt-[2px] text-sm'><FaPlus /></span>

                        Create New
                    </button>

                </div>

                <div className="w-full md:w-auto flex flex-col md:flex-row space-y-2 md:space-y-0 items-stretch md:items-center justify-end md:space-x-3 flex-shrink-0">
                    <div>

                        <select
                            id="countries"
                            className="bg-gray-50 border border-slate-300 bg-white rounded-[8px] text-black text-sm font-semibold block w-full px-2 py-1"
                        >

                            <option value="US">10</option>
                            <option value="CA">25</option>
                            <option value="FR">50</option>
                            <option value="DE">100</option>
                            <option value="DE">200</option>
                        </select>
                    </div>
                    <div>


                    </div>

                    <div className="flex items-center space-x-3 w-full md:w-auto">


                        <div className="w-full ">
                            <form className="flex items-center">
                                <label htmlFor="simple-search" className="sr-only">
                                    Search
                                </label>
                                <div className="relative w-full">
                                    <div className="absolute inset-y-0 left-0 flex items-center pl-3 pointer-events-none">
                                        <svg
                                            aria-hidden="true"
                                            className="w-5 h-5 text-gray-500 "
                                            fill="currentColor"
                                            viewBox="0 0 20 20"
                                            xmlns="http://www.w3.org/2000/svg"
                                        >
                                            <path
                                                fillRule="evenodd"
                                                d="M8 4a4 4 0 100 8 4 4 0 000-8zM2 8a6 6 0 1110.89 3.476l4.817 4.817a1 1 0 01-1.414 1.414l-4.816-4.816A6 6 0 012 8z"
                                                clipRule="evenodd"
                                            />
                                        </svg>
                                    </div>
                                    <input
                                        type="text"
                                        // value={searchQuery}
                                        // onChange={handleSearchInput}
                                        id="simple-search"
                                        className="bg-gray-50 border border-slate-300 text-gray-900 text-sm outline-none block w-full pl-10 px-2 py-1 rounded-[8px] "
                                        placeholder="Search"
                                        required
                                    />
                                </div>
                            </form>
                        </div>


                    </div>

                </div>
            </div>

            {/* Table Part */}


            <div className="overflow-x-auto px-[32px] ">
                <table className="w-full text-sm text-left text-gray-500 ">
                    <thead className="text-[14px] text-black  bg-gray-50 bottom-[23px]">
                        <tr className='w-full border-t border-b border-slate-300'>


                            <th scope="col" className="px-4 py-[6px] min-w-[7%] border-r font-[500] border-slate-300 ">
                                #
                            </th>

                            <th scope="col" className="px-4 py-[6px] border-r  font-[500] border-slate-300 ">
                                Payment Term
                            </th>

                            <th scope="col" className="px-4 py-[6px]  border-r font-[500] border-slate-300  ">
                                Payment Term Day
                            </th>
                            <th scope="col" className="px-4 py-[6px] border-r  font-[500] border-slate-300  ">
                                created By
                            </th>
                            <th scope="col" className="px-4 py-[6px] font-[500] border-slate-300  ">
                                Actions
                            </th>


                        </tr>
                    </thead>

                    <tbody className='mt-8 '>
                        {data?.length === 0 ? (
                            <tr className='border-b border-slate-300'>
                                <td colSpan={6} className="px-4 py-[6px] font-[400] text-center text-slate-700">
                                    No data available in this table
                                </td>
                            </tr>
                        ) : (
                            data?.map((payment, index) => (
                                <tr key={index} className="border-t border-b border-slate-300">
                                    <td
                                        className="px-4 py-[6px] font-medium  border-r border-slate-300 text-black"
                                    >
                                        {index + 1}
                                    </td>
                                    <td className="px-4 py-[6px]  border-r border-slate-300 font-[500] text-sky-500">{payment.paymentTermName}</td>


                                    <td className="px-4 py-[6px]  border-r border-slate-300 font-[500]">{payment?.paymentTermDay}</td>
                                    <td className="px-4 py-[6px]  border-r border-slate-300 font-[500]">{payment?.createdBy}</td>
                                    <td className="px-4 py-[6px]  font-[500] flex gap-x-[12px]">

                                        <button type='button' onClick={() => handleDelete(payment?._id)} className='text-[18px]'><RiDeleteBin6Line /></button>
                                        <span className='text-[18px] '><FaRegEdit /></span>
                                    </td>
                                </tr>
                            ))
                        )}
                    </tbody>

                </table>
            </div>
            <nav
                className="flex flex-col md:flex-row justify-between items-start px-[32px] md:items-center space-y-3 md:space-y-0 p-4"
                aria-label="Table navigation"
            >
                <span className="text-sm font-normal text-slate-500 ">
                    Showing{" "}
                    <span className="font-semibold text-slate-600 ">
                        1-10{" "}
                    </span>
                    of{" "}
                    <span className="font-semibold text-slate-600 ">
                        1000{" "}
                    </span>
                </span>
                <ul className="inline-flex items-stretch -space-x-px">
                    <li>
                        <a
                            href="#"
                            className="flex items-center justify-center h-full py-1.5 px-3 ml-0 text-gray-500 bg-white rounded-l-lg border border-slate-300 hover:bg-gray-100 hover:text-gray-700  "
                        >
                            <span className="sr-only">Previous</span>
                            <svg
                                className="w-5 h-5"
                                aria-hidden="true"
                                fill="currentColor"
                                viewBox="0 0 20 20"
                                xmlns="http://www.w3.org/2000/svg"
                            >
                                <path
                                    fillRule="evenodd"
                                    d="M12.707 5.293a1 1 0 010 1.414L9.414 10l3.293 3.293a1 1 0 01-1.414 1.414l-4-4a1 1 0 010-1.414l4-4a1 1 0 011.414 0z"
                                    clipRule="evenodd"
                                />
                            </svg>
                        </a>
                    </li>
                    <li>
                        <a
                            href="#"
                            className="flex items-center justify-center text-sm py-2 px-3 leading-tight text-gray-500 bg-white border border-slate-300 hover:bg-gray-100 hover:text-gray-700  "
                        >
                            1
                        </a>
                    </li>
                    <li>
                        <a
                            href="#"
                            className="flex items-center justify-center text-sm py-2 px-3 leading-tight text-gray-500 bg-white border border-slate-300 hover:bg-gray-100 hover:text-gray-700  "
                        >
                            2
                        </a>
                    </li>
                    <li>
                        <a
                            href="#"
                            aria-current="page"
                            className="flex items-center justify-center text-sm z-10 py-2 px-3 leading-tight text-primary-600 bg-primary-50 border border-slate-300 hover:bg-primary-100 hover:text-primary-700   "
                        >
                            3
                        </a>
                    </li>
                    <li>
                        <a
                            href="#"
                            className="flex items-center justify-center text-sm py-2 px-3 leading-tight text-gray-500 bg-white border border-slate-300 hover:bg-gray-100 hover:text-gray-700  "
                        >
                            ...
                        </a>
                    </li>
                    <li>
                        <a
                            href="#"
                            className="flex items-center justify-center text-sm py-2 px-3 leading-tight text-gray-500 bg-white border border-slate-300 hover:bg-gray-100 hover:text-gray-700  "
                        >
                            100
                        </a>
                    </li>
                    <li>
                        <a
                            href="#"
                            className="flex items-center justify-center h-full py-1.5 px-3 leading-tight text-gray-500 bg-white rounded-r-lg border border-slate-300 hover:bg-gray-100 hover:text-gray-700  "
                        >
                            <span className="sr-only">Next</span>
                            <svg
                                className="w-5 h-5"
                                aria-hidden="true"
                                fill="currentColor"
                                viewBox="0 0 20 20"
                                xmlns="http://www.w3.org/2000/svg"
                            >
                                <path
                                    fillRule="evenodd"
                                    d="M7.293 14.707a1 1 0 010-1.414L10.586 10 7.293 6.707a1 1 0 011.414-1.414l4 4a1 1 0 010 1.414l-4 4a1 1 0 01-1.414 0z"
                                    clipRule="evenodd"
                                />
                            </svg>
                        </a>
                    </li>
                </ul>
            </nav>
        </div>
    )
}

export default PaymentTerms