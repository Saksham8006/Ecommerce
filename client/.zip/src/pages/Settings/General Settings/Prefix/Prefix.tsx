import React, { useEffect, useState } from 'react'
import { backendUrl } from '../../../../Configmain'
import axios from 'axios'
import { FaRegEdit } from 'react-icons/fa'



interface Data {
    prefix: string;
    length: string;
    prefixType: string;
    sequenceNumber: string;
    createdBy: string;
    _id: string

}

const Prefix: React.FC = () => {
    const [data, setData] = useState<Data[]>([])
    const token = localStorage.getItem("authorization")



    useEffect(() => {
        const fectchingPrefix = async () => {

            try {
                const response = await axios.get(`${backendUrl}/api/settings/general/prefix`, {
                    headers: {
                        "Authorization": `${token}`
                    }
                })
                // console.log("response from prefix", response.data.data)

                if (response.status === 200) {
                    setData(response.data.data)
                }


            } catch (error) {
                console.log("error", error)
            }
        }


        fectchingPrefix();
    }, [])


    return (

        <div className="bg-white  relative overflow-hidden">
            <div className="flex flex-col md:flex-row items-center justify-end space-y-3 md:space-y-0 md:space-x-4 p-4 px-[32px]">

                <div className="w-full md:w-auto flex flex-col justify-end md:flex-row space-y-2 md:space-y-0 items-stretch md:items-center  md:space-x-3 flex-shrink-0">
                    <div>

                        <select
                            id="countries"
                            className="bg-gray-50 border border-slate-300 bg-white rounded-[8px] text-black text-sm font-semibold block w-full px-2 py-1"
                        >
                            <option value="US">10</option>
                            <option value="CA">25</option>
                            <option value="FR">50</option>
                            <option value="DE">100</option>
                            <option value="DE">200</option>
                        </select>
                    </div>


                    <div className="flex items-center  float-right space-x-3 w-full md:w-auto">
                        <div className="w-full ">
                            <form className="flex items-center">
                                <label htmlFor="simple-search" className="sr-only">
                                    Search
                                </label>
                                <div className="relative w-full">
                                    <div className="absolute inset-y-0 left-0 flex items-center pl-3 pointer-events-none">
                                        <svg
                                            aria-hidden="true"
                                            className="w-5 h-5 text-gray-500 "
                                            fill="currentColor"
                                            viewBox="0 0 20 20"
                                            xmlns="http://www.w3.org/2000/svg"
                                        >
                                            <path
                                                fillRule="evenodd"
                                                d="M8 4a4 4 0 100 8 4 4 0 000-8zM2 8a6 6 0 1110.89 3.476l4.817 4.817a1 1 0 01-1.414 1.414l-4.816-4.816A6 6 0 012 8z"
                                                clipRule="evenodd"
                                            />
                                        </svg>
                                    </div>
                                    <input
                                        type="text"
                                        // value={searchQuery}
                                        // onChange={handleSearchInput}
                                        id="simple-search"
                                        className="bg-gray-50 border border-slate-300 text-gray-900 text-sm outline-none block w-full pl-10 px-2 py-1 rounded-[8px] "
                                        placeholder="Search"
                                        required
                                    />
                                </div>
                            </form>
                        </div>
                    </div>
                </div>
            </div>

            {/* Table Part */}


            <div className="overflow-x-auto px-[32px] ">
                <table className="w-full text-sm text-left text-gray-500 ">
                    <thead className="text-[14px] text-black  bg-gray-50 bottom-[23px]">
                        <tr className='w-full border-t border-b border-slate-300'>


                            <th scope="col" className="px-4 py-[6px] min-w-[7%] border-r font-[500] border-slate-300 ">
                                #
                            </th>

                            <th scope="col" className="px-4 py-[6px] border-r  font-[500] border-slate-300 ">
                                Prefix
                            </th>

                            <th scope="col" className="px-4 py-[6px] border-r font-[500] border-slate-300  ">
                                Prefix Type
                            </th>

                            <th scope="col" className="px-4 py-[6px]  border-r font-[500] border-slate-300  ">
                                Sequence No.
                            </th>
                            <th scope="col" className="px-4 py-[6px]  border-r font-[500] border-slate-300  ">
                                Length
                            </th>
                            <th scope="col" className="px-4 py-[6px]  border-r font-[500] border-slate-300  ">
                                Created By
                            </th>
                            <th scope="col" className="px-4 py-[6px] font-[500] border-slate-300  ">
                                Actions
                            </th>
                        </tr>
                    </thead>

                    <tbody className='mt-8 '>
                        {data?.length === 0 ? (
                            <tr className='border-b border-slate-300'>
                                <td colSpan={7} className="px-4 py-[6px] font-[400] text-center text-slate-700">
                                    No data available in this table
                                </td>
                            </tr>
                        ) : (
                            data?.map((prefix, index) => (
                                <tr key={index} className="border-t border-b border-slate-300">
                                    <td
                                        className="px-4 py-[6px] font-medium  border-r border-slate-300 text-black"
                                    >
                                        {index + 1}
                                    </td>
                                    <td className="px-4 py-[6px]  border-r border-slate-300 font-[500] text-sky-500">{prefix.prefix}</td>


                                    <td className="px-4 py-[6px]  border-r border-slate-300 font-[500]">{prefix?.prefixType}</td>
                                    <td className="px-4 py-[6px]  border-r border-slate-300 font-[500]">{prefix?.sequenceNumber}</td>
                                    <td className="px-4 py-[6px]  border-r border-slate-300 font-[500]">{prefix?.length}</td>
                                    <td className="px-4 py-[6px]  border-r border-slate-300 font-[500]">{prefix?.createdBy}</td>
                                    <td className="px-4 py-[6px]  font-[500] flex gap-x-[12px]">


                                        <span className='text-[18px] '><FaRegEdit /></span>
                                    </td>
                                </tr>
                            ))
                        )}
                    </tbody>

                </table>
            </div>
            <nav
                className="flex flex-col md:flex-row justify-between items-start px-[32px] md:items-center space-y-3 md:space-y-0 p-4"
                aria-label="Table navigation"
            >
                <span className="text-sm font-normal text-slate-500 ">
                    Showing{" "}
                    <span className="font-semibold text-slate-600 ">
                        1-10{" "}
                    </span>
                    of{" "}
                    <span className="font-semibold text-slate-600 ">
                        1000{" "}
                    </span>
                </span>
                <ul className="inline-flex items-stretch -space-x-px">
                    <li>
                        <a
                            href="#"
                            className="flex items-center justify-center h-full py-1.5 px-3 ml-0 text-gray-500 bg-white rounded-l-lg border border-slate-300 hover:bg-gray-100 hover:text-gray-700  "
                        >
                            <span className="sr-only">Previous</span>
                            <svg
                                className="w-5 h-5"
                                aria-hidden="true"
                                fill="currentColor"
                                viewBox="0 0 20 20"
                                xmlns="http://www.w3.org/2000/svg"
                            >
                                <path
                                    fillRule="evenodd"
                                    d="M12.707 5.293a1 1 0 010 1.414L9.414 10l3.293 3.293a1 1 0 01-1.414 1.414l-4-4a1 1 0 010-1.414l4-4a1 1 0 011.414 0z"
                                    clipRule="evenodd"
                                />
                            </svg>
                        </a>
                    </li>
                    <li>
                        <a
                            href="#"
                            className="flex items-center justify-center text-sm py-2 px-3 leading-tight text-gray-500 bg-white border border-slate-300 hover:bg-gray-100 hover:text-gray-700  "
                        >
                            1
                        </a>
                    </li>
                    <li>
                        <a
                            href="#"
                            className="flex items-center justify-center text-sm py-2 px-3 leading-tight text-gray-500 bg-white border border-slate-300 hover:bg-gray-100 hover:text-gray-700  "
                        >
                            2
                        </a>
                    </li>
                    <li>
                        <a
                            href="#"
                            aria-current="page"
                            className="flex items-center justify-center text-sm z-10 py-2 px-3 leading-tight text-primary-600 bg-primary-50 border border-slate-300 hover:bg-primary-100 hover:text-primary-700   "
                        >
                            3
                        </a>
                    </li>
                    <li>
                        <a
                            href="#"
                            className="flex items-center justify-center text-sm py-2 px-3 leading-tight text-gray-500 bg-white border border-slate-300 hover:bg-gray-100 hover:text-gray-700  "
                        >
                            ...
                        </a>
                    </li>
                    <li>
                        <a
                            href="#"
                            className="flex items-center justify-center text-sm py-2 px-3 leading-tight text-gray-500 bg-white border border-slate-300 hover:bg-gray-100 hover:text-gray-700  "
                        >
                            100
                        </a>
                    </li>
                    <li>
                        <a
                            href="#"
                            className="flex items-center justify-center h-full py-1.5 px-3 leading-tight text-gray-500 bg-white rounded-r-lg border border-slate-300 hover:bg-gray-100 hover:text-gray-700  "
                        >
                            <span className="sr-only">Next</span>
                            <svg
                                className="w-5 h-5"
                                aria-hidden="true"
                                fill="currentColor"
                                viewBox="0 0 20 20"
                                xmlns="http://www.w3.org/2000/svg"
                            >
                                <path
                                    fillRule="evenodd"
                                    d="M7.293 14.707a1 1 0 010-1.414L10.586 10 7.293 6.707a1 1 0 011.414-1.414l4 4a1 1 0 010 1.414l-4 4a1 1 0 01-1.414 0z"
                                    clipRule="evenodd"
                                />
                            </svg>
                        </a>
                    </li>
                </ul>
            </nav>
        </div>
    )
}

export default Prefix