import React from 'react'



const ReportFormats: React.FC = () => {
    return (

        <div>ReportFormats</div>


    )
}

export default ReportFormats