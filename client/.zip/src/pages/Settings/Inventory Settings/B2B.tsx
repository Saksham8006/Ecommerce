import React from 'react'
import { MdOutlineProductionQuantityLimits } from "react-icons/md";



const B2B: React.FC = () => {



    return (

        <div className=" bg-white px-[24px] mt-[1px] rounded-md  mr-[20px] border-b border-slate-300">
            <div>
                <div>
                    <>
                        {/* component */}
                        {/* @author: Hackcharms */}
                        <style
                            dangerouslySetInnerHTML={{
                                __html:
                                    "\n    input:checked ~ .radio {\n  color:white;\n  background-color: green;\n}\n"
                            }}
                        />
                        <div>
                            <div className="mx-auto bg-white pt-[10px]">

                                <div className='border-b border-slate-300'>
                                    <span className='text-[16px] font-[500] text-[#2ac3df] flex items-center gap-[6px] mb-[1px]'><MdOutlineProductionQuantityLimits />B2B</span>
                                </div>
                                <div className="grid grid-cols-1 py-[25px] sm:grid-cols-2 lg:grid-cols-4 gap-10">



                                    <div className="bg-gray-200 rounded-lg bg-gray-200">
                                        <h3 className='font-[500] text-[15px] text-black whitespace-nowrap color'>Enable Product Types</h3>
                                        <label className='toggle-label border-lg'>
                                            <input type='checkbox' />
                                            <span className='back'>
                                                <span className='toggle'></span>
                                                <span className='label on mt-[-20px]'>YES</span>
                                                <span className='label off  mt-[-20px]'>NO</span>
                                            </span>
                                        </label>
                                    </div>

                                </div>

                            </div>
                        </div>
                    </>
                </div>
            </div>



        </div>


    )
}

export default B2B