import React from 'react'
import { LiaBarcodeSolid } from "react-icons/lia";


const Barcodes: React.FC = () => {

    return (

        <div className=" bg-white mr-[20px] mt-[1px] rounded-md  border-b border-slate-300">
            <div>
                <>
                    {/* component */}
                    {/* @author: Hackcharms */}
                    <style
                        dangerouslySetInnerHTML={{
                            __html:
                                "\n    input:checked ~ .radio {\n  color:white;\n  background-color: green;\n}\n"
                        }}
                    />
                    <div>
                        <div className=" bg-white pt-[10px] px-[20px]">

                            <div className='border-b border-slate-300'>
                                <span className='text-[16px] font-[500] text-[#2ac3df]  flex items-center gap-[6px] mb-[1px]'><LiaBarcodeSolid />BARCODES</span>
                            </div>
                            <div className="grid grid-cols-1 py-[25px] sm:grid-cols-2 lg:grid-cols-4 gap-10">



                                <div className="bg-gray-200 rounded-lg bg-gray-200">
                                    <h3 className='font-[500] text-[15px] text-black whitespace-nowrap color'>Auto Generate Barcode</h3>
                                    <label className='toggle-label border-lg'>
                                        <input type='checkbox' />
                                        <span className='back'>
                                            <span className='toggle'></span>
                                            <span className='label on mt-[-20px]'>YES</span>
                                            <span className='label off  mt-[-20px]'>NO</span>
                                        </span>
                                    </label>
                                </div>


                                {/* bg-gray-200 */}
                                <div>
                                    <label
                                        htmlFor="select_brand"
                                        className='font-[500] text-[15px] text-black whitespace-nowrap color'
                                    >
                                        Barcode Prefix
                                    </label>

                                    <select
                                        id="bank"
                                        // value={paymentMode}
                                        // onChange={handleChange}
                                        className="bg-white border border-slate-300 text-gray-900 text-sm rounded-lg  block w-full px-2 py-[8px] mt-3 "
                                    >
                                        <option selected>Search Bank</option>
                                        <option value="cash">Cash</option>
                                        <option value="cheque">Cheque</option>
                                        <option value="dds">DDS</option>
                                        <option value="DE">E-Commerce Operator</option>
                                        <option value="DE">UIN Holders</option>
                                    </select>
                                </div>

                                <div>
                                    <label
                                        htmlFor="select_brand"
                                        className='font-[500] text-[15px] text-black whitespace-nowrap color'
                                    >
                                        Barcode Series
                                    </label>

                                    <select
                                        id="bank"
                                        // value={paymentMode}
                                        // onChange={handleChange}
                                        className="bg-white border border-slate-300 text-gray-900 text-sm rounded-lg  block w-full px-2 py-[8px] mt-3 "
                                    >
                                        <option selected>Search Bank</option>
                                        <option value="cash">Cash</option>
                                        <option value="cheque">Cheque</option>
                                        <option value="dds">DDS</option>
                                        <option value="DE">E-Commerce Operator</option>
                                        <option value="DE">UIN Holders</option>
                                    </select>
                                </div>


                                <div>
                                    <label
                                        htmlFor="select_brand"
                                        className='font-[500] text-[15px] text-black whitespace-nowrap color'
                                    >
                                        Barcode Length
                                    </label>

                                    <select
                                        id="bank"
                                        // value={paymentMode}
                                        // onChange={handleChange}
                                        className="bg-white border border-slate-300 text-gray-900 text-sm rounded-lg  block w-full px-2 py-[8px] mt-3 "
                                    >
                                        <option selected>Search Bank</option>
                                        <option value="cash">Cash</option>
                                        <option value="cheque">Cheque</option>
                                        <option value="dds">DDS</option>
                                        <option value="DE">E-Commerce Operator</option>
                                        <option value="DE">UIN Holders</option>
                                    </select>
                                </div>

                                <div>
                                    <label
                                        htmlFor="select_brand"
                                        className='font-[500] text-[15px] text-black whitespace-nowrap color'
                                    >
                                        MFG Date
                                    </label>

                                    <select
                                        id="bank"
                                        // value={paymentMode}
                                        // onChange={handleChange}
                                        className="bg-white border border-slate-300 text-gray-900 text-sm rounded-lg  block w-full px-2 py-[8px] mt-3 "
                                    >
                                        <option selected>Search Bank</option>
                                        <option value="cash">Cash</option>
                                        <option value="cheque">Cheque</option>
                                        <option value="dds">DDS</option>
                                        <option value="DE">E-Commerce Operator</option>
                                        <option value="DE">UIN Holders</option>
                                    </select>
                                </div>

                                <div>
                                    <label
                                        htmlFor="select_brand"
                                        className='font-[500] text-[15px] text-black whitespace-nowrap color'
                                    >
                                        Expiry Date
                                    </label>

                                    <select
                                        id="bank"
                                        // value={paymentMode}
                                        // onChange={handleChange}
                                        className="bg-white border border-slate-300 text-gray-900 text-sm rounded-lg  block w-full px-2 py-[8px] mt-3 "
                                    >
                                        <option selected>Search Bank</option>
                                        <option value="cash">Cash</option>
                                        <option value="cheque">Cheque</option>
                                        <option value="dds">DDS</option>
                                        <option value="DE">E-Commerce Operator</option>
                                        <option value="DE">UIN Holders</option>
                                    </select>
                                </div>



                                <div>
                                    <label
                                        htmlFor="select_brand"
                                        className='font-[500] text-[15px] text-black whitespace-nowrap color'
                                    >
                                        Selling Price
                                    </label>

                                    <select
                                        id="bank"
                                        // value={paymentMode}
                                        // onChange={handleChange}
                                        className="bg-white border border-slate-300 text-gray-900 text-sm rounded-lg  block w-full px-2 py-[8px] mt-3 "
                                    >
                                        <option selected>Search Bank</option>
                                        <option value="cash">Cash</option>
                                        <option value="cheque">Cheque</option>
                                        <option value="dds">DDS</option>
                                        <option value="DE">E-Commerce Operator</option>
                                        <option value="DE">UIN Holders</option>
                                    </select>
                                </div>





                            </div>
                        </div>
                    </div>
                </>
            </div>

        </div>


    )
}

export default Barcodes