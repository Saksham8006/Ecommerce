import React, { useState } from 'react'
import DefaultLayout from '../../../layout/DefaultLayout'
import Breadcrumb from '../../../components/Breadcrumbs/Breadcrumb'
import { FaHome } from "react-icons/fa";
import Settings_sidebar from '../../../assets/Settings_sidebar.svg'
import Defaults from './Defaults';
import Pricing from './Pricing';
import Stock from './Stock';
import Barcodes from './Barcodes';
import Production from './Production';
import B2B from './B2B';
import { FaRupeeSign } from "react-icons/fa";
import { FaDatabase } from "react-icons/fa";
import { LiaBarcodeSolid } from "react-icons/lia";
import { MdOutlineProductionQuantityLimits } from "react-icons/md";
import { FaBabyCarriage } from "react-icons/fa";
import { FaScrewdriverWrench } from "react-icons/fa6";




const InventorySettings: React.FC = () => {
    const [current, setCurrent] = useState<number>(1);

    return (
        <DefaultLayout>
            <Breadcrumb
                pageName={<h1 className='ml-[42px] '>Inventory Settings</h1>}
                icon={<img src={Settings_sidebar} alt="Inventory Settings icon" className='max-w-[50%] ml-2 mb-2' />}
                homeIcon={<span className=''><FaHome /></span>}
            />

            <div className='flex flex-row gap-[30px] '>

                <div className='flex flex-col gap-[4px]'>
                    <button type="button" onClick={() => setCurrent(1)} className={` ${current === 1 ? "border-[1.5px] border-black" : "border border-slate-300"} text-black  font-medium rounded-lg text-sm px-5 py-[4px] me-2 mb-2 ml-[20px] w-[200px]  bg-white flex items-center gap-[10px] `}><FaScrewdriverWrench />Default</button>
                    <button type="button" onClick={() => setCurrent(2)} className={` ${current === 2 ? "border-[1.5px] border-black" : "border border-slate-300"} text-black  font-medium rounded-lg text-sm px-5  py-[4px] me-2 mb-2 ml-[20px] w-[200px]  bg-white flex items-center gap-[10px] `}><FaRupeeSign />Pricing</button>
                    <button type="button" onClick={() => setCurrent(3)} className={` ${current === 3 ? "border-[1.5px] border-black" : "border border-slate-300"} text-black  font-medium rounded-lg text-sm px-5  py-[4px]  me-2 mb-2 ml-[20px] w-[200px] bg-white flex items-center gap-[10px] `}><FaDatabase />Stock</button>
                    <button type="button" onClick={() => setCurrent(4)} className={` ${current === 4 ? "border-[1.5px] border-black" : "border border-slate-300"} text-black  font-medium rounded-lg text-sm px-5 py-[4px] me-2 mb-2 ml-[20px]  w-[200px]  bg-white flex items-center gap-[10px] `}><LiaBarcodeSolid />Barcodes</button>
                    <button type="button" onClick={() => setCurrent(5)} className={` ${current === 5 ? "border-[1.5px] border-black" : "border border-slate-300"} text-black  font-medium rounded-lg text-sm px-5 py-[4px] me-2 mb-2 ml-[20px]  w-[200px]  bg-white flex items-center gap-[10px] `}><MdOutlineProductionQuantityLimits />Production</button>
                    <button type="button" onClick={() => setCurrent(6)} className={` ${current === 6 ? "border-[1.5px] border-black" : "border border-slate-300"} text-black  font-medium rounded-lg text-sm px-5 py-[4px] me-2 mb-2 ml-[20px] w-[200px]   bg-white flex items-center gap-[10px] `}><FaBabyCarriage />B2B</button>

                </div>

                <div className='w-full'>
                    {current === 1 &&
                        <Defaults />
                    }
                    {current === 2 &&
                        <Pricing />
                    }
                    {current === 3 &&
                        <Stock />
                    }
                    {current === 4 &&
                        <Barcodes />
                    }
                    {current === 5 &&
                        <Production />
                    }
                    {current === 6 &&
                        <B2B />
                    }

                </div>
            </div>



        </DefaultLayout>
    )
}

export default InventorySettings