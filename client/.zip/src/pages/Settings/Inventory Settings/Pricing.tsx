import React from 'react'
import { FaRupeeSign } from "react-icons/fa";


const Pricing: React.FC = () => {


    return (



        <div className=" bg-white my-[24px] mt-[1px] mr-[20px] rounded-md  border-b border-slate-300 ">


            <>
                {/* component */}
                {/* @author: Hackcharms */}
                <style
                    dangerouslySetInnerHTML={{
                        __html:
                            "\n    input:checked ~ .radio {\n  color:white;\n  background-color: green;\n}\n"
                    }}
                />

                <div className=" px-[24px] bg-white">

                    <div className='border-b pl-[2px] border-slate-300'>
                        <span className='text-[16px] font-[500] text-[#2ac3df] flex items-center pt-[10px]'><FaRupeeSign />PRICING</span>
                    </div>
                    <div className="grid grid-cols-1 py-[25px] sm:grid-cols-2 lg:grid-cols-4 gap-10">
                        <div>
                            <label
                                htmlFor="selling_margin"
                                className="block mb-2   text-sm font-[500] text-black"
                            >
                                Selling Margin %
                            </label>
                            <input
                                type="text"
                                id="selling_margin"
                                // value={productName}
                                // onChange={handleChange}
                                className="bg-gray-50 rounded-lg border border-slate-300 text-black text-sm  block w-full px-2 py-[5px] outline-none"
                                placeholder="Product Name"
                                required
                            />
                        </div>

                        <div className="bg-gray-200 rounded-lg bg-gray-200">
                            <h3 className='font-[500] text-[15px] text-black whitespace-nowrap color'>Enable B2B Pricing</h3>
                            <label className='toggle-label border-lg'>
                                <input type='checkbox' />
                                <span className='back'>
                                    <span className='toggle'></span>
                                    <span className='label on mt-[-20px]'>YES</span>
                                    <span className='label off  mt-[-20px]'>NO</span>
                                </span>
                            </label>
                        </div>



                        <div>
                            <label
                                htmlFor="selling_margin"
                                className="block mb-2 text-sm font-[500] text-black"
                            >
                                Retailer Margin %
                            </label>
                            <input
                                type="text"
                                id="selling_margin"
                                // value={productName}
                                // onChange={handleChange}
                                className="bg-gray-50 rounded-lg border border-slate-300 text-black text-sm  block w-full px-2 py-[5px] outline-none"
                                placeholder="Product Name"
                                required
                            />
                        </div>

                        <div>
                            <label
                                htmlFor="selling_margin"
                                className="block mb-2 text-sm font-[500] text-black"
                            >
                                Wholesaler Margin %

                            </label>
                            <input
                                type="text"
                                id="selling_margin"
                                // value={productName}
                                // onChange={handleChange}
                                className="bg-gray-50 rounded-lg border border-slate-300 text-black text-sm  block w-full px-[4px] py-[2px] outline-none"
                                placeholder="Product Name"
                                required
                            />
                        </div>




                        <div className="bg-gray-200 rounded-lg bg-gray-200">
                            <h3 className='font-[500] text-[15px] text-black whitespace-nowrap color'>Allow Product Cost</h3>
                            <label className='toggle-label border-lg'>
                                <input type='checkbox' />
                                <span className='back'>
                                    <span className='toggle'></span>
                                    <span className='label on mt-[-20px]'>YES</span>
                                    <span className='label off  mt-[-20px]'>NO</span>
                                </span>
                            </label>
                        </div>


                        <div className='three'>
                            <div className="bg-gray-200 rounded-lg bg-gray-200">
                                <h3 className='font-[500] text-[15px] text-black  leading-[20px] whitespace-nowrap color'>Allow User to Update <br />Product Price on POS</h3>
                                <label className='toggle-label border-lg'>
                                    <input type='checkbox' />
                                    <span className='back'>
                                        <span className='toggle'></span>
                                        <span className='label on mt-[-20px]'>ON</span>
                                        <span className='label off  mt-[-20px]'>OFF</span>
                                    </span>
                                </label>
                            </div>
                        </div>


                        <div className='four'>
                            <div className="bg-gray-200 rounded-lg bg-gray-200">
                                <h3 className='font-[500] text-[15px] text-black whitespace-nowrap color'>Membership</h3>
                                <label className='toggle-label border-lg'>
                                    <input type='checkbox' />
                                    <span className='back'>
                                        <span className='toggle'></span>
                                        <span className='label on mt-[-20px]'>YES</span>
                                        <span className='label off  mt-[-20px]'>NO</span>
                                    </span>
                                </label>
                            </div>
                        </div>

                        {/* bg-gray-200 */}
                        <div>
                            <label
                                htmlFor="select_brand"
                                className='font-[500] text-[15px] text-black whitespace-nowrap color'
                            >
                                Show Profit as per Costing

                            </label>

                            <select
                                id="bank"
                                // value={paymentMode}
                                // onChange={handleChange}
                                className="bg-white border border-slate-300 text-gray-900 text-sm rounded-lg  block w-full px-2 py-[8px] mt-3 "
                            >
                                <option selected>Search Bank</option>
                                <option value="cash">Cash</option>
                                <option value="cheque">Cheque</option>
                                <option value="dds">DDS</option>
                                <option value="DE">E-Commerce Operator</option>
                                <option value="DE">UIN Holders</option>
                            </select>
                        </div>





                    </div>
                </div>


            </>

        </div>


    )
}

export default Pricing