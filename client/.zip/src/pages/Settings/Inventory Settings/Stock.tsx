import React from 'react'

import { FaDatabase } from "react-icons/fa";


const Stock: React.FC = () => {



    return (



        <div className="mx-auto bg-white my-[24px] mt-[1px]  mr-[20px] rounded-md  border-b border-slate-300">
            <div>
                <div>
                    <>
                        {/* component */}
                        {/* @author: Hackcharms */}
                        <style
                            dangerouslySetInnerHTML={{
                                __html:
                                    "\n    input:checked ~ .radio {\n  color:white;\n  background-color: green;\n}\n"
                            }}
                        />
                        <div className="flex px-[20px] pr-[20px]">
                            <div className=" bg-white ">

                                <div className='border-b border-slate-300'>
                                    <span className='text-[16px] font-[500] text-[#2ac3df] flex items-center gap-[6px] pt-[10px] pr-[10px]'><FaDatabase />STOCK</span>
                                </div>
                                <div className="grid grid-cols-1 py-[25px] sm:grid-cols-2 lg:grid-cols-4 gap-10">



                                    <div className="bg-gray-200 rounded-lg bg-gray-200">
                                        <h3 className='font-[500] text-[15px] text-black whitespace-nowrap color'>Allow Negative Stock</h3>
                                        <label className='toggle-label border-lg'>
                                            <input type='checkbox' />
                                            <span className='back'>
                                                <span className='toggle'></span>
                                                <span className='label on mt-[-20px]'>YES</span>
                                                <span className='label off  mt-[-20px]'>NO</span>
                                            </span>
                                        </label>
                                    </div>


                                    {/* bg-gray-200 */}
                                    <div>
                                        <label
                                            htmlFor="select_brand"
                                            className='font-[500] text-[15px] text-black whitespace-nowrap color'
                                        >
                                            Add Quantity Through
                                        </label>

                                        <select
                                            id="bank"
                                            // value={paymentMode}
                                            // onChange={handleChange}
                                            className="bg-white border border-slate-300 text-gray-900 text-sm rounded-lg  block w-full px-2 py-[8px] mt-3 "
                                        >
                                            <option selected>Search Bank</option>
                                            <option value="cash">Cash</option>
                                            <option value="cheque">Cheque</option>
                                            <option value="dds">DDS</option>
                                            <option value="DE">E-Commerce Operator</option>
                                            <option value="DE">UIN Holders</option>
                                        </select>
                                    </div>

                                    <div className="bg-gray-200 rounded-lg bg-gray-200">
                                        <h3 className='font-[500] text-[15px] text-black leading-[20px] whitespace-nowrap color'>
                                            Manage Minimum Stock <br />& PO Quantity</h3>
                                        <label className='toggle-label border-lg'>
                                            <input type='checkbox' />
                                            <span className='back'>
                                                <span className='toggle'></span>
                                                <span className='label on mt-[-20px]'>YES</span>
                                                <span className='label off  mt-[-20px]'>NO</span>
                                            </span>
                                        </label>
                                    </div>

                                    <div className="bg-gray-200 rounded-lg bg-gray-200">
                                        <h3 className='font-[500] text-[15px] text-black leading-[20px] whitespace-nowrap color'>Allow Product Delete if<br /> Stock Available</h3>
                                        <label className='toggle-label border-lg'>
                                            <input type='checkbox' />
                                            <span className='back'>
                                                <span className='toggle'></span>
                                                <span className='label on mt-[-20px]'>YES</span>
                                                <span className='label off  mt-[-20px]'>NO</span>
                                            </span>
                                        </label>
                                    </div>
                                </div>
                            </div>
                        </div>
                    </>
                </div>
            </div>
        </div>


    )
}

export default Stock