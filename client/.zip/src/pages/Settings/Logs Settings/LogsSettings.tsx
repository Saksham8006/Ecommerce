import React, { useState } from 'react'
import DefaultLayout from '../../../layout/DefaultLayout'
import Breadcrumb from '../../../components/Breadcrumbs/Breadcrumb'
import { FaHome } from "react-icons/fa";
import Settings_sidebar from '../../../assets/Settings_sidebar.svg'
import SMSLog from './SMSLog';
import UserActivityLogs from './UserActivityLogs';

import { FaRupeeSign } from "react-icons/fa";

import { FaScrewdriverWrench } from "react-icons/fa6";




const LogsSettings: React.FC = () => {
    const [current, setCurrent] = useState<number>(1);

    return (
        <DefaultLayout>
            <Breadcrumb
                pageName={<h1 className='ml-[42px] '>Logs Settings</h1>}
                icon={<img src={Settings_sidebar} alt="Inventory Settings icon" className='max-w-[50%] ml-2 mb-2' />}
                homeIcon={<span className=''><FaHome /></span>}
            />

            <div className='flex flex-row gap-[30px] '>

                <div className='flex flex-col gap-[4px]'>
                    <button type="button" onClick={() => setCurrent(1)} className={` ${current === 1 ? "border-[1.5px] border-black" : "border border-slate-300"} text-black  font-medium rounded-lg text-sm px-5 py-[4px] me-2 mb-2 ml-[20px] w-[200px]  bg-white flex items-center gap-[10px] `}><FaScrewdriverWrench />SMS Log</button>
                    <button type="button" onClick={() => setCurrent(2)} className={` ${current === 2 ? "border-[1.5px] border-black" : "border border-slate-300"} text-black  font-medium rounded-lg text-sm px-5  py-[4px] me-2 mb-2 ml-[20px] w-[200px]  bg-white flex items-center gap-[10px] `}><FaRupeeSign />User Activity Logs</button>
                </div>

                <div className='w-full'>
                    {current === 1 &&
                        <SMSLog />
                    }
                    {current === 2 &&
                        <UserActivityLogs />
                    }

                </div>
            </div>



        </DefaultLayout>
    )
}

export default LogsSettings