import React, { useState } from 'react'
import { BiSolidPrinter } from 'react-icons/bi'
import { FaRegFileLines } from 'react-icons/fa6'

const SMSLog = () => {
  const [data, setData] = useState<string[]>([])


  return (
    <div className=' border-rounded-md p-[10px]'>


      <div className='bg-white rounded-[8px] my-[4px] flex gap-[8px] items-center py-[8px]  justify-end  px-[32px]'>

        <span className='bg-yellow-500 p-[2px]  rounded-md text-white text-[20px]'> <BiSolidPrinter /></span>
        <span className='bg-pink-500  p-[2px] rounded-md text-white text-[20px]'><FaRegFileLines /></span>
        <span className='bg-green-500 p-[2px]  rounded-md text-white text-[20px]'> <FaRegFileLines /></span>

      </div>

      <div className="flex px-[12px] py-[20px] bg-white rounded-md">
        <div>
          <div className="flex  w-full">

            <div className="bg-gray-200 rounded-lg bg-gray-200 ml-4 ">
              <h3 className='font-[500] text-[15px] text-black whitespace-nowrap color mb-4'>Select Status</h3>


              <select
                id="countries"
                className="bg-gray-50 border border-slate-300 bg-white rounded-[8px] text-black text-sm font-semibold block w-[200px] px-2 py-1"
              >
                <option value="DE">All</option>
                <option value="US">pending</option>
                <option value="CA">Deleivered</option>
                <option value="FR">Failed</option>
              </select>
            </div>

            {/* 2nd */}


            <div className="container mx-auto p-4">
              <div className="flex items-center mb-4">
                <div>
                  <div>
                    <label
                      htmlFor="first_name"
                      className="block mb-2 text-sm font-[500] text-black"
                    >
                      From Date
                    </label>
                    <input
                      type="date"
                      id="first_name"
                      // value={firstName}
                      // onChange={handleChange}
                      className="bg-gray-50 border rounded-lg border-slate-300 text-black text-sm  block w-full px-2 py-[5px] outline-none"
                      placeholder="First Name"
                      required
                    />
                  </div>

                </div>
              </div>
              <div id="calendar" className="bg-white shadow overflow-hidden sm:rounded-lg mt-4">
                {/* Calendar content will be dynamically populated here */}
              </div>
            </div>

            <div className="container mx-auto p-4">
              <div className="flex items-center mb-4">
                <div>
                  <div>
                    <label
                      htmlFor="first_name"
                      className="block mb-2 text-sm font-[500] text-black"
                    >
                      To Date
                    </label>
                    <input
                      type="date"
                      id="first_name"
                      // value={firstName}
                      // onChange={handleChange}
                      className="bg-gray-50 border rounded-lg border-slate-300 text-black text-sm  block w-full px-2 py-[5px] outline-none"
                      placeholder="First Name"
                      required
                    />
                  </div>

                </div>
              </div>
              <div id="calendar" className="bg-white shadow overflow-hidden sm:rounded-lg mt-4">
                {/* Calendar content will be dynamically populated here */}
              </div>
            </div>
          </div>

          <div className=' rounded-md'>
            <div className="overflow-x-auto  rounded-md px-[32px] ">
              <table className="w-full text-sm text-left text-gray-500 ">
                <thead className="text-[14px] text-black  bg-gray-50 bottom-[23px]">
                  <tr className='w-full border-t border-b border-slate-300'>


                    <th scope="col" className="px-4 py-[6px]  border-r font-[500] border-slate-300 ">
                      from
                    </th>

                    <th scope="col" className="px-4 py-[6px] border-r  font-[500] border-slate-300 ">
                      To
                    </th>
                    <th scope="col" className="px-4 py-[6px]  border-r font-[500] border-slate-300 ">
                      Message
                    </th>
                    <th scope="col" className="px-4 py-[6px] border-r font-[500] border-slate-300  ">
                      Date
                    </th>
                    <th scope="col" className="px-4 py-[6px] border-r font-[500] border-slate-300  ">
                      Status
                    </th>

                    <th scope="col" className="px-4 py-[6px] font-[500] border-slate-300  ">
                      Total Materials
                    </th>

                  </tr>
                </thead>

                <tbody className='mt-8 '>
                  {data?.length === 0 ? (
                    <tr className='border-b border-slate-300'>
                      <td colSpan={6} className="px-4 py-[6px] font-[400] text-center text-slate-700">
                        No data available in this table
                      </td>
                    </tr>
                  ) : (
                    data?.map((material, index) => (
                      <tr key={index} className="border-t border-b border-slate-300">
                        <td
                          className="px-4 py-[6px] font-medium  border-r border-slate-300 text-black"
                        >
                          {index + 1}
                        </td>
                        <td className="px-4 py-[6px]  border-r border-slate-300 font-[500] text-sky-500">{material.consumptionNumber}</td>

                        <td className="px-4 py-[6px] border-r border-slate-300 font-[500]">
                          {/* {material?.consumptionDate ? formatDate(material.consumptionDate) : ''} */}
                        </td>
                        <td className="px-4 py-[6px]  border-r border-slate-300 font-[500]">{material?.userName}</td>
                        <td className="px-4 py-[6px]  border-r border-slate-300 font-[500]">{material?.consumptionType}</td>
                        <td className="px-4 py-[6px]  border-r border-slate-300 font-[500]">{material?.location}</td>
                        <td className="px-4 py-[6px]  border-r border-slate-300 font-[500]">{material?.grandTotal}</td>

                        <td className="px-4 py-[6px]  font-[500] flex gap-x-[12px]">
                          <span className='text-[18px] '></span>
                          {/* <button type='button' onClick={() => handleDeleteMaterialCon(material?._id)} className='text-[18px]'></button>  */}
                          <span className='text-[18px] '></span>
                        </td>
                      </tr>
                    ))
                  )}
                </tbody>


                <thead className="text-[14px] text-black  bg-gray-50 bottom-[23px]">
                  <tr className='w-full border-t border-b border-slate-300'>


                    <th scope="col" className="px-4 py-[6px]  border-r font-[500] border-slate-300 ">


                      <input
                        type="text"
                        id="selling_margin"
                        // value={productName}
                        // onChange={handleChange}
                        className="bg-gray-50 rounded-lg border border-slate-300 text-black text-sm  block w-full px-[4px] py-[2px] outline-none"
                        placeholder="Search"
                        required
                      />

                    </th>

                    <th scope="col" className="px-4 py-[6px] border-r  font-[500] border-slate-300 ">


                      <input
                        type="text"
                        id="selling_margin"
                        // value={productName}
                        // onChange={handleChange}
                        className="bg-gray-50 rounded-lg border border-slate-300 text-black text-sm  block w-full px-[4px] py-[2px] outline-none"
                        placeholder="Search"
                        required
                      />

                    </th>
                    <th scope="col" className="px-4 py-[6px]  border-r font-[500] border-slate-300 ">


                      <input
                        type="text"
                        id="selling_margin"
                        // value={productName}
                        // onChange={handleChange}
                        className="bg-gray-50 rounded-lg border border-slate-300 text-black text-sm  block w-full px-[4px] py-[2px] outline-none"
                        placeholder="Search"
                        required
                      />

                    </th>
                    <th scope="col" className="px-4 py-[6px] border-r font-[500] border-slate-300  ">


                      <input
                        type="text"
                        id="selling_margin"
                        // value={productName}
                        // onChange={handleChange}
                        className="bg-gray-50 rounded-lg border border-slate-300 text-black text-sm  block w-full px-[4px] py-[2px] outline-none"
                        placeholder="Search"
                        required
                      />

                    </th>
                    <th scope="col" className="px-4 py-[6px] border-r font-[500] border-slate-300  ">
                      <input
                        type="text"
                        id="selling_margin"
                        // value={productName}
                        // onChange={handleChange}
                        className="bg-gray-50 rounded-lg border border-slate-300 text-black text-sm  block w-full px-[4px] py-[2px] outline-none"
                        placeholder="Search"
                        required
                      />

                    </th>

                    <th scope="col" className="px-4 py-[6px] font-[500] border-slate-300  ">


                      <input
                        type="text"
                        id="selling_margin"
                        // value={productName}
                        // onChange={handleChange}
                        className="bg-gray-50 rounded-lg border border-slate-300 text-black text-sm  block w-full px-[4px] py-[2px] outline-none"
                        placeholder="Search"
                        required
                      />
                    </th>
                  </tr>
                </thead>
              </table>
            </div>
            <nav
              className="flex flex-col md:flex-row justify-between items-start px-[32px] md:items-center space-y-3 md:space-y-0 p-4"
              aria-label="Table navigation"
            >
              <span className="text-sm font-normal text-slate-500 ">
                Showing{" "}
                <span className="font-semibold text-slate-600 ">
                  1-10{" "}
                </span>
                of{" "}
                <span className="font-semibold text-slate-600 ">
                  1000{" "}
                </span>
              </span>
              <ul className="inline-flex items-stretch -space-x-px">
                <li>
                  <a
                    href="#"
                    className="flex items-center justify-center h-full py-1.5 px-3 ml-0 text-gray-500 bg-white rounded-l-lg border border-slate-300 hover:bg-gray-100 hover:text-gray-700  "
                  >
                    <span className="sr-only">Previous</span>
                    <svg
                      className="w-5 h-5"
                      aria-hidden="true"
                      fill="currentColor"
                      viewBox="0 0 20 20"
                      xmlns="http://www.w3.org/2000/svg"
                    >
                      <path
                        fillRule="evenodd"
                        d="M12.707 5.293a1 1 0 010 1.414L9.414 10l3.293 3.293a1 1 0 01-1.414 1.414l-4-4a1 1 0 010-1.414l4-4a1 1 0 011.414 0z"
                        clipRule="evenodd"
                      />
                    </svg>
                  </a>
                </li>
                <li>
                  <a
                    href="#"
                    className="flex items-center justify-center text-sm py-2 px-3 leading-tight text-gray-500 bg-white border border-slate-300 hover:bg-gray-100 hover:text-gray-700  "
                  >
                    1
                  </a>
                </li>
                <li>
                  <a
                    href="#"
                    className="flex items-center justify-center text-sm py-2 px-3 leading-tight text-gray-500 bg-white border border-slate-300 hover:bg-gray-100 hover:text-gray-700  "
                  >
                    2
                  </a>
                </li>
                <li>
                  <a
                    href="#"
                    aria-current="page"
                    className="flex items-center justify-center text-sm z-10 py-2 px-3 leading-tight text-primary-600 bg-primary-50 border border-slate-300 hover:bg-primary-100 hover:text-primary-700   "
                  >
                    3
                  </a>
                </li>
                <li>
                  <a
                    href="#"
                    className="flex items-center justify-center text-sm py-2 px-3 leading-tight text-gray-500 bg-white border border-slate-300 hover:bg-gray-100 hover:text-gray-700  "
                  >
                    ...
                  </a>
                </li>
                <li>
                  <a
                    href="#"
                    className="flex items-center justify-center text-sm py-2 px-3 leading-tight text-gray-500 bg-white border border-slate-300 hover:bg-gray-100 hover:text-gray-700  "
                  >
                    100
                  </a>
                </li>
                <li>
                  <a
                    href="#"
                    className="flex items-center justify-center h-full py-1.5 px-3 leading-tight text-gray-500 bg-white rounded-r-lg border border-slate-300 hover:bg-gray-100 hover:text-gray-700  "
                  >
                    <span className="sr-only">Next</span>
                    <svg
                      className="w-5 h-5"
                      aria-hidden="true"
                      fill="currentColor"
                      viewBox="0 0 20 20"
                      xmlns="http://www.w3.org/2000/svg"
                    >
                      <path
                        fillRule="evenodd"
                        d="M7.293 14.707a1 1 0 010-1.414L10.586 10 7.293 6.707a1 1 0 011.414-1.414l4 4a1 1 0 010 1.414l-4 4a1 1 0 01-1.414 0z"
                        clipRule="evenodd"
                      />
                    </svg>
                  </a>
                </li>
              </ul>
            </nav>
          </div>


        </div>


      </div>



    </div>
  )
}

export default SMSLog