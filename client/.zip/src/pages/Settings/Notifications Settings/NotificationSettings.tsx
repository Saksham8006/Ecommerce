import React from 'react'
import DefaultLayout from '../../../layout/DefaultLayout'
import Breadcrumb from '../../../components/Breadcrumbs/Breadcrumb'
import { FaHome } from "react-icons/fa";
import Settings_sidebar from '../../../assets/Settings_sidebar.svg'


const NotificationSettings: React.FC = () => {
    return (
        <DefaultLayout>
            <Breadcrumb
                pageName={<h1 className='ml-[42px]'>Notification Settings</h1>}
                icon={<img src={Settings_sidebar} alt="Notification Settings icon" className='max-w-[50%] ml-2 mb-2' />}
                homeIcon={<span className=''><FaHome /></span>}
            />
            <div>NotificationSettings</div>

        </DefaultLayout>
    )
}

export default NotificationSettings