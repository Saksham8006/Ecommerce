import React, { useState, useEffect } from 'react'
import DefaultLayout from '../../../layout/DefaultLayout'
import Breadcrumb from '../../../components/Breadcrumbs/Breadcrumb'
import toast, { Toaster } from 'react-hot-toast';
import { Link } from 'react-router-dom';
import { FaRegEdit } from "react-icons/fa";
import { FaHome } from "react-icons/fa";
import { FaPlus } from "react-icons/fa6";
import { IoChevronDown } from "react-icons/io5";
import inventory_sidebar from '../../../assets/inventory_sidebar.svg'
import { RiDeleteBin6Line } from "react-icons/ri";
import { GiShieldDisabled } from "react-icons/gi";
import '../../../../src/Zinventory.css'
import axios from 'axios';
import { inventoryBackendUrl } from '../../../Configmain';


interface Data {
    consumptionNumber: string;
    consumptionType: string;
    consumptionDate: string;
    grandTotal: string;
    location: string;
    userName: string;
    _id: string;

}

const PosSettings: React.FC = () => {
    const [data, setData] = useState<Data[]>([]);
    const token = localStorage.getItem("authorization")

    const [isChecked, setIsChecked] = useState(false)

    const handleCheckboxChange = () => {
        setIsChecked(!isChecked)
    }



    useEffect(() => {

        const fetchingMaterialConsuption = async () => {
            try {
                const response = await axios.get(`${inventoryBackendUrl}/bhghg`, {
                    headers: {
                        "Authorization": `${token}`
                    }
                })

                if (response.status === 200) {
                    console.log("response from material ", response.data.data)
                    setData(response.data.data)
                }

            } catch (error) {

            }
        }
        fetchingMaterialConsuption();
    }, [])




    return (
        <DefaultLayout>
            <Breadcrumb
                pageName={<h1 className='ml-[42px]'>PosSettings</h1>}
                icon={<img src={inventory_sidebar} alt="Settings icon" className='max-w-[50%] ml-2 mb-2' />}
                homeIcon={<span className=''><FaHome /></span>}
            />




            <Toaster />
            <div className="mx-auto bg-white px-[24px] my-[24px]  border-b border-slate-300">

                <div>
                    <div>
                        <>
                            {/* component */}
                            {/* @author: Hackcharms */}
                            <style
                                dangerouslySetInnerHTML={{
                                    __html:
                                        "\n    input:checked ~ .radio {\n  color:white;\n  background-color: green;\n}\n"
                                }}
                            />
                            <div className="flex px-[12px] py-[20px]">

                                <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4  gap-10 w-full">

                                    <div className="bg-gray-200 rounded-lg bg-gray-200">
                                        <h3 className='font-[500] text-[15px] text-black whitespace-nowrap color'>File Attachment Mandatory</h3>
                                        <label className='toggle-label border-lg'>
                                            <input type='checkbox' />
                                            <span className='back'>
                                                <span className='toggle'></span>
                                                <span className='label on mt-[-20px]'>YES</span>
                                                <span className='label off  mt-[-20px]'>NO</span>
                                            </span>
                                        </label>
                                    </div>





                                    <div className="bg-gray-200 rounded-lg bg-gray-200">
                                        <h3 className='font-[500] text-[15px] text-black whitespace-nowrap color'>Supplier wise Product Mapping</h3>
                                        <label className='toggle-label border-lg'>
                                            <input type='checkbox' />
                                            <span className='back'>
                                                <span className='toggle'></span>
                                                <span className='label on mt-[-20px]'>YES</span>
                                                <span className='label off  mt-[-20px]'>NO</span>
                                            </span>
                                        </label>
                                    </div>




                                    <div className="bg-gray-200 rounded-lg bg-gray-200">
                                        <h3 className='font-[500] text-[15px] text-black whitespace-nowrap color'>Check Credit Limit</h3>
                                        <label className='toggle-label border-lg'>
                                            <input type='checkbox' />
                                            <span className='back'>
                                                <span className='toggle'></span>
                                                <span className='label on mt-[-20px]'>YES</span>
                                                <span className='label off  mt-[-20px]'>NO</span>
                                            </span>
                                        </label>
                                    </div>




                                    <div className="bg-gray-200 rounded-lg bg-gray-200">
                                        <h3 className='font-[500] text-[15px] text-black whitespace-nowrap color'>Credit Alert</h3>
                                        <label className='toggle-label border-lg'>
                                            <input type='checkbox' />
                                            <span className='back'>
                                                <span className='toggle'></span>
                                                <span className='label on mt-[-20px]'>YES</span>
                                                <span className='label off  mt-[-20px]'>NO</span>
                                            </span>
                                        </label>
                                    </div>




                                    <div className="bg-gray-200 rounded-lg bg-gray-200">
                                        <h3 className='font-[500] text-[15px] text-black whitespace-nowrap color'>PO By Sales Qty</h3>
                                        <label className='toggle-label border-lg'>
                                            <input type='checkbox' />
                                            <span className='back'>
                                                <span className='toggle'></span>
                                                <span className='label on mt-[-20px]'>YES</span>
                                                <span className='label off  mt-[-20px]'>NO</span>
                                            </span>
                                        </label>
                                    </div>




                                    <div className="bg-gray-200 rounded-lg bg-gray-200">
                                        <h3 className='font-[500] text-[15px] text-black whitespace-nowrap color'>Allow Purchase Order Approval</h3>
                                        <label className='toggle-label border-lg'>
                                            <input type='checkbox' />
                                            <span className='back'>
                                                <span className='toggle'></span>
                                                <span className='label on mt-[-20px]'>YES</span>
                                                <span className='label off  mt-[-20px]'>NO</span>
                                            </span>
                                        </label>
                                    </div>



                                    {/* bg-gray-200 */}
                                    <div>
                                        <label
                                            htmlFor="select_brand"
                                            className='font-[500] text-[15px] text-black whitespace-nowrap color'
                                        >
                                            Purchase Default Focus On
                                        </label>

                                        <select
                                            id="bank"
                                            // value={paymentMode}
                                            // onChange={handleChange}
                                            className="bg-white border border-slate-300 text-gray-900 text-sm rounded-lg  block w-full px-2 py-[8px] mt-3 "
                                        >
                                            <option selected>Search Bank</option>
                                            <option value="cash">Cash</option>
                                            <option value="cheque">Cheque</option>
                                            <option value="dds">DDS</option>
                                            <option value="DE">E-Commerce Operator</option>
                                            <option value="DE">UIN Holders</option>
                                        </select>
                                    </div>




                                    <div className="bg-gray-200 rounded-lg bg-gray-200">
                                        <h3 className='font-[500] text-[15px] text-black whitespace-nowrap color'>Allow Purchase Merge Same Item</h3>
                                        <label className='toggle-label border-lg'>
                                            <input type='checkbox' />
                                            <span className='back'>
                                                <span className='toggle'></span>
                                                <span className='label on mt-[-20px]'>ON</span>
                                                <span className='label off  mt-[-20px]'>OFF</span>
                                            </span>
                                        </label>
                                    </div>


                                </div>
                            </div>
                        </>
                    </div>
                </div>
            </div>


            <div className="mx-auto px-[24px] bg-white py-[24px] my-[24px] mb-[50px]">

                <div className='border-b border-slate-300'>
                    <span className='text-[16px] font-[500] text-[#2ac3df] py-[25px]'>Advance Setting</span>
                </div>
                {/* Start coding here */}
                <div className="bg-white  relative  overflow-hidden mt-[40px]">
                    <div className="grid grid-cols-1 sm:grid-cols-2 md:grid-cols-4 border-b gap-x-[15px] border-slate-300 items-center justify-between space-y-3 md:space-y-0 md:space-x-4 py-[12px] px-[32px]">

                        <div className='flex justify-between  text-black font-medium  items-center gap-[20px]'>
                            <label>Sales Man</label>
                            <label
                                htmlFor="sales_man"
                                className="flex items-center cursor-pointer "
                            >
                                <div className="relative">
                                    <input type="checkbox" id="sales_man" className="peer sr-only" />
                                    <div className="block h-[22px] rounded-full bg-slate-400  w-[50px]" />
                                    <div className="absolute flex items-center justify-center w-[24px] h-[20px] transition bg-white  rounded-full dot  left-[1px] top-[1px] peer-checked:translate-x-full peer-checked:bg-green-600">
                                        {isChecked === false ?

                                            <svg
                                                width={7}
                                                height={5}
                                                viewBox="0 0 11 8"
                                                fill="none"
                                                xmlns="http://www.w3.org/2000/svg"
                                            >
                                                <path
                                                    d="M10.0915 0.951972L10.0867 0.946075L10.0813 0.940568C9.90076 0.753564 9.61034 0.753146 9.42927 0.939309L4.16201 6.22962L1.58507 3.63469C1.40401 3.44841 1.11351 3.44879 0.932892 3.63584C0.755703 3.81933 0.755703 4.10875 0.932892 4.29224L0.932878 4.29225L0.934851 4.29424L3.58046 6.95832C3.73676 7.11955 3.94983 7.2 4.1473 7.2C4.36196 7.2 4.55963 7.11773 4.71406 6.9584L10.0468 1.60234C10.2436 1.4199 10.2421 1.1339 10.0915 0.951972ZM4.2327 6.30081L4.2317 6.2998C4.23206 6.30015 4.23237 6.30049 4.23269 6.30082L4.2327 6.30081Z"
                                                    fill="white"
                                                    stroke="white"
                                                    strokeWidth="0.4"
                                                />
                                            </svg>
                                            :

                                            <svg
                                                className="w-4 h-4 stroke-current"
                                                fill="none"
                                                viewBox="0 0 24 24"
                                                xmlns="http://www.w3.org/2000/svg"
                                            >
                                                <path
                                                    strokeLinecap="round"
                                                    strokeLinejoin="round"
                                                    strokeWidth={2}
                                                    d="M6 18L18 6M6 6l12 12"
                                                />
                                            </svg>

                                        }
                                    </div>
                                </div>
                            </label>
                        </div>

                        <div className='flex justify-between  text-black font-medium  items-center gap-[20px]'>
                            <label>Qty</label>
                            <label
                                htmlFor="Qty"
                                className="flex items-center cursor-pointer "
                            >
                                <div className="relative">
                                    <input type="checkbox" id="Qty" className="peer sr-only" />
                                    <div className="block h-[22px] rounded-full bg-slate-400  w-[50px]" />
                                    <div className="absolute flex items-center justify-center w-[24px] h-[20px] transition bg-white  rounded-full dot  left-[1px] top-[1px] peer-checked:translate-x-full peer-checked:bg-green-600">
                                        {isChecked === false ?

                                            <svg
                                                width={11}
                                                height={8}
                                                viewBox="0 0 11 8"
                                                fill="none"
                                                xmlns="http://www.w3.org/2000/svg"
                                            >
                                                <path
                                                    d="M10.0915 0.951972L10.0867 0.946075L10.0813 0.940568C9.90076 0.753564 9.61034 0.753146 9.42927 0.939309L4.16201 6.22962L1.58507 3.63469C1.40401 3.44841 1.11351 3.44879 0.932892 3.63584C0.755703 3.81933 0.755703 4.10875 0.932892 4.29224L0.932878 4.29225L0.934851 4.29424L3.58046 6.95832C3.73676 7.11955 3.94983 7.2 4.1473 7.2C4.36196 7.2 4.55963 7.11773 4.71406 6.9584L10.0468 1.60234C10.2436 1.4199 10.2421 1.1339 10.0915 0.951972ZM4.2327 6.30081L4.2317 6.2998C4.23206 6.30015 4.23237 6.30049 4.23269 6.30082L4.2327 6.30081Z"
                                                    fill="white"
                                                    stroke="white"
                                                    strokeWidth="0.4"
                                                />
                                            </svg>
                                            :

                                            <svg
                                                className="w-4 h-4 stroke-current"
                                                fill="none"
                                                viewBox="0 0 24 24"
                                                xmlns="http://www.w3.org/2000/svg"
                                            >
                                                <path
                                                    strokeLinecap="round"
                                                    strokeLinejoin="round"
                                                    strokeWidth={2}
                                                    d="M6 18L18 6M6 6l12 12"
                                                />
                                            </svg>

                                        }
                                    </div>
                                </div>
                            </label>
                        </div>
                        <div className='flex justify-between  text-black font-medium  items-center gap-[20px]'>
                            <label>MRP</label>
                            <label
                                htmlFor="MRP"
                                className="flex items-center cursor-pointer "
                            >
                                <div className="relative">
                                    <input type="checkbox" id="MRP" className="peer sr-only" />
                                    <div className="block h-[22px] rounded-full bg-slate-400  w-[50px]" />
                                    <div className="absolute flex items-center justify-center w-[24px] h-[20px] transition bg-white  rounded-full dot  left-[1px] top-[1px] peer-checked:translate-x-full peer-checked:bg-green-600">
                                        {isChecked === false ?

                                            <svg
                                                width={11}
                                                height={8}
                                                viewBox="0 0 11 8"
                                                fill="none"
                                                xmlns="http://www.w3.org/2000/svg"
                                            >
                                                <path
                                                    d="M10.0915 0.951972L10.0867 0.946075L10.0813 0.940568C9.90076 0.753564 9.61034 0.753146 9.42927 0.939309L4.16201 6.22962L1.58507 3.63469C1.40401 3.44841 1.11351 3.44879 0.932892 3.63584C0.755703 3.81933 0.755703 4.10875 0.932892 4.29224L0.932878 4.29225L0.934851 4.29424L3.58046 6.95832C3.73676 7.11955 3.94983 7.2 4.1473 7.2C4.36196 7.2 4.55963 7.11773 4.71406 6.9584L10.0468 1.60234C10.2436 1.4199 10.2421 1.1339 10.0915 0.951972ZM4.2327 6.30081L4.2317 6.2998C4.23206 6.30015 4.23237 6.30049 4.23269 6.30082L4.2327 6.30081Z"
                                                    fill="white"
                                                    stroke="white"
                                                    strokeWidth="0.4"
                                                />
                                            </svg>
                                            :

                                            <svg
                                                className="w-4 h-4 stroke-current"
                                                fill="none"
                                                viewBox="0 0 24 24"
                                                xmlns="http://www.w3.org/2000/svg"
                                            >
                                                <path
                                                    strokeLinecap="round"
                                                    strokeLinejoin="round"
                                                    strokeWidth={2}
                                                    d="M6 18L18 6M6 6l12 12"
                                                />
                                            </svg>

                                        }
                                    </div>
                                </div>
                            </label>
                        </div>
                        <div className='flex justify-between  text-black font-medium  items-center gap-[20px]'>
                            <label>Tax Amount</label>
                            <label
                                htmlFor="Tax_Amount"
                                className="flex items-center cursor-pointer "
                            >
                                <div className="relative">
                                    <input type="checkbox" id="Tax_Amount" className="peer sr-only" />
                                    <div className="block h-[22px] rounded-full bg-slate-400  w-[50px]" />
                                    <div className="absolute flex items-center justify-center w-[24px] h-[20px] transition bg-white  rounded-full dot  left-[1px] top-[1px] peer-checked:translate-x-full peer-checked:bg-green-600">
                                        {isChecked === false ?

                                            <svg
                                                width={11}
                                                height={8}
                                                viewBox="0 0 11 8"
                                                fill="none"
                                                xmlns="http://www.w3.org/2000/svg"
                                            >
                                                <path
                                                    d="M10.0915 0.951972L10.0867 0.946075L10.0813 0.940568C9.90076 0.753564 9.61034 0.753146 9.42927 0.939309L4.16201 6.22962L1.58507 3.63469C1.40401 3.44841 1.11351 3.44879 0.932892 3.63584C0.755703 3.81933 0.755703 4.10875 0.932892 4.29224L0.932878 4.29225L0.934851 4.29424L3.58046 6.95832C3.73676 7.11955 3.94983 7.2 4.1473 7.2C4.36196 7.2 4.55963 7.11773 4.71406 6.9584L10.0468 1.60234C10.2436 1.4199 10.2421 1.1339 10.0915 0.951972ZM4.2327 6.30081L4.2317 6.2998C4.23206 6.30015 4.23237 6.30049 4.23269 6.30082L4.2327 6.30081Z"
                                                    fill="white"
                                                    stroke="white"
                                                    strokeWidth="0.4"
                                                />
                                            </svg>
                                            :

                                            <svg
                                                className="w-4 h-4 stroke-current"
                                                fill="none"
                                                viewBox="0 0 24 24"
                                                xmlns="http://www.w3.org/2000/svg"
                                            >
                                                <path
                                                    strokeLinecap="round"
                                                    strokeLinejoin="round"
                                                    strokeWidth={2}
                                                    d="M6 18L18 6M6 6l12 12"
                                                />
                                            </svg>

                                        }
                                    </div>
                                </div>
                            </label>
                        </div>
                    </div>
                </div>

                <div className="bg-white  relative  overflow-hidden ">
                    <div className="grid grid-cols-1 sm:grid-cols-2 md:grid-cols-4  border-b gap-x-[15px] border-slate-300 items-center justify-between space-y-3 md:space-y-0 md:space-x-4 py-[12px] px-[32px]">

                        <div className='flex justify-between  text-black font-medium  items-center gap-[20px]'>
                            <label>Additional Charge</label>
                            <label
                                htmlFor="Additional_Charge"
                                className="flex items-center cursor-pointer "
                            >
                                <div className="relative">
                                    <input type="checkbox" id="Additional_Charge" className="peer sr-only" />
                                    <div className="block h-[22px] rounded-full bg-slate-400  w-[50px]" />
                                    <div className="absolute flex items-center justify-center w-[24px] h-[20px] transition bg-white  rounded-full dot  left-[1px] top-[1px] peer-checked:translate-x-full peer-checked:bg-green-600">
                                        {isChecked === false ?

                                            <svg
                                                width={11}
                                                height={8}
                                                viewBox="0 0 11 8"
                                                fill="none"
                                                xmlns="http://www.w3.org/2000/svg"
                                            >
                                                <path
                                                    d="M10.0915 0.951972L10.0867 0.946075L10.0813 0.940568C9.90076 0.753564 9.61034 0.753146 9.42927 0.939309L4.16201 6.22962L1.58507 3.63469C1.40401 3.44841 1.11351 3.44879 0.932892 3.63584C0.755703 3.81933 0.755703 4.10875 0.932892 4.29224L0.932878 4.29225L0.934851 4.29424L3.58046 6.95832C3.73676 7.11955 3.94983 7.2 4.1473 7.2C4.36196 7.2 4.55963 7.11773 4.71406 6.9584L10.0468 1.60234C10.2436 1.4199 10.2421 1.1339 10.0915 0.951972ZM4.2327 6.30081L4.2317 6.2998C4.23206 6.30015 4.23237 6.30049 4.23269 6.30082L4.2327 6.30081Z"
                                                    fill="white"
                                                    stroke="white"
                                                    strokeWidth="0.4"
                                                />
                                            </svg>
                                            :

                                            <svg
                                                className="w-4 h-4 stroke-current"
                                                fill="none"
                                                viewBox="0 0 24 24"
                                                xmlns="http://www.w3.org/2000/svg"
                                            >
                                                <path
                                                    strokeLinecap="round"
                                                    strokeLinejoin="round"
                                                    strokeWidth={2}
                                                    d="M6 18L18 6M6 6l12 12"
                                                />
                                            </svg>

                                        }
                                    </div>
                                </div>
                            </label>
                        </div>

                        <div className='flex justify-between  text-black font-medium  items-center gap-[20px]'>
                            <label>Flat Discount</label>
                            <label
                                htmlFor="Flat_Discount"
                                className="flex items-center cursor-pointer "
                            >
                                <div className="relative">
                                    <input type="checkbox" id="Flat_Discount" className="peer sr-only" />
                                    <div className="block h-[22px] rounded-full bg-slate-400  w-[50px]" />
                                    <div className="absolute flex items-center justify-center w-[24px] h-[20px] transition bg-white  rounded-full dot  left-[1px] top-[1px] peer-checked:translate-x-full peer-checked:bg-green-600">
                                        {isChecked === false ?

                                            <svg
                                                width={11}
                                                height={8}
                                                viewBox="0 0 11 8"
                                                fill="none"
                                                xmlns="http://www.w3.org/2000/svg"
                                            >
                                                <path
                                                    d="M10.0915 0.951972L10.0867 0.946075L10.0813 0.940568C9.90076 0.753564 9.61034 0.753146 9.42927 0.939309L4.16201 6.22962L1.58507 3.63469C1.40401 3.44841 1.11351 3.44879 0.932892 3.63584C0.755703 3.81933 0.755703 4.10875 0.932892 4.29224L0.932878 4.29225L0.934851 4.29424L3.58046 6.95832C3.73676 7.11955 3.94983 7.2 4.1473 7.2C4.36196 7.2 4.55963 7.11773 4.71406 6.9584L10.0468 1.60234C10.2436 1.4199 10.2421 1.1339 10.0915 0.951972ZM4.2327 6.30081L4.2317 6.2998C4.23206 6.30015 4.23237 6.30049 4.23269 6.30082L4.2327 6.30081Z"
                                                    fill="white"
                                                    stroke="white"
                                                    strokeWidth="0.4"
                                                />
                                            </svg>
                                            :

                                            <svg
                                                className="w-4 h-4 stroke-current"
                                                fill="none"
                                                viewBox="0 0 24 24"
                                                xmlns="http://www.w3.org/2000/svg"
                                            >
                                                <path
                                                    strokeLinecap="round"
                                                    strokeLinejoin="round"
                                                    strokeWidth={2}
                                                    d="M6 18L18 6M6 6l12 12"
                                                />
                                            </svg>

                                        }
                                    </div>
                                </div>
                            </label>
                        </div>
                        <div className='flex justify-between  text-black font-medium  items-center gap-[20px]'>
                            <label>RoundOff</label>
                            <label
                                htmlFor="RoundOff"
                                className="flex items-center cursor-pointer "
                            >
                                <div className="relative">
                                    <input type="checkbox" id="RoundOff" className="peer sr-only" />
                                    <div className="block h-[22px] rounded-full bg-slate-400  w-[50px]" />
                                    <div className="absolute flex items-center justify-center w-[24px] h-[20px] transition bg-white  rounded-full dot  left-[1px] top-[1px] peer-checked:translate-x-full peer-checked:bg-green-600">
                                        {isChecked === false ?

                                            <svg
                                                width={11}
                                                height={8}
                                                viewBox="0 0 11 8"
                                                fill="none"
                                                xmlns="http://www.w3.org/2000/svg"
                                            >
                                                <path
                                                    d="M10.0915 0.951972L10.0867 0.946075L10.0813 0.940568C9.90076 0.753564 9.61034 0.753146 9.42927 0.939309L4.16201 6.22962L1.58507 3.63469C1.40401 3.44841 1.11351 3.44879 0.932892 3.63584C0.755703 3.81933 0.755703 4.10875 0.932892 4.29224L0.932878 4.29225L0.934851 4.29424L3.58046 6.95832C3.73676 7.11955 3.94983 7.2 4.1473 7.2C4.36196 7.2 4.55963 7.11773 4.71406 6.9584L10.0468 1.60234C10.2436 1.4199 10.2421 1.1339 10.0915 0.951972ZM4.2327 6.30081L4.2317 6.2998C4.23206 6.30015 4.23237 6.30049 4.23269 6.30082L4.2327 6.30081Z"
                                                    fill="white"
                                                    stroke="white"
                                                    strokeWidth="0.4"
                                                />
                                            </svg>
                                            :

                                            <svg
                                                className="w-4 h-4 stroke-current"
                                                fill="none"
                                                viewBox="0 0 24 24"
                                                xmlns="http://www.w3.org/2000/svg"
                                            >
                                                <path
                                                    strokeLinecap="round"
                                                    strokeLinejoin="round"
                                                    strokeWidth={2}
                                                    d="M6 18L18 6M6 6l12 12"
                                                />
                                            </svg>

                                        }
                                    </div>
                                </div>
                            </label>
                        </div>
                        <div className='flex justify-between  text-black font-medium  items-center gap-[20px]'>
                            <label>MultiPay</label>
                            <label
                                htmlFor="MultiPay"
                                className="flex items-center cursor-pointer "
                            >
                                <div className="relative">
                                    <input type="checkbox" id="MultiPay" className="peer sr-only" />
                                    <div className="block h-[22px] rounded-full bg-slate-400  w-[50px]" />
                                    <div className="absolute flex items-center justify-center w-[24px] h-[20px] transition bg-white  rounded-full dot  left-[1px] top-[1px] peer-checked:translate-x-full peer-checked:bg-green-600">
                                        {isChecked === false ?

                                            <svg
                                                width={11}
                                                height={8}
                                                viewBox="0 0 11 8"
                                                fill="none"
                                                xmlns="http://www.w3.org/2000/svg"
                                            >
                                                <path
                                                    d="M10.0915 0.951972L10.0867 0.946075L10.0813 0.940568C9.90076 0.753564 9.61034 0.753146 9.42927 0.939309L4.16201 6.22962L1.58507 3.63469C1.40401 3.44841 1.11351 3.44879 0.932892 3.63584C0.755703 3.81933 0.755703 4.10875 0.932892 4.29224L0.932878 4.29225L0.934851 4.29424L3.58046 6.95832C3.73676 7.11955 3.94983 7.2 4.1473 7.2C4.36196 7.2 4.55963 7.11773 4.71406 6.9584L10.0468 1.60234C10.2436 1.4199 10.2421 1.1339 10.0915 0.951972ZM4.2327 6.30081L4.2317 6.2998C4.23206 6.30015 4.23237 6.30049 4.23269 6.30082L4.2327 6.30081Z"
                                                    fill="white"
                                                    stroke="white"
                                                    strokeWidth="0.4"
                                                />
                                            </svg>
                                            :

                                            <svg
                                                className="w-4 h-4 stroke-current"
                                                fill="none"
                                                viewBox="0 0 24 24"
                                                xmlns="http://www.w3.org/2000/svg"
                                            >
                                                <path
                                                    strokeLinecap="round"
                                                    strokeLinejoin="round"
                                                    strokeWidth={2}
                                                    d="M6 18L18 6M6 6l12 12"
                                                />
                                            </svg>

                                        }
                                    </div>
                                </div>
                            </label>
                        </div>
                    </div>
                </div>


                <div className="bg-white  relative  overflow-hidden ">
                    <div className="grid grid-cols-1 sm:grid-cols-2 md:grid-cols-4  border-b gap-x-[15px] border-slate-300 items-center justify-between space-y-3 md:space-y-0 md:space-x-4 py-[12px] px-[32px]">

                        <div className='flex justify-between  text-black font-medium  items-center gap-[20px]'>
                            <label>Redeem Credit</label>
                            <label
                                htmlFor="Redeem_Credit"
                                className="flex items-center cursor-pointer "
                            >
                                <div className="relative">
                                    <input type="checkbox" id="Redeem_Credit" className="peer sr-only" />
                                    <div className="block h-[22px] rounded-full bg-slate-400  w-[50px]" />
                                    <div className="absolute flex items-center justify-center w-[24px] h-[20px] transition bg-white  rounded-full dot  left-[1px] top-[1px] peer-checked:translate-x-full peer-checked:bg-green-600">
                                        {isChecked === false ?

                                            <svg
                                                width={11}
                                                height={8}
                                                viewBox="0 0 11 8"
                                                fill="none"
                                                xmlns="http://www.w3.org/2000/svg"
                                            >
                                                <path
                                                    d="M10.0915 0.951972L10.0867 0.946075L10.0813 0.940568C9.90076 0.753564 9.61034 0.753146 9.42927 0.939309L4.16201 6.22962L1.58507 3.63469C1.40401 3.44841 1.11351 3.44879 0.932892 3.63584C0.755703 3.81933 0.755703 4.10875 0.932892 4.29224L0.932878 4.29225L0.934851 4.29424L3.58046 6.95832C3.73676 7.11955 3.94983 7.2 4.1473 7.2C4.36196 7.2 4.55963 7.11773 4.71406 6.9584L10.0468 1.60234C10.2436 1.4199 10.2421 1.1339 10.0915 0.951972ZM4.2327 6.30081L4.2317 6.2998C4.23206 6.30015 4.23237 6.30049 4.23269 6.30082L4.2327 6.30081Z"
                                                    fill="white"
                                                    stroke="white"
                                                    strokeWidth="0.4"
                                                />
                                            </svg>
                                            :

                                            <svg
                                                className="w-4 h-4 stroke-current"
                                                fill="none"
                                                viewBox="0 0 24 24"
                                                xmlns="http://www.w3.org/2000/svg"
                                            >
                                                <path
                                                    strokeLinecap="round"
                                                    strokeLinejoin="round"
                                                    strokeWidth={2}
                                                    d="M6 18L18 6M6 6l12 12"
                                                />
                                            </svg>

                                        }
                                    </div>
                                </div>
                            </label>
                        </div>

                        <div className='flex justify-between  text-black font-medium  items-center gap-[20px]'>
                            <label>UPI</label>
                            <label
                                htmlFor="UPI"
                                className="flex items-center cursor-pointer "
                            >
                                <div className="relative">
                                    <input type="checkbox" id="UPI" className="peer sr-only" />
                                    <div className="block h-[22px] rounded-full bg-slate-400  w-[50px]" />
                                    <div className="absolute flex items-center justify-center w-[24px] h-[20px] transition bg-white  rounded-full dot  left-[1px] top-[1px] peer-checked:translate-x-full peer-checked:bg-green-600">
                                        {isChecked === false ?

                                            <svg
                                                width={11}
                                                height={8}
                                                viewBox="0 0 11 8"
                                                fill="none"
                                                xmlns="http://www.w3.org/2000/svg"
                                            >
                                                <path
                                                    d="M10.0915 0.951972L10.0867 0.946075L10.0813 0.940568C9.90076 0.753564 9.61034 0.753146 9.42927 0.939309L4.16201 6.22962L1.58507 3.63469C1.40401 3.44841 1.11351 3.44879 0.932892 3.63584C0.755703 3.81933 0.755703 4.10875 0.932892 4.29224L0.932878 4.29225L0.934851 4.29424L3.58046 6.95832C3.73676 7.11955 3.94983 7.2 4.1473 7.2C4.36196 7.2 4.55963 7.11773 4.71406 6.9584L10.0468 1.60234C10.2436 1.4199 10.2421 1.1339 10.0915 0.951972ZM4.2327 6.30081L4.2317 6.2998C4.23206 6.30015 4.23237 6.30049 4.23269 6.30082L4.2327 6.30081Z"
                                                    fill="white"
                                                    stroke="white"
                                                    strokeWidth="0.4"
                                                />
                                            </svg>
                                            :

                                            <svg
                                                className="w-4 h-4 stroke-current"
                                                fill="none"
                                                viewBox="0 0 24 24"
                                                xmlns="http://www.w3.org/2000/svg"
                                            >
                                                <path
                                                    strokeLinecap="round"
                                                    strokeLinejoin="round"
                                                    strokeWidth={2}
                                                    d="M6 18L18 6M6 6l12 12"
                                                />
                                            </svg>

                                        }
                                    </div>
                                </div>
                            </label>
                        </div>
                        <div className='flex justify-between  text-black font-medium  items-center gap-[20px]'>
                            <label>Card</label>
                            <label
                                htmlFor="Card"
                                className="flex items-center cursor-pointer "
                            >
                                <div className="relative">
                                    <input type="checkbox" id="Card" className="peer sr-only" />
                                    <div className="block h-[22px] rounded-full bg-slate-400  w-[50px]" />
                                    <div className="absolute flex items-center justify-center w-[24px] h-[20px] transition bg-white  rounded-full dot  left-[1px] top-[1px] peer-checked:translate-x-full peer-checked:bg-green-600">
                                        {isChecked === false ?

                                            <svg
                                                width={11}
                                                height={8}
                                                viewBox="0 0 11 8"
                                                fill="none"
                                                xmlns="http://www.w3.org/2000/svg"
                                            >
                                                <path
                                                    d="M10.0915 0.951972L10.0867 0.946075L10.0813 0.940568C9.90076 0.753564 9.61034 0.753146 9.42927 0.939309L4.16201 6.22962L1.58507 3.63469C1.40401 3.44841 1.11351 3.44879 0.932892 3.63584C0.755703 3.81933 0.755703 4.10875 0.932892 4.29224L0.932878 4.29225L0.934851 4.29424L3.58046 6.95832C3.73676 7.11955 3.94983 7.2 4.1473 7.2C4.36196 7.2 4.55963 7.11773 4.71406 6.9584L10.0468 1.60234C10.2436 1.4199 10.2421 1.1339 10.0915 0.951972ZM4.2327 6.30081L4.2317 6.2998C4.23206 6.30015 4.23237 6.30049 4.23269 6.30082L4.2327 6.30081Z"
                                                    fill="white"
                                                    stroke="white"
                                                    strokeWidth="0.4"
                                                />
                                            </svg>
                                            :

                                            <svg
                                                className="w-4 h-4 stroke-current"
                                                fill="none"
                                                viewBox="0 0 24 24"
                                                xmlns="http://www.w3.org/2000/svg"
                                            >
                                                <path
                                                    strokeLinecap="round"
                                                    strokeLinejoin="round"
                                                    strokeWidth={2}
                                                    d="M6 18L18 6M6 6l12 12"
                                                />
                                            </svg>

                                        }
                                    </div>
                                </div>
                            </label>
                        </div>
                        <div className='flex justify-between  text-black font-medium  items-center gap-[20px]'>
                            <label>Cash</label>
                            <label
                                htmlFor="Cash"
                                className="flex items-center cursor-pointer "
                            >
                                <div className="relative">
                                    <input type="checkbox" id="Cash" className="peer sr-only" />
                                    <div className="block h-[22px] rounded-full bg-slate-400  w-[50px]" />
                                    <div className="absolute flex items-center justify-center w-[24px] h-[20px] transition bg-white  rounded-full dot  left-[1px] top-[1px] peer-checked:translate-x-full peer-checked:bg-green-600">
                                        {isChecked === false ?

                                            <svg
                                                width={11}
                                                height={8}
                                                viewBox="0 0 11 8"
                                                fill="none"
                                                xmlns="http://www.w3.org/2000/svg"
                                            >
                                                <path
                                                    d="M10.0915 0.951972L10.0867 0.946075L10.0813 0.940568C9.90076 0.753564 9.61034 0.753146 9.42927 0.939309L4.16201 6.22962L1.58507 3.63469C1.40401 3.44841 1.11351 3.44879 0.932892 3.63584C0.755703 3.81933 0.755703 4.10875 0.932892 4.29224L0.932878 4.29225L0.934851 4.29424L3.58046 6.95832C3.73676 7.11955 3.94983 7.2 4.1473 7.2C4.36196 7.2 4.55963 7.11773 4.71406 6.9584L10.0468 1.60234C10.2436 1.4199 10.2421 1.1339 10.0915 0.951972ZM4.2327 6.30081L4.2317 6.2998C4.23206 6.30015 4.23237 6.30049 4.23269 6.30082L4.2327 6.30081Z"
                                                    fill="white"
                                                    stroke="white"
                                                    strokeWidth="0.4"
                                                />
                                            </svg>
                                            :

                                            <svg
                                                className="w-4 h-4 stroke-current"
                                                fill="none"
                                                viewBox="0 0 24 24"
                                                xmlns="http://www.w3.org/2000/svg"
                                            >
                                                <path
                                                    strokeLinecap="round"
                                                    strokeLinejoin="round"
                                                    strokeWidth={2}
                                                    d="M6 18L18 6M6 6l12 12"
                                                />
                                            </svg>

                                        }
                                    </div>
                                </div>
                            </label>
                        </div>
                    </div>
                </div>

                <div className="bg-white  relative  overflow-hidden ">
                    <div className="grid grid-cols-1 sm:grid-cols-2 md:grid-cols-4  border-b gap-x-[15px] border-slate-300 items-center justify-between space-y-3 md:space-y-0 md:space-x-4 py-[12px] px-[32px]">

                        <div className='flex justify-between  text-black font-medium  items-center gap-[20px]'>
                            <label>Apply Coupon</label>
                            <label
                                htmlFor="Apply Coupon"
                                className="flex items-center cursor-pointer "
                            >
                                <div className="relative">
                                    <input type="checkbox" id="Apply Coupon" className="peer sr-only" />
                                    <div className="block h-[22px] rounded-full bg-slate-400  w-[50px]" />
                                    <div className="absolute flex items-center justify-center w-[24px] h-[20px] transition bg-white  rounded-full dot  left-[1px] top-[1px] peer-checked:translate-x-full peer-checked:bg-green-600">
                                        {isChecked === false ?

                                            <svg
                                                width={11}
                                                height={8}
                                                viewBox="0 0 11 8"
                                                fill="none"
                                                xmlns="http://www.w3.org/2000/svg"
                                            >
                                                <path
                                                    d="M10.0915 0.951972L10.0867 0.946075L10.0813 0.940568C9.90076 0.753564 9.61034 0.753146 9.42927 0.939309L4.16201 6.22962L1.58507 3.63469C1.40401 3.44841 1.11351 3.44879 0.932892 3.63584C0.755703 3.81933 0.755703 4.10875 0.932892 4.29224L0.932878 4.29225L0.934851 4.29424L3.58046 6.95832C3.73676 7.11955 3.94983 7.2 4.1473 7.2C4.36196 7.2 4.55963 7.11773 4.71406 6.9584L10.0468 1.60234C10.2436 1.4199 10.2421 1.1339 10.0915 0.951972ZM4.2327 6.30081L4.2317 6.2998C4.23206 6.30015 4.23237 6.30049 4.23269 6.30082L4.2327 6.30081Z"
                                                    fill="white"
                                                    stroke="white"
                                                    strokeWidth="0.4"
                                                />
                                            </svg>
                                            :

                                            <svg
                                                className="w-4 h-4 stroke-current"
                                                fill="none"
                                                viewBox="0 0 24 24"
                                                xmlns="http://www.w3.org/2000/svg"
                                            >
                                                <path
                                                    strokeLinecap="round"
                                                    strokeLinejoin="round"
                                                    strokeWidth={2}
                                                    d="M6 18L18 6M6 6l12 12"
                                                />
                                            </svg>

                                        }
                                    </div>
                                </div>
                            </label>
                        </div>

                        <div className='flex justify-between  text-black font-medium  items-center gap-[20px]'>
                            <label>Pay Later</label>
                            <label
                                htmlFor="Pay_Later"
                                className="flex items-center cursor-pointer "
                            >
                                <div className="relative">
                                    <input type="checkbox" id="Pay_Later" className="peer sr-only" />
                                    <div className="block h-[22px] rounded-full bg-slate-400  w-[50px]" />
                                    <div className="absolute flex items-center justify-center w-[24px] h-[20px] transition bg-white  rounded-full dot  left-[1px] top-[1px] peer-checked:translate-x-full peer-checked:bg-green-600">
                                        {isChecked === false ?

                                            <svg
                                                width={11}
                                                height={8}
                                                viewBox="0 0 11 8"
                                                fill="none"
                                                xmlns="http://www.w3.org/2000/svg"
                                            >
                                                <path
                                                    d="M10.0915 0.951972L10.0867 0.946075L10.0813 0.940568C9.90076 0.753564 9.61034 0.753146 9.42927 0.939309L4.16201 6.22962L1.58507 3.63469C1.40401 3.44841 1.11351 3.44879 0.932892 3.63584C0.755703 3.81933 0.755703 4.10875 0.932892 4.29224L0.932878 4.29225L0.934851 4.29424L3.58046 6.95832C3.73676 7.11955 3.94983 7.2 4.1473 7.2C4.36196 7.2 4.55963 7.11773 4.71406 6.9584L10.0468 1.60234C10.2436 1.4199 10.2421 1.1339 10.0915 0.951972ZM4.2327 6.30081L4.2317 6.2998C4.23206 6.30015 4.23237 6.30049 4.23269 6.30082L4.2327 6.30081Z"
                                                    fill="white"
                                                    stroke="white"
                                                    strokeWidth="0.4"
                                                />
                                            </svg>
                                            :

                                            <svg
                                                className="w-4 h-4 stroke-current"
                                                fill="none"
                                                viewBox="0 0 24 24"
                                                xmlns="http://www.w3.org/2000/svg"
                                            >
                                                <path
                                                    strokeLinecap="round"
                                                    strokeLinejoin="round"
                                                    strokeWidth={2}
                                                    d="M6 18L18 6M6 6l12 12"
                                                />
                                            </svg>

                                        }
                                    </div>
                                </div>
                            </label>
                        </div>
                        <div className='flex justify-between  text-black font-medium  items-center gap-[20px]'>
                            <label>Hold & Print</label>
                            <label
                                htmlFor="Hold & Print"
                                className="flex items-center cursor-pointer "
                            >
                                <div className="relative">
                                    <input type="checkbox" id="Hold & Print" className="peer sr-only" />
                                    <div className="block h-[22px] rounded-full bg-slate-400  w-[50px]" />
                                    <div className="absolute flex items-center justify-center w-[24px] h-[20px] transition bg-white  rounded-full dot  left-[1px] top-[1px] peer-checked:translate-x-full peer-checked:bg-green-600">
                                        {isChecked === false ?

                                            <svg
                                                width={11}
                                                height={8}
                                                viewBox="0 0 11 8"
                                                fill="none"
                                                xmlns="http://www.w3.org/2000/svg"
                                            >
                                                <path
                                                    d="M10.0915 0.951972L10.0867 0.946075L10.0813 0.940568C9.90076 0.753564 9.61034 0.753146 9.42927 0.939309L4.16201 6.22962L1.58507 3.63469C1.40401 3.44841 1.11351 3.44879 0.932892 3.63584C0.755703 3.81933 0.755703 4.10875 0.932892 4.29224L0.932878 4.29225L0.934851 4.29424L3.58046 6.95832C3.73676 7.11955 3.94983 7.2 4.1473 7.2C4.36196 7.2 4.55963 7.11773 4.71406 6.9584L10.0468 1.60234C10.2436 1.4199 10.2421 1.1339 10.0915 0.951972ZM4.2327 6.30081L4.2317 6.2998C4.23206 6.30015 4.23237 6.30049 4.23269 6.30082L4.2327 6.30081Z"
                                                    fill="white"
                                                    stroke="white"
                                                    strokeWidth="0.4"
                                                />
                                            </svg>
                                            :

                                            <svg
                                                className="w-4 h-4 stroke-current"
                                                fill="none"
                                                viewBox="0 0 24 24"
                                                xmlns="http://www.w3.org/2000/svg"
                                            >
                                                <path
                                                    strokeLinecap="round"
                                                    strokeLinejoin="round"
                                                    strokeWidth={2}
                                                    d="M6 18L18 6M6 6l12 12"
                                                />
                                            </svg>

                                        }
                                    </div>
                                </div>
                            </label>
                        </div>
                        <div className='flex justify-between  text-black font-medium  items-center gap-[20px]'>
                            <label>UPI & Print</label>
                            <label
                                htmlFor="UPI_Print"
                                className="flex items-center cursor-pointer "
                            >
                                <div className="relative">
                                    <input type="checkbox" id="UPI_Print" className="peer sr-only" />
                                    <div className="block h-[22px] rounded-full bg-slate-400  w-[50px]" />
                                    <div className="absolute flex items-center justify-center w-[24px] h-[20px] transition bg-white  rounded-full dot  left-[1px] top-[1px] peer-checked:translate-x-full peer-checked:bg-green-600">
                                        {isChecked === false ?

                                            <svg
                                                width={11}
                                                height={8}
                                                viewBox="0 0 11 8"
                                                fill="none"
                                                xmlns="http://www.w3.org/2000/svg"
                                            >
                                                <path
                                                    d="M10.0915 0.951972L10.0867 0.946075L10.0813 0.940568C9.90076 0.753564 9.61034 0.753146 9.42927 0.939309L4.16201 6.22962L1.58507 3.63469C1.40401 3.44841 1.11351 3.44879 0.932892 3.63584C0.755703 3.81933 0.755703 4.10875 0.932892 4.29224L0.932878 4.29225L0.934851 4.29424L3.58046 6.95832C3.73676 7.11955 3.94983 7.2 4.1473 7.2C4.36196 7.2 4.55963 7.11773 4.71406 6.9584L10.0468 1.60234C10.2436 1.4199 10.2421 1.1339 10.0915 0.951972ZM4.2327 6.30081L4.2317 6.2998C4.23206 6.30015 4.23237 6.30049 4.23269 6.30082L4.2327 6.30081Z"
                                                    fill="white"
                                                    stroke="white"
                                                    strokeWidth="0.4"
                                                />
                                            </svg>
                                            :

                                            <svg
                                                className="w-4 h-4 stroke-current"
                                                fill="none"
                                                viewBox="0 0 24 24"
                                                xmlns="http://www.w3.org/2000/svg"
                                            >
                                                <path
                                                    strokeLinecap="round"
                                                    strokeLinejoin="round"
                                                    strokeWidth={2}
                                                    d="M6 18L18 6M6 6l12 12"
                                                />
                                            </svg>

                                        }
                                    </div>
                                </div>
                            </label>
                        </div>
                    </div>
                </div>


                <div className="bg-white  relative  overflow-hidden ">
                    <div className="grid grid-cols-1 sm:grid-cols-2 md:grid-cols-4  border-b gap-x-[15px] border-slate-300 items-center justify-between space-y-3 md:space-y-0 md:space-x-4 py-[12px] px-[32px]">

                        <div className='flex justify-between  text-black font-medium  items-center gap-[20px]'>
                            <label>Card & Print</label>
                            <label
                                htmlFor="Card_Print"
                                className="flex items-center cursor-pointer "
                            >
                                <div className="relative">
                                    <input type="checkbox" id="Card_Print" className="peer sr-only" />
                                    <div className="block h-[22px] rounded-full bg-slate-400  w-[50px]" />
                                    <div className="absolute flex items-center justify-center w-[24px] h-[20px] transition bg-white  rounded-full dot  left-[1px] top-[1px] peer-checked:translate-x-full peer-checked:bg-green-600">
                                        {isChecked === false ?

                                            <svg
                                                width={11}
                                                height={8}
                                                viewBox="0 0 11 8"
                                                fill="none"
                                                xmlns="http://www.w3.org/2000/svg"
                                            >
                                                <path
                                                    d="M10.0915 0.951972L10.0867 0.946075L10.0813 0.940568C9.90076 0.753564 9.61034 0.753146 9.42927 0.939309L4.16201 6.22962L1.58507 3.63469C1.40401 3.44841 1.11351 3.44879 0.932892 3.63584C0.755703 3.81933 0.755703 4.10875 0.932892 4.29224L0.932878 4.29225L0.934851 4.29424L3.58046 6.95832C3.73676 7.11955 3.94983 7.2 4.1473 7.2C4.36196 7.2 4.55963 7.11773 4.71406 6.9584L10.0468 1.60234C10.2436 1.4199 10.2421 1.1339 10.0915 0.951972ZM4.2327 6.30081L4.2317 6.2998C4.23206 6.30015 4.23237 6.30049 4.23269 6.30082L4.2327 6.30081Z"
                                                    fill="white"
                                                    stroke="white"
                                                    strokeWidth="0.4"
                                                />
                                            </svg>
                                            :

                                            <svg
                                                className="w-4 h-4 stroke-current"
                                                fill="none"
                                                viewBox="0 0 24 24"
                                                xmlns="http://www.w3.org/2000/svg"
                                            >
                                                <path
                                                    strokeLinecap="round"
                                                    strokeLinejoin="round"
                                                    strokeWidth={2}
                                                    d="M6 18L18 6M6 6l12 12"
                                                />
                                            </svg>

                                        }
                                    </div>
                                </div>
                            </label>
                        </div>

                        <div className='flex justify-between  text-black font-medium  items-center gap-[20px]'>
                            <label>Cash & Print</label>
                            <label
                                htmlFor="Cash_Later"
                                className="flex items-center cursor-pointer "
                            >
                                <div className="relative">
                                    <input type="checkbox" id="Cash_Later" className="peer sr-only" />
                                    <div className="block h-[22px] rounded-full bg-slate-400  w-[50px]" />
                                    <div className="absolute flex items-center justify-center w-[24px] h-[20px] transition bg-white  rounded-full dot  left-[1px] top-[1px] peer-checked:translate-x-full peer-checked:bg-green-600">
                                        {isChecked === false ?

                                            <svg
                                                width={11}
                                                height={8}
                                                viewBox="0 0 11 8"
                                                fill="none"
                                                xmlns="http://www.w3.org/2000/svg"
                                            >
                                                <path
                                                    d="M10.0915 0.951972L10.0867 0.946075L10.0813 0.940568C9.90076 0.753564 9.61034 0.753146 9.42927 0.939309L4.16201 6.22962L1.58507 3.63469C1.40401 3.44841 1.11351 3.44879 0.932892 3.63584C0.755703 3.81933 0.755703 4.10875 0.932892 4.29224L0.932878 4.29225L0.934851 4.29424L3.58046 6.95832C3.73676 7.11955 3.94983 7.2 4.1473 7.2C4.36196 7.2 4.55963 7.11773 4.71406 6.9584L10.0468 1.60234C10.2436 1.4199 10.2421 1.1339 10.0915 0.951972ZM4.2327 6.30081L4.2317 6.2998C4.23206 6.30015 4.23237 6.30049 4.23269 6.30082L4.2327 6.30081Z"
                                                    fill="white"
                                                    stroke="white"
                                                    strokeWidth="0.4"
                                                />
                                            </svg>
                                            :

                                            <svg
                                                className="w-4 h-4 stroke-current"
                                                fill="none"
                                                viewBox="0 0 24 24"
                                                xmlns="http://www.w3.org/2000/svg"
                                            >
                                                <path
                                                    strokeLinecap="round"
                                                    strokeLinejoin="round"
                                                    strokeWidth={2}
                                                    d="M6 18L18 6M6 6l12 12"
                                                />
                                            </svg>

                                        }
                                    </div>
                                </div>
                            </label>
                        </div>
                        <div className='flex justify-between  text-black font-medium  items-center gap-[20px]'>
                            <label>Hold Bill</label>
                            <label
                                htmlFor="Hold_Bill"
                                className="flex items-center cursor-pointer "
                            >
                                <div className="relative">
                                    <input type="checkbox" id="Hold_Bill" className="peer sr-only" />
                                    <div className="block h-[22px] rounded-full bg-slate-400  w-[50px]" />
                                    <div className="absolute flex items-center justify-center w-[24px] h-[20px] transition bg-white  rounded-full dot  left-[1px] top-[1px] peer-checked:translate-x-full peer-checked:bg-green-600">
                                        {isChecked === false ?

                                            <svg
                                                width={11}
                                                height={8}
                                                viewBox="0 0 11 8"
                                                fill="none"
                                                xmlns="http://www.w3.org/2000/svg"
                                            >
                                                <path
                                                    d="M10.0915 0.951972L10.0867 0.946075L10.0813 0.940568C9.90076 0.753564 9.61034 0.753146 9.42927 0.939309L4.16201 6.22962L1.58507 3.63469C1.40401 3.44841 1.11351 3.44879 0.932892 3.63584C0.755703 3.81933 0.755703 4.10875 0.932892 4.29224L0.932878 4.29225L0.934851 4.29424L3.58046 6.95832C3.73676 7.11955 3.94983 7.2 4.1473 7.2C4.36196 7.2 4.55963 7.11773 4.71406 6.9584L10.0468 1.60234C10.2436 1.4199 10.2421 1.1339 10.0915 0.951972ZM4.2327 6.30081L4.2317 6.2998C4.23206 6.30015 4.23237 6.30049 4.23269 6.30082L4.2327 6.30081Z"
                                                    fill="white"
                                                    stroke="white"
                                                    strokeWidth="0.4"
                                                />
                                            </svg>
                                            :

                                            <svg
                                                className="w-4 h-4 stroke-current"
                                                fill="none"
                                                viewBox="0 0 24 24"
                                                xmlns="http://www.w3.org/2000/svg"
                                            >
                                                <path
                                                    strokeLinecap="round"
                                                    strokeLinejoin="round"
                                                    strokeWidth={2}
                                                    d="M6 18L18 6M6 6l12 12"
                                                />
                                            </svg>

                                        }
                                    </div>
                                </div>
                            </label>
                        </div>
                        <div className='flex justify-between  text-black font-medium  items-center gap-[20px]'>
                            <label>Reedem Loyalty</label>
                            <label
                                htmlFor="Reedem_Loyalty"
                                className="flex items-center cursor-pointer "
                            >
                                <div className="relative">
                                    <input type="checkbox" id="Reedem_Loyalty" className="peer sr-only" />
                                    <div className="block h-[22px] rounded-full bg-slate-400  w-[50px]" />
                                    <div className="absolute flex items-center justify-center w-[24px] h-[20px] transition bg-white  rounded-full dot  left-[1px] top-[1px] peer-checked:translate-x-full peer-checked:bg-green-600">
                                        {isChecked === false ?

                                            <svg
                                                width={11}
                                                height={8}
                                                viewBox="0 0 11 8"
                                                fill="none"
                                                xmlns="http://www.w3.org/2000/svg"
                                            >
                                                <path
                                                    d="M10.0915 0.951972L10.0867 0.946075L10.0813 0.940568C9.90076 0.753564 9.61034 0.753146 9.42927 0.939309L4.16201 6.22962L1.58507 3.63469C1.40401 3.44841 1.11351 3.44879 0.932892 3.63584C0.755703 3.81933 0.755703 4.10875 0.932892 4.29224L0.932878 4.29225L0.934851 4.29424L3.58046 6.95832C3.73676 7.11955 3.94983 7.2 4.1473 7.2C4.36196 7.2 4.55963 7.11773 4.71406 6.9584L10.0468 1.60234C10.2436 1.4199 10.2421 1.1339 10.0915 0.951972ZM4.2327 6.30081L4.2317 6.2998C4.23206 6.30015 4.23237 6.30049 4.23269 6.30082L4.2327 6.30081Z"
                                                    fill="white"
                                                    stroke="white"
                                                    strokeWidth="0.4"
                                                />
                                            </svg>
                                            :

                                            <svg
                                                className="w-4 h-4 stroke-current"
                                                fill="none"
                                                viewBox="0 0 24 24"
                                                xmlns="http://www.w3.org/2000/svg"
                                            >
                                                <path
                                                    strokeLinecap="round"
                                                    strokeLinejoin="round"
                                                    strokeWidth={2}
                                                    d="M6 18L18 6M6 6l12 12"
                                                />
                                            </svg>

                                        }
                                    </div>
                                </div>
                            </label>
                        </div>
                    </div>
                </div>


                <div className="bg-white  relative  overflow-hidden ">
                    <div className="grid grid-cols-1 sm:grid-cols-2 md:grid-cols-4  border-b gap-x-[15px] border-slate-300 items-center justify-between space-y-3 md:space-y-0 md:space-x-4 py-[12px] px-[32px]">

                        <div className='flex justify-between  text-black font-medium  items-center gap-[20px]'>
                            <label>Add Payment</label>
                            <label
                                htmlFor="Add_Payment"
                                className="flex items-center cursor-pointer "
                            >
                                <div className="relative">
                                    <input type="checkbox" id="Add_Payment" className="peer sr-only" />
                                    <div className="block h-[22px] rounded-full bg-slate-400  w-[50px]" />
                                    <div className="absolute flex items-center justify-center w-[24px] h-[20px] transition bg-white  rounded-full dot  left-[1px] top-[1px] peer-checked:translate-x-full peer-checked:bg-green-600">
                                        {isChecked === false ?

                                            <svg
                                                width={11}
                                                height={8}
                                                viewBox="0 0 11 8"
                                                fill="none"
                                                xmlns="http://www.w3.org/2000/svg"
                                            >
                                                <path
                                                    d="M10.0915 0.951972L10.0867 0.946075L10.0813 0.940568C9.90076 0.753564 9.61034 0.753146 9.42927 0.939309L4.16201 6.22962L1.58507 3.63469C1.40401 3.44841 1.11351 3.44879 0.932892 3.63584C0.755703 3.81933 0.755703 4.10875 0.932892 4.29224L0.932878 4.29225L0.934851 4.29424L3.58046 6.95832C3.73676 7.11955 3.94983 7.2 4.1473 7.2C4.36196 7.2 4.55963 7.11773 4.71406 6.9584L10.0468 1.60234C10.2436 1.4199 10.2421 1.1339 10.0915 0.951972ZM4.2327 6.30081L4.2317 6.2998C4.23206 6.30015 4.23237 6.30049 4.23269 6.30082L4.2327 6.30081Z"
                                                    fill="white"
                                                    stroke="white"
                                                    strokeWidth="0.4"
                                                />
                                            </svg>
                                            :

                                            <svg
                                                className="w-4 h-4 stroke-current"
                                                fill="none"
                                                viewBox="0 0 24 24"
                                                xmlns="http://www.w3.org/2000/svg"
                                            >
                                                <path
                                                    strokeLinecap="round"
                                                    strokeLinejoin="round"
                                                    strokeWidth={2}
                                                    d="M6 18L18 6M6 6l12 12"
                                                />
                                            </svg>

                                        }
                                    </div>
                                </div>
                            </label>
                        </div>

                        <div className='flex justify-between  text-black font-medium  items-center gap-[20px]'>
                            <label>Credit Note</label>
                            <label
                                htmlFor="Credit_Note"
                                className="flex items-center cursor-pointer "
                            >
                                <div className="relative">
                                    <input type="checkbox" id="Credit_Note" className="peer sr-only" />
                                    <div className="block h-[22px] rounded-full bg-slate-400  w-[50px]" />
                                    <div className="absolute flex items-center justify-center w-[24px] h-[20px] transition bg-white  rounded-full dot  left-[1px] top-[1px] peer-checked:translate-x-full peer-checked:bg-green-600">
                                        {isChecked === false ?

                                            <svg
                                                width={11}
                                                height={8}
                                                viewBox="0 0 11 8"
                                                fill="none"
                                                xmlns="http://www.w3.org/2000/svg"
                                            >
                                                <path
                                                    d="M10.0915 0.951972L10.0867 0.946075L10.0813 0.940568C9.90076 0.753564 9.61034 0.753146 9.42927 0.939309L4.16201 6.22962L1.58507 3.63469C1.40401 3.44841 1.11351 3.44879 0.932892 3.63584C0.755703 3.81933 0.755703 4.10875 0.932892 4.29224L0.932878 4.29225L0.934851 4.29424L3.58046 6.95832C3.73676 7.11955 3.94983 7.2 4.1473 7.2C4.36196 7.2 4.55963 7.11773 4.71406 6.9584L10.0468 1.60234C10.2436 1.4199 10.2421 1.1339 10.0915 0.951972ZM4.2327 6.30081L4.2317 6.2998C4.23206 6.30015 4.23237 6.30049 4.23269 6.30082L4.2327 6.30081Z"
                                                    fill="white"
                                                    stroke="white"
                                                    strokeWidth="0.4"
                                                />
                                            </svg>
                                            :

                                            <svg
                                                className="w-4 h-4 stroke-current"
                                                fill="none"
                                                viewBox="0 0 24 24"
                                                xmlns="http://www.w3.org/2000/svg"
                                            >
                                                <path
                                                    strokeLinecap="round"
                                                    strokeLinejoin="round"
                                                    strokeWidth={2}
                                                    d="M6 18L18 6M6 6l12 12"
                                                />
                                            </svg>

                                        }
                                    </div>
                                </div>
                            </label>
                        </div>
                        <div className='flex justify-between  text-black font-medium  items-center gap-[20px]'>
                            <label>Orders</label>
                            <label
                                htmlFor="Orders"
                                className="flex items-center cursor-pointer "
                            >
                                <div className="relative">
                                    <input type="checkbox" id="Orders" className="peer sr-only" />
                                    <div className="block h-[22px] rounded-full bg-slate-400  w-[50px]" />
                                    <div className="absolute flex items-center justify-center w-[24px] h-[20px] transition bg-white  rounded-full dot  left-[1px] top-[1px] peer-checked:translate-x-full peer-checked:bg-green-600">
                                        {isChecked === false ?

                                            <svg
                                                width={11}
                                                height={8}
                                                viewBox="0 0 11 8"
                                                fill="none"
                                                xmlns="http://www.w3.org/2000/svg"
                                            >
                                                <path
                                                    d="M10.0915 0.951972L10.0867 0.946075L10.0813 0.940568C9.90076 0.753564 9.61034 0.753146 9.42927 0.939309L4.16201 6.22962L1.58507 3.63469C1.40401 3.44841 1.11351 3.44879 0.932892 3.63584C0.755703 3.81933 0.755703 4.10875 0.932892 4.29224L0.932878 4.29225L0.934851 4.29424L3.58046 6.95832C3.73676 7.11955 3.94983 7.2 4.1473 7.2C4.36196 7.2 4.55963 7.11773 4.71406 6.9584L10.0468 1.60234C10.2436 1.4199 10.2421 1.1339 10.0915 0.951972ZM4.2327 6.30081L4.2317 6.2998C4.23206 6.30015 4.23237 6.30049 4.23269 6.30082L4.2327 6.30081Z"
                                                    fill="white"
                                                    stroke="white"
                                                    strokeWidth="0.4"
                                                />
                                            </svg>
                                            :

                                            <svg
                                                className="w-4 h-4 stroke-current"
                                                fill="none"
                                                viewBox="0 0 24 24"
                                                xmlns="http://www.w3.org/2000/svg"
                                            >
                                                <path
                                                    strokeLinecap="round"
                                                    strokeLinejoin="round"
                                                    strokeWidth={2}
                                                    d="M6 18L18 6M6 6l12 12"
                                                />
                                            </svg>

                                        }
                                    </div>
                                </div>
                            </label>
                        </div>
                        <div className='flex justify-between  text-black font-medium  items-center gap-[20px]'>
                            <label>Customer Details</label>
                            <label
                                htmlFor="Customer_Details"
                                className="flex items-center cursor-pointer "
                            >
                                <div className="relative">
                                    <input type="checkbox" id="Customer_Details" className="peer sr-only" />
                                    <div className="block h-[22px] rounded-full bg-slate-400  w-[50px]" />
                                    <div className="absolute flex items-center justify-center w-[24px] h-[20px] transition bg-white  rounded-full dot  left-[1px] top-[1px] peer-checked:translate-x-full peer-checked:bg-green-600">
                                        {isChecked === false ?

                                            <svg
                                                width={11}
                                                height={8}
                                                viewBox="0 0 11 8"
                                                fill="none"
                                                xmlns="http://www.w3.org/2000/svg"
                                            >
                                                <path
                                                    d="M10.0915 0.951972L10.0867 0.946075L10.0813 0.940568C9.90076 0.753564 9.61034 0.753146 9.42927 0.939309L4.16201 6.22962L1.58507 3.63469C1.40401 3.44841 1.11351 3.44879 0.932892 3.63584C0.755703 3.81933 0.755703 4.10875 0.932892 4.29224L0.932878 4.29225L0.934851 4.29424L3.58046 6.95832C3.73676 7.11955 3.94983 7.2 4.1473 7.2C4.36196 7.2 4.55963 7.11773 4.71406 6.9584L10.0468 1.60234C10.2436 1.4199 10.2421 1.1339 10.0915 0.951972ZM4.2327 6.30081L4.2317 6.2998C4.23206 6.30015 4.23237 6.30049 4.23269 6.30082L4.2327 6.30081Z"
                                                    fill="white"
                                                    stroke="white"
                                                    strokeWidth="0.4"
                                                />
                                            </svg>
                                            :

                                            <svg
                                                className="w-4 h-4 stroke-current"
                                                fill="none"
                                                viewBox="0 0 24 24"
                                                xmlns="http://www.w3.org/2000/svg"
                                            >
                                                <path
                                                    strokeLinecap="round"
                                                    strokeLinejoin="round"
                                                    strokeWidth={2}
                                                    d="M6 18L18 6M6 6l12 12"
                                                />
                                            </svg>

                                        }
                                    </div>
                                </div>
                            </label>
                        </div>
                    </div>
                </div>



                <div className="bg-white  relative  overflow-hidden ">
                    <div className="grid grid-cols-1 sm:grid-cols-2 md:grid-cols-4  border-b gap-x-[15px] border-slate-300 items-center justify-between space-y-3 md:space-y-0 md:space-x-4 py-[12px] px-[32px]">

                        <div className='flex justify-between  text-black font-medium  items-center gap-[20px]'>
                            <label>Additional Discount</label>
                            <label
                                htmlFor="Additional_Discount"
                                className="flex items-center cursor-pointer "
                            >
                                <div className="relative">
                                    <input type="checkbox" id="Additional_Discount" className="peer sr-only" />
                                    <div className="block h-[22px] rounded-full bg-slate-400  w-[50px]" />
                                    <div className="absolute flex items-center justify-center w-[24px] h-[20px] transition bg-white  rounded-full dot  left-[1px] top-[1px] peer-checked:translate-x-full peer-checked:bg-green-600">
                                        {isChecked === false ?

                                            <svg
                                                width={11}
                                                height={8}
                                                viewBox="0 0 11 8"
                                                fill="none"
                                                xmlns="http://www.w3.org/2000/svg"
                                            >
                                                <path
                                                    d="M10.0915 0.951972L10.0867 0.946075L10.0813 0.940568C9.90076 0.753564 9.61034 0.753146 9.42927 0.939309L4.16201 6.22962L1.58507 3.63469C1.40401 3.44841 1.11351 3.44879 0.932892 3.63584C0.755703 3.81933 0.755703 4.10875 0.932892 4.29224L0.932878 4.29225L0.934851 4.29424L3.58046 6.95832C3.73676 7.11955 3.94983 7.2 4.1473 7.2C4.36196 7.2 4.55963 7.11773 4.71406 6.9584L10.0468 1.60234C10.2436 1.4199 10.2421 1.1339 10.0915 0.951972ZM4.2327 6.30081L4.2317 6.2998C4.23206 6.30015 4.23237 6.30049 4.23269 6.30082L4.2327 6.30081Z"
                                                    fill="white"
                                                    stroke="white"
                                                    strokeWidth="0.4"
                                                />
                                            </svg>
                                            :

                                            <svg
                                                className="w-4 h-4 stroke-current"
                                                fill="none"
                                                viewBox="0 0 24 24"
                                                xmlns="http://www.w3.org/2000/svg"
                                            >
                                                <path
                                                    strokeLinecap="round"
                                                    strokeLinejoin="round"
                                                    strokeWidth={2}
                                                    d="M6 18L18 6M6 6l12 12"
                                                />
                                            </svg>

                                        }
                                    </div>
                                </div>
                            </label>
                        </div>

                        <div className='flex justify-between  text-black font-medium  items-center gap-[20px]'>
                            <label>Bill Discount</label>
                            <label
                                htmlFor="Bill_Discount"
                                className="flex items-center cursor-pointer "
                            >
                                <div className="relative">
                                    <input type="checkbox" id="Bill_Discount" className="peer sr-only" />
                                    <div className="block h-[22px] rounded-full bg-slate-400  w-[50px]" />
                                    <div className="absolute flex items-center justify-center w-[24px] h-[20px] transition bg-white  rounded-full dot  left-[1px] top-[1px] peer-checked:translate-x-full peer-checked:bg-green-600">
                                        {isChecked === false ?

                                            <svg
                                                width={11}
                                                height={8}
                                                viewBox="0 0 11 8"
                                                fill="none"
                                                xmlns="http://www.w3.org/2000/svg"
                                            >
                                                <path
                                                    d="M10.0915 0.951972L10.0867 0.946075L10.0813 0.940568C9.90076 0.753564 9.61034 0.753146 9.42927 0.939309L4.16201 6.22962L1.58507 3.63469C1.40401 3.44841 1.11351 3.44879 0.932892 3.63584C0.755703 3.81933 0.755703 4.10875 0.932892 4.29224L0.932878 4.29225L0.934851 4.29424L3.58046 6.95832C3.73676 7.11955 3.94983 7.2 4.1473 7.2C4.36196 7.2 4.55963 7.11773 4.71406 6.9584L10.0468 1.60234C10.2436 1.4199 10.2421 1.1339 10.0915 0.951972ZM4.2327 6.30081L4.2317 6.2998C4.23206 6.30015 4.23237 6.30049 4.23269 6.30082L4.2327 6.30081Z"
                                                    fill="white"
                                                    stroke="white"
                                                    strokeWidth="0.4"
                                                />
                                            </svg>
                                            :

                                            <svg
                                                className="w-4 h-4 stroke-current"
                                                fill="none"
                                                viewBox="0 0 24 24"
                                                xmlns="http://www.w3.org/2000/svg"
                                            >
                                                <path
                                                    strokeLinecap="round"
                                                    strokeLinejoin="round"
                                                    strokeWidth={2}
                                                    d="M6 18L18 6M6 6l12 12"
                                                />
                                            </svg>

                                        }
                                    </div>
                                </div>
                            </label>
                        </div>
                        <div className='flex justify-between  text-black font-medium  items-center gap-[20px]'>
                            <label>Item Code</label>
                            <label
                                htmlFor="Item_Code"
                                className="flex items-center cursor-pointer "
                            >
                                <div className="relative">
                                    <input type="checkbox" id="Item_Code" className="peer sr-only" />
                                    <div className="block h-[22px] rounded-full bg-slate-400  w-[50px]" />
                                    <div className="absolute flex items-center justify-center w-[24px] h-[20px] transition bg-white  rounded-full dot  left-[1px] top-[1px] peer-checked:translate-x-full peer-checked:bg-green-600">
                                        {isChecked === false ?

                                            <svg
                                                width={11}
                                                height={8}
                                                viewBox="0 0 11 8"
                                                fill="none"
                                                xmlns="http://www.w3.org/2000/svg"
                                            >
                                                <path
                                                    d="M10.0915 0.951972L10.0867 0.946075L10.0813 0.940568C9.90076 0.753564 9.61034 0.753146 9.42927 0.939309L4.16201 6.22962L1.58507 3.63469C1.40401 3.44841 1.11351 3.44879 0.932892 3.63584C0.755703 3.81933 0.755703 4.10875 0.932892 4.29224L0.932878 4.29225L0.934851 4.29424L3.58046 6.95832C3.73676 7.11955 3.94983 7.2 4.1473 7.2C4.36196 7.2 4.55963 7.11773 4.71406 6.9584L10.0468 1.60234C10.2436 1.4199 10.2421 1.1339 10.0915 0.951972ZM4.2327 6.30081L4.2317 6.2998C4.23206 6.30015 4.23237 6.30049 4.23269 6.30082L4.2327 6.30081Z"
                                                    fill="white"
                                                    stroke="white"
                                                    strokeWidth="0.4"
                                                />
                                            </svg>
                                            :

                                            <svg
                                                className="w-4 h-4 stroke-current"
                                                fill="none"
                                                viewBox="0 0 24 24"
                                                xmlns="http://www.w3.org/2000/svg"
                                            >
                                                <path
                                                    strokeLinecap="round"
                                                    strokeLinejoin="round"
                                                    strokeWidth={2}
                                                    d="M6 18L18 6M6 6l12 12"
                                                />
                                            </svg>

                                        }
                                    </div>
                                </div>
                            </label>
                        </div>
                        <div className='flex justify-between  text-black font-medium  items-center gap-[20px]'>
                            <label>Last Bill</label>
                            <label
                                htmlFor="Last_Bill"
                                className="flex items-center cursor-pointer "
                            >
                                <div className="relative">
                                    <input type="checkbox" id="Last_Bill" className="peer sr-only" />
                                    <div className="block h-[22px] rounded-full bg-slate-400  w-[50px]" />
                                    <div className="absolute flex items-center justify-center w-[24px] h-[20px] transition bg-white  rounded-full dot  left-[1px] top-[1px] peer-checked:translate-x-full peer-checked:bg-green-600">
                                        {isChecked === false ?

                                            <svg
                                                width={11}
                                                height={8}
                                                viewBox="0 0 11 8"
                                                fill="none"
                                                xmlns="http://www.w3.org/2000/svg"
                                            >
                                                <path
                                                    d="M10.0915 0.951972L10.0867 0.946075L10.0813 0.940568C9.90076 0.753564 9.61034 0.753146 9.42927 0.939309L4.16201 6.22962L1.58507 3.63469C1.40401 3.44841 1.11351 3.44879 0.932892 3.63584C0.755703 3.81933 0.755703 4.10875 0.932892 4.29224L0.932878 4.29225L0.934851 4.29424L3.58046 6.95832C3.73676 7.11955 3.94983 7.2 4.1473 7.2C4.36196 7.2 4.55963 7.11773 4.71406 6.9584L10.0468 1.60234C10.2436 1.4199 10.2421 1.1339 10.0915 0.951972ZM4.2327 6.30081L4.2317 6.2998C4.23206 6.30015 4.23237 6.30049 4.23269 6.30082L4.2327 6.30081Z"
                                                    fill="white"
                                                    stroke="white"
                                                    strokeWidth="0.4"
                                                />
                                            </svg>
                                            :

                                            <svg
                                                className="w-4 h-4 stroke-current"
                                                fill="none"
                                                viewBox="0 0 24 24"
                                                xmlns="http://www.w3.org/2000/svg"
                                            >
                                                <path
                                                    strokeLinecap="round"
                                                    strokeLinejoin="round"
                                                    strokeWidth={2}
                                                    d="M6 18L18 6M6 6l12 12"
                                                />
                                            </svg>

                                        }
                                    </div>
                                </div>
                            </label>
                        </div>
                    </div>
                </div>




                <div className="bg-white  relative  overflow-hidden ">
                    <div className="grid grid-cols-1 sm:grid-cols-2  md:grid-cols-4  border-b gap-x-[15px] border-slate-300 items-center justify-between space-y-3 md:space-y-0 md:space-x-4 py-[12px] px-[32px]">


                        <div className='flex justify-between  text-black font-medium  items-center gap-[20px]'>
                            <label>Order Type</label>
                            <label
                                htmlFor="Order_Type"
                                className="flex items-center cursor-pointer "
                            >
                                <div className="relative">
                                    <input type="checkbox" id="Order_Type" className="peer sr-only" />
                                    <div className="block h-[22px] rounded-full bg-slate-400  w-[50px]" />
                                    <div className="absolute flex items-center justify-center w-[24px] h-[20px] transition bg-white  rounded-full dot  left-[1px] top-[1px] peer-checked:translate-x-full peer-checked:bg-green-600">
                                        {isChecked === false ?

                                            <svg
                                                width={11}
                                                height={8}
                                                viewBox="0 0 11 8"
                                                fill="none"
                                                xmlns="http://www.w3.org/2000/svg"
                                            >
                                                <path
                                                    d="M10.0915 0.951972L10.0867 0.946075L10.0813 0.940568C9.90076 0.753564 9.61034 0.753146 9.42927 0.939309L4.16201 6.22962L1.58507 3.63469C1.40401 3.44841 1.11351 3.44879 0.932892 3.63584C0.755703 3.81933 0.755703 4.10875 0.932892 4.29224L0.932878 4.29225L0.934851 4.29424L3.58046 6.95832C3.73676 7.11955 3.94983 7.2 4.1473 7.2C4.36196 7.2 4.55963 7.11773 4.71406 6.9584L10.0468 1.60234C10.2436 1.4199 10.2421 1.1339 10.0915 0.951972ZM4.2327 6.30081L4.2317 6.2998C4.23206 6.30015 4.23237 6.30049 4.23269 6.30082L4.2327 6.30081Z"
                                                    fill="white"
                                                    stroke="white"
                                                    strokeWidth="0.4"
                                                />
                                            </svg>
                                            :

                                            <svg
                                                className="w-4 h-4 stroke-current"
                                                fill="none"
                                                viewBox="0 0 24 24"
                                                xmlns="http://www.w3.org/2000/svg"
                                            >
                                                <path
                                                    strokeLinecap="round"
                                                    strokeLinejoin="round"
                                                    strokeWidth={2}
                                                    d="M6 18L18 6M6 6l12 12"
                                                />
                                            </svg>

                                        }
                                    </div>
                                </div>
                            </label>
                        </div>
                        <div className='flex justify-between  text-black font-medium  items-center gap-[20px]'>
                            <label>OTP Verification on PayLater</label>
                            <label
                                htmlFor="OTP_V"
                                className="flex items-center cursor-pointer"
                            >
                                <div className="relative">
                                    <input type="checkbox" id="OTP_V" className="peer sr-only" />
                                    <div className="block h-[22px] rounded-full bg-slate-400  w-[50px]" />
                                    <div className="absolute flex items-center justify-center w-[24px] h-[20px] transition bg-white  rounded-full dot  left-[1px] top-[1px] peer-checked:translate-x-full peer-checked:bg-green-600">
                                        {isChecked === false ?

                                            <svg
                                                width={11}
                                                height={8}
                                                viewBox="0 0 11 8"
                                                fill="none"
                                                xmlns="http://www.w3.org/2000/svg"
                                            >
                                                <path
                                                    d="M10.0915 0.951972L10.0867 0.946075L10.0813 0.940568C9.90076 0.753564 9.61034 0.753146 9.42927 0.939309L4.16201 6.22962L1.58507 3.63469C1.40401 3.44841 1.11351 3.44879 0.932892 3.63584C0.755703 3.81933 0.755703 4.10875 0.932892 4.29224L0.932878 4.29225L0.934851 4.29424L3.58046 6.95832C3.73676 7.11955 3.94983 7.2 4.1473 7.2C4.36196 7.2 4.55963 7.11773 4.71406 6.9584L10.0468 1.60234C10.2436 1.4199 10.2421 1.1339 10.0915 0.951972ZM4.2327 6.30081L4.2317 6.2998C4.23206 6.30015 4.23237 6.30049 4.23269 6.30082L4.2327 6.30081Z"
                                                    fill="white"
                                                    stroke="white"
                                                    strokeWidth="0.4"
                                                />
                                            </svg>
                                            :

                                            <svg
                                                className="w-4 h-4 stroke-current"
                                                fill="none"
                                                viewBox="0 0 24 24"
                                                xmlns="http://www.w3.org/2000/svg"
                                            >
                                                <path
                                                    strokeLinecap="round"
                                                    strokeLinejoin="round"
                                                    strokeWidth={2}
                                                    d="M6 18L18 6M6 6l12 12"
                                                />
                                            </svg>

                                        }
                                    </div>
                                </div>
                            </label>
                        </div>
                    </div>
                </div>
            </div >


            <Toaster />
            <div className="mx-auto bg-white px-[24px] my-[24px]  border-b border-slate-300">

                <div>
                    <div>
                        <>
                            {/* component */}
                            {/* @author: Hackcharms */}
                            <style
                                dangerouslySetInnerHTML={{
                                    __html:
                                        "\n    input:checked ~ .radio {\n  color:white;\n  background-color: green;\n}\n"
                                }}
                            />
                            <div className="flex px-[12px] py-[20px]">

                                <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4  gap-10 w-full">

                                    <div className="bg-gray-200 rounded-lg bg-gray-200">
                                        <h3 className='font-[500] text-[15px] text-black whitespace-nowrap color'>View all Terminal/User Orders</h3>
                                        <label className='toggle-label border-lg'>
                                            <input type='checkbox' />
                                            <span className='back'>
                                                <span className='toggle'></span>
                                                <span className='label on mt-[-20px]'>YES</span>
                                                <span className='label off  mt-[-20px]'>NO</span>
                                            </span>
                                        </label>
                                    </div>





                                    <div className="bg-gray-200 rounded-lg bg-gray-200">
                                        <h3 className='font-[500] text-[15px] text-black whitespace-nowrap color'>Allow Manager Cash Flow</h3>
                                        <label className='toggle-label border-lg'>
                                            <input type='checkbox' />
                                            <span className='back'>
                                                <span className='toggle'></span>
                                                <span className='label on mt-[-20px]'>YES</span>
                                                <span className='label off  mt-[-20px]'>NO</span>
                                            </span>
                                        </label>
                                    </div>




                                    <div className="bg-gray-200 rounded-lg bg-gray-200">
                                        <h3 className='font-[500] text-[15px] text-black whitespace-nowrap color'>Allow user for Take Money Out</h3>
                                        <label className='toggle-label border-lg'>
                                            <input type='checkbox' />
                                            <span className='back'>
                                                <span className='toggle'></span>
                                                <span className='label on mt-[-20px]'>YES</span>
                                                <span className='label off  mt-[-20px]'>NO</span>
                                            </span>
                                        </label>
                                    </div>




                                    <div className="bg-gray-200 rounded-lg bg-gray-200">
                                        <h3 className='font-[500] text-[15px] text-black whitespace-nowrap color'>Select Tender Type</h3>
                                        <label className='toggle-label border-lg'>
                                            <input type='checkbox' />
                                            <span className='back'>
                                                <span className='toggle'></span>
                                                <span className='label on mt-[-20px]'>YES</span>
                                                <span className='label off  mt-[-20px]'>NO</span>
                                            </span>
                                        </label>
                                    </div>




                                    <div className="bg-gray-200 rounded-lg bg-gray-200">
                                        <h3 className='font-[500] text-[15px] text-black whitespace-nowrap color'>Coupon Show</h3>
                                        <label className='toggle-label border-lg'>
                                            <input type='checkbox' />
                                            <span className='back'>
                                                <span className='toggle'></span>
                                                <span className='label on mt-[-20px]'>YES</span>
                                                <span className='label off  mt-[-20px]'>NO</span>
                                            </span>
                                        </label>
                                    </div>




                                    <div className="bg-gray-200 rounded-lg bg-gray-200">
                                        <h3 className='font-[500] text-[15px] text-black whitespace-nowrap color'>
                                            Allow Token Print</h3>
                                        <label className='toggle-label border-lg'>
                                            <input type='checkbox' />
                                            <span className='back'>
                                                <span className='toggle'></span>
                                                <span className='label on mt-[-20px]'>ON</span>
                                                <span className='label off  mt-[-20px]'>OFF</span>
                                            </span>
                                        </label>
                                    </div>






                                    {/* bg-gray-200 */}





                                    <div className="bg-gray-200 rounded-lg bg-gray-200">
                                        <h3 className='font-[500] text-[15px] text-black whitespace-nowrap color'>Customer Details Mandatory</h3>
                                        <label className='toggle-label border-lg'>
                                            <input type='checkbox' />
                                            <span className='back'>
                                                <span className='toggle'></span>
                                                <span className='label on mt-[-20px]'>ON</span>
                                                <span className='label off  mt-[-20px]'>OFF</span>
                                            </span>
                                        </label>
                                    </div>





                                    <div className="bg-gray-200 rounded-lg bg-gray-200">
                                        <h3 className='font-[500] text-[15px] text-black whitespace-nowrap color'>
                                            Allow Token Print</h3>
                                        <label className='toggle-label border-lg'>
                                            <input type='checkbox' />
                                            <span className='back'>
                                                <span className='toggle'></span>
                                                <span className='label on mt-[-20px]'>ON</span>
                                                <span className='label off  mt-[-20px]'>OFF</span>
                                            </span>
                                        </label>
                                    </div>




                                    <div className="bg-gray-200 rounded-lg bg-gray-200 ">
                                        <h3 className='font-[500] text-[15px] text-black whitespace-nowrap color'>
                                            Show Landing Price
                                        </h3>
                                        <label className='toggle-label border-lg'>
                                            <input type='checkbox' />
                                            <span className='back'>
                                                <span className='toggle'></span>
                                                <span className='label on mt-[-20px]'>ON</span>
                                                <span className='label off  mt-[-20px]'>OFF</span>
                                            </span>
                                        </label>
                                    </div>



                                    <div>
                                        <label
                                            htmlFor="select_brand"
                                            className='font-[500] text-[15px] text-black whitespace-nowrap color'
                                        >
                                            Flat Discount Limit
                                        </label>

                                        <select
                                            id="bank"
                                            // value={paymentMode}
                                            // onChange={handleChange}
                                            className="bg-white border border-slate-300 text-gray-900 text-sm rounded-lg  block w-full px-2 py-[8px] mt-3 "
                                        >
                                            <option selected>Search Bank</option>
                                            <option value="cash">Cash</option>
                                            <option value="cheque">Cheque</option>
                                            <option value="dds">DDS</option>
                                            <option value="DE">E-Commerce Operator</option>
                                            <option value="DE">UIN Holders</option>
                                        </select>
                                    </div>

                                </div>
                            </div>
                        </>
                    </div>
                </div>
            </div>

        </DefaultLayout >
    )
}

export default PosSettings