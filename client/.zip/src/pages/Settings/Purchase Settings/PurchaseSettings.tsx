import React, { useState, useEffect } from 'react'
import DefaultLayout from '../../../layout/DefaultLayout'
import Breadcrumb from '../../../components/Breadcrumbs/Breadcrumb'
import toast, { Toaster } from 'react-hot-toast';
import { Link } from 'react-router-dom';
import { FaRegEdit } from "react-icons/fa";
import { FaHome } from "react-icons/fa";
import { FaPlus } from "react-icons/fa6";
import { IoChevronDown } from "react-icons/io5";
import inventory_sidebar from '../../../assets/inventory_sidebar.svg'
import { RiDeleteBin6Line } from "react-icons/ri";
import { GiShieldDisabled } from "react-icons/gi";
import '../../../../src/Zinventory.css'
import axios from 'axios';
import { inventoryBackendUrl } from '../../../Configmain';
import { formatDate } from '../../../Utils/Utils';

interface Data {
    consumptionNumber: string;
    consumptionType: string;
    consumptionDate: string;
    grandTotal: string;
    location: string;
    userName: string;
    _id: string;

}

const PurchaseSettings: React.FC = () => {
    const [data, setData] = useState<Data[]>([]);
    const [membershipBoxOpen, setMembershipBoxOpen] = useState<boolean>(false)
    const token = localStorage.getItem("authorization")


    

    const handleDeleteMaterialCon = async (_id: string) => {
        try {
            const response = await axios.delete(`${inventoryBackendUrl}/api/material-consumption/${_id}`, {
                headers: {
                    "Authorization": `${token}`
                }
            })

            if (response.status === 200) {
                toast.success("Material Consumption Deleted Successfully");
                setData((prevData) => prevData.filter(item => item._id !== _id))
            }
        } catch (error) {
            console.log("error", error)
        }
    }



    useEffect(() => {

        const fetchingMaterialConsuption = async () => {
            try {
                const response = await axios.get(`${inventoryBackendUrl}/api/material-consumption`, {
                    headers: {
                        "Authorization": `${token}`
                    }
                })

                if (response.status === 200) {
                    console.log("response from material ", response.data.data)
                    setData(response.data.data)
                }

            } catch (error) {

            }
        }
        fetchingMaterialConsuption();
    }, [])




    return (
        <DefaultLayout>
            <Breadcrumb
                pageName={<h1 className='ml-[42px]'>PurchaseSettings</h1>}
                icon={<img src={inventory_sidebar} alt="Settings icon" className='max-w-[50%] ml-2 mb-2' />}
                homeIcon={<span className=''><FaHome /></span>}
            />




            <Toaster />
            <div className="mx-auto bg-white px-[24px] my-[24px]  border-b border-slate-300">

                <div>
                    <div>
                        <>
                            {/* component */}
                            {/* @author: Hackcharms */}
                            <style
                                dangerouslySetInnerHTML={{
                                    __html:
                                        "\n    input:checked ~ .radio {\n  color:white;\n  background-color: green;\n}\n"
                                }}
                            />
                            <div className="flex px-[12px] py-[20px]">

                                <div className="grid grid-cols-4 gap-10">
                                    <div className='one'>
                                    <div className="bg-gray-200 rounded-lg bg-gray-200">
                                        <h3 className='font-[500] text-[15px] text-black whitespace-nowrap color'>File Attachment Mandatory</h3>
                                        <label className='toggle-label border-lg'>
                                            <input type='checkbox' />
                                            <span className='back'>
                                                <span className='toggle'></span>
                                                <span className='label on mt-[-20px]'>YES</span>
                                                <span className='label off  mt-[-20px]'>NO</span>
                                            </span>
                                        </label>
                                    </div>
                                    </div>
                                    


                                    <div className='two'>
                                    <div className="bg-gray-200 rounded-lg bg-gray-200">
                                        <h3 className='font-[500] text-[15px] text-black whitespace-nowrap color'>Supplier wise Product Mapping</h3>
                                        <label className='toggle-label border-lg'>
                                            <input type='checkbox' />
                                            <span className='back'>
                                                <span className='toggle'></span>
                                                <span className='label on mt-[-20px]'>YES</span>
                                                <span className='label off  mt-[-20px]'>NO</span>
                                            </span>
                                        </label>
                                    </div>
                                    </div>


                                    <div className='three'>
                                    <div className="bg-gray-200 rounded-lg bg-gray-200">
                                        <h3 className='font-[500] text-[15px] text-black whitespace-nowrap color'>Check Credit Limit</h3>
                                        <label className='toggle-label border-lg'>
                                            <input type='checkbox' />
                                            <span className='back'>
                                                <span className='toggle'></span>
                                                <span className='label on mt-[-20px]'>ON</span>
                                                <span className='label off  mt-[-20px]'>OFF</span>
                                            </span>
                                        </label>
                                    </div>
                                    </div>


                                    <div className='four'>
                                    <div className="bg-gray-200 rounded-lg bg-gray-200">
                                        <h3 className='font-[500] text-[15px] text-black whitespace-nowrap color'>Credit Alert</h3>
                                        <label className='toggle-label border-lg'>
                                            <input type='checkbox' />
                                            <span className='back'>
                                                <span className='toggle'></span>
                                                <span className='label on mt-[-20px]'>YES</span>
                                                <span className='label off  mt-[-20px]'>NO</span>
                                            </span>
                                        </label>
                                    </div>
                                    </div>


                                    <div className='fifth'>
                                    <div className="bg-gray-200 rounded-lg bg-gray-200">
                                        <h3 className='font-[500] text-[15px] text-black whitespace-nowrap color'>PO By Sales Qty</h3>
                                        <label className='toggle-label border-lg'>
                                            <input type='checkbox' />
                                            <span className='back'>
                                                <span className='toggle'></span>
                                                <span className='label on mt-[-20px]'>YES</span>
                                                <span className='label off  mt-[-20px]'>NO</span>
                                            </span>
                                        </label>
                                    </div>
                                    </div>


                                    <div className='sixth'>
                                    <div className="bg-gray-200 rounded-lg bg-gray-200">
                                        <h3 className='font-[500] text-[15px] text-black whitespace-nowrap color'>Allow Purchase Order Approval</h3>
                                        <label className='toggle-label border-lg'>
                                            <input type='checkbox' />
                                            <span className='back'>
                                                <span className='toggle'></span>
                                                <span className='label on mt-[-20px]'>ON</span>
                                                <span className='label off  mt-[-20px]'>OFF</span>
                                            </span>
                                        </label>
                                    </div>
                                    </div>


                                    {/* bg-gray-200 */}
                                    <div>
                                        <label
                                            htmlFor="select_brand"
                                            className='font-[500] text-[15px] text-black whitespace-nowrap color'
                                        >
                                            Purchase Default Focus On
                                        </label>

                                        <select
                                            id="bank"
                                            // value={paymentMode}
                                            // onChange={handleChange}
                                            className="bg-white border border-slate-300 text-gray-900 text-sm rounded-lg  block w-full px-2 py-[8px] mt-3 "
                                        >
                                            <option selected>Search Bank</option>
                                            <option value="cash">Cash</option>
                                            <option value="cheque">Cheque</option>
                                            <option value="dds">DDS</option>
                                            <option value="DE">E-Commerce Operator</option>
                                            <option value="DE">UIN Holders</option>
                                        </select>
                                    </div>



                                    <div className='Seventh'>
                                    <div className="bg-gray-200 rounded-lg bg-gray-200">
                                        <h3 className='font-[500] text-[15px] text-black whitespace-nowrap color'>Allow Purchase Merge Same Item</h3>
                                        <label className='toggle-label border-lg'>
                                            <input type='checkbox' />
                                            <span className='back'>
                                                <span className='toggle'></span>
                                                <span className='label on mt-[-20px]'>ON</span>
                                                <span className='label off  mt-[-20px]'>OFF</span>
                                            </span>
                                        </label>
                                    </div>
                                    </div>

                                </div>
                            </div>
                        </>
                    </div>
                </div>
            </div>


            <div className="mx-auto px-[24px] bg-white py-[24px] my-[24px] mb-[50px]">

                <div className='border-b border-slate-300'>
                    <span className='text-[16px] font-[500] text-[#2ac3df] py-[25px]'>Purchase Terms & Conditions</span>
                </div>
                {/* Start coding here */}
                <div className="bg-white  relative  overflow-hidden">
                    <div className="flex flex-col md:flex-row items-center justify-between space-y-3 md:space-y-0 md:space-x-4 p-4 px-[32px]">
                        <div className=''>
                            <button
                                type="button"
                                onClick={() => setMembershipBoxOpen(!membershipBoxOpen)}
                                className="flex items-center justify-center text-black border border-slate-300 rounded-[8px] font-[500] text-sm px-3 py-1 "
                            >
                                <span className='mr-1 mt-[2px] text-sm'><FaPlus /></span>

                                Create New
                            </button>

                        </div>

                        <div className="w-full md:w-auto flex flex-col md:flex-row space-y-2 md:space-y-0 items-stretch md:items-center justify-end md:space-x-3 flex-shrink-0">
                            <div>

                                <select
                                    id="countries"
                                    className="bg-gray-50 border border-slate-300 bg-white rounded-[8px] text-black text-sm font-semibold block w-full px-2 py-1"
                                >

                                    <option value="US">10</option>
                                    <option value="CA">25</option>
                                    <option value="FR">50</option>
                                    <option value="DE">100</option>
                                    <option value="DE">200</option>
                                </select>
                            </div>
                            <div>


                            </div>

                            <div className="flex items-center space-x-3 w-full md:w-auto">


                                <div className="w-full ">
                                    <form className="flex items-center">
                                        <label htmlFor="simple-search" className="sr-only">
                                            Search
                                        </label>
                                        <div className="relative w-full">
                                            <div className="absolute inset-y-0 left-0 flex items-center pl-3 pointer-events-none">
                                                <svg
                                                    aria-hidden="true"
                                                    className="w-5 h-5 text-gray-500 "
                                                    fill="currentColor"
                                                    viewBox="0 0 20 20"
                                                    xmlns="http://www.w3.org/2000/svg"
                                                >
                                                    <path
                                                        fillRule="evenodd"
                                                        d="M8 4a4 4 0 100 8 4 4 0 000-8zM2 8a6 6 0 1110.89 3.476l4.817 4.817a1 1 0 01-1.414 1.414l-4.816-4.816A6 6 0 012 8z"
                                                        clipRule="evenodd"
                                                    />
                                                </svg>
                                            </div>
                                            <input
                                                type="text"
                                                // value={searchQuery}
                                                // onChange={handleSearchInput}
                                                id="simple-search"
                                                className="bg-gray-50 border border-slate-300 text-gray-900 text-sm outline-none block w-full pl-10 px-2 py-1 rounded-[8px] "
                                                placeholder="Search"
                                                required
                                            />
                                        </div>
                                    </form>
                                </div>


                            </div>

                        </div>
                    </div>

                    {/* Table Part */}


                    <div className="overflow-x-auto px-[32px] ">
                        <table className="w-full text-sm text-left text-gray-500 ">
                            <thead className="text-[14px] text-black  bg-gray-50 bottom-[23px]">
                                <tr className='w-full border-t border-b border-slate-300'>


                                    <th scope="col" className="px-4 py-[6px] min-w-[7%] border-r font-[500] border-slate-300 ">
                                        #
                                    </th>

                                    <th scope="col" className="px-4 py-[6px] border-r  font-[500] border-slate-300 ">
                                        Name
                                    </th>
                                    <th scope="col" className="px-4 py-[6px]  border-r font-[500] border-slate-300 ">
                                        Is Default
                                    </th>
                                    <th scope="col" className="px-4 py-[6px] border-r font-[500] border-slate-300  ">
                                        Created By
                                    </th>

                                    <th scope="col" className="px-4 py-[6px] font-[500] border-slate-300  ">
                                        Actions
                                    </th>

                                </tr>
                            </thead>

                            <tbody className='mt-8 '>
                                {data?.length === 0 ? (
                                    <tr className='border-b border-slate-300'>
                                        <td colSpan={6} className="px-4 py-[6px] font-[400] text-center text-slate-700">
                                            No data available in this table
                                        </td>
                                    </tr>
                                ) : (
                                    data?.map((material, index) => (
                                        <tr key={index} className="border-t border-b border-slate-300">
                                            <td
                                                className="px-4 py-[6px] font-medium  border-r border-slate-300 text-black"
                                            >
                                                {index + 1}
                                            </td>
                                            <td className="px-4 py-[6px]  border-r border-slate-300 font-[500] text-sky-500">{material.consumptionNumber}</td>

                                            <td className="px-4 py-[6px] border-r border-slate-300 font-[500]">
                                                {material?.consumptionDate ? formatDate(material.consumptionDate) : ''}
                                            </td>
                                            <td className="px-4 py-[6px]  border-r border-slate-300 font-[500]">{material?.userName}</td>
                                            <td className="px-4 py-[6px]  border-r border-slate-300 font-[500]">{material?.consumptionType}</td>
                                            <td className="px-4 py-[6px]  border-r border-slate-300 font-[500]">{material?.location}</td>
                                            <td className="px-4 py-[6px]  border-r border-slate-300 font-[500]">{material?.grandTotal}</td>

                                            <td className="px-4 py-[6px]  font-[500] flex gap-x-[12px]">
                                                <span className='text-[18px] '><GiShieldDisabled /></span>
                                                <button type='button' onClick={() => handleDeleteMaterialCon(material?._id)} className='text-[18px]'><RiDeleteBin6Line /></button>
                                                <span className='text-[18px] '><FaRegEdit /></span>
                                            </td>
                                        </tr>
                                    ))
                                )}
                            </tbody>

                        </table>
                    </div>
                    <nav
                        className="flex flex-col md:flex-row justify-between items-start px-[32px] md:items-center space-y-3 md:space-y-0 p-4"
                        aria-label="Table navigation"
                    >
                        <span className="text-sm font-normal text-slate-500 ">
                            Showing{" "}
                            <span className="font-semibold text-slate-600 ">
                                1-10{" "}
                            </span>
                            of{" "}
                            <span className="font-semibold text-slate-600 ">
                                1000{" "}
                            </span>
                        </span>
                        <ul className="inline-flex items-stretch -space-x-px">
                            <li>
                                <a
                                    href="#"
                                    className="flex items-center justify-center h-full py-1.5 px-3 ml-0 text-gray-500 bg-white rounded-l-lg border border-slate-300 hover:bg-gray-100 hover:text-gray-700  "
                                >
                                    <span className="sr-only">Previous</span>
                                    <svg
                                        className="w-5 h-5"
                                        aria-hidden="true"
                                        fill="currentColor"
                                        viewBox="0 0 20 20"
                                        xmlns="http://www.w3.org/2000/svg"
                                    >
                                        <path
                                            fillRule="evenodd"
                                            d="M12.707 5.293a1 1 0 010 1.414L9.414 10l3.293 3.293a1 1 0 01-1.414 1.414l-4-4a1 1 0 010-1.414l4-4a1 1 0 011.414 0z"
                                            clipRule="evenodd"
                                        />
                                    </svg>
                                </a>
                            </li>
                            <li>
                                <a
                                    href="#"
                                    className="flex items-center justify-center text-sm py-2 px-3 leading-tight text-gray-500 bg-white border border-slate-300 hover:bg-gray-100 hover:text-gray-700  "
                                >
                                    1
                                </a>
                            </li>
                            <li>
                                <a
                                    href="#"
                                    className="flex items-center justify-center text-sm py-2 px-3 leading-tight text-gray-500 bg-white border border-slate-300 hover:bg-gray-100 hover:text-gray-700  "
                                >
                                    2
                                </a>
                            </li>
                            <li>
                                <a
                                    href="#"
                                    aria-current="page"
                                    className="flex items-center justify-center text-sm z-10 py-2 px-3 leading-tight text-primary-600 bg-primary-50 border border-slate-300 hover:bg-primary-100 hover:text-primary-700   "
                                >
                                    3
                                </a>
                            </li>
                            <li>
                                <a
                                    href="#"
                                    className="flex items-center justify-center text-sm py-2 px-3 leading-tight text-gray-500 bg-white border border-slate-300 hover:bg-gray-100 hover:text-gray-700  "
                                >
                                    ...
                                </a>
                            </li>
                            <li>
                                <a
                                    href="#"
                                    className="flex items-center justify-center text-sm py-2 px-3 leading-tight text-gray-500 bg-white border border-slate-300 hover:bg-gray-100 hover:text-gray-700  "
                                >
                                    100
                                </a>
                            </li>
                            <li>
                                <a
                                    href="#"
                                    className="flex items-center justify-center h-full py-1.5 px-3 leading-tight text-gray-500 bg-white rounded-r-lg border border-slate-300 hover:bg-gray-100 hover:text-gray-700  "
                                >
                                    <span className="sr-only">Next</span>
                                    <svg
                                        className="w-5 h-5"
                                        aria-hidden="true"
                                        fill="currentColor"
                                        viewBox="0 0 20 20"
                                        xmlns="http://www.w3.org/2000/svg"
                                    >
                                        <path
                                            fillRule="evenodd"
                                            d="M7.293 14.707a1 1 0 010-1.414L10.586 10 7.293 6.707a1 1 0 011.414-1.414l4 4a1 1 0 010 1.414l-4 4a1 1 0 01-1.414 0z"
                                            clipRule="evenodd"
                                        />
                                    </svg>
                                </a>
                            </li>
                        </ul>
                    </nav>
                </div>
            </div>


        </DefaultLayout>
    )
}

export default PurchaseSettings